import{At as e,B as t,D as n,E as r,G as i,I as a,Mt as o,S as s,U as c,V as l,b as u,g as d,k as f,m as p,ot as m,tt as ee,v as te,x as h,y as g}from"./vue-vendor-DBT-cNUj.js";/* empty css                  */import{w as ne,x as re}from"./index-Dh15gM_A.js";import{a as ie,t as ae}from"./format-_2hHHHlA.js";import{t as oe}from"./BusySpinner-yEHohdw2.js";import{s as se}from"./FolderPickerModal-DgoFNYw0.js";import{n as ce,t as le}from"./PreviewHeader-9vfGR1Uh.js";import{t as ue}from"./fileIcon-DOkdUFUB.js";var _={MEDIA_PLAY_REQUEST:`mediaplayrequest`,MEDIA_PAUSE_REQUEST:`mediapauserequest`,MEDIA_MUTE_REQUEST:`mediamuterequest`,MEDIA_UNMUTE_REQUEST:`mediaunmuterequest`,MEDIA_LOOP_REQUEST:`medialooprequest`,MEDIA_VOLUME_REQUEST:`mediavolumerequest`,MEDIA_SEEK_REQUEST:`mediaseekrequest`,MEDIA_AIRPLAY_REQUEST:`mediaairplayrequest`,MEDIA_ENTER_FULLSCREEN_REQUEST:`mediaenterfullscreenrequest`,MEDIA_EXIT_FULLSCREEN_REQUEST:`mediaexitfullscreenrequest`,MEDIA_PREVIEW_REQUEST:`mediapreviewrequest`,MEDIA_ENTER_PIP_REQUEST:`mediaenterpiprequest`,MEDIA_EXIT_PIP_REQUEST:`mediaexitpiprequest`,MEDIA_ENTER_CAST_REQUEST:`mediaentercastrequest`,MEDIA_EXIT_CAST_REQUEST:`mediaexitcastrequest`,MEDIA_SHOW_TEXT_TRACKS_REQUEST:`mediashowtexttracksrequest`,MEDIA_HIDE_TEXT_TRACKS_REQUEST:`mediahidetexttracksrequest`,MEDIA_SHOW_SUBTITLES_REQUEST:`mediashowsubtitlesrequest`,MEDIA_DISABLE_SUBTITLES_REQUEST:`mediadisablesubtitlesrequest`,MEDIA_TOGGLE_SUBTITLES_REQUEST:`mediatogglesubtitlesrequest`,MEDIA_PLAYBACK_RATE_REQUEST:`mediaplaybackraterequest`,MEDIA_RENDITION_REQUEST:`mediarenditionrequest`,MEDIA_AUDIO_TRACK_REQUEST:`mediaaudiotrackrequest`,MEDIA_SEEK_TO_LIVE_REQUEST:`mediaseektoliverequest`,REGISTER_MEDIA_STATE_RECEIVER:`registermediastatereceiver`,UNREGISTER_MEDIA_STATE_RECEIVER:`unregistermediastatereceiver`},v={MEDIA_CHROME_ATTRIBUTES:`mediachromeattributes`,MEDIA_CONTROLLER:`mediacontroller`},de={MEDIA_AIRPLAY_UNAVAILABLE:`mediaAirplayUnavailable`,MEDIA_AUDIO_TRACK_ENABLED:`mediaAudioTrackEnabled`,MEDIA_AUDIO_TRACK_LIST:`mediaAudioTrackList`,MEDIA_AUDIO_TRACK_UNAVAILABLE:`mediaAudioTrackUnavailable`,MEDIA_BUFFERED:`mediaBuffered`,MEDIA_CAST_UNAVAILABLE:`mediaCastUnavailable`,MEDIA_CHAPTERS_CUES:`mediaChaptersCues`,MEDIA_CURRENT_TIME:`mediaCurrentTime`,MEDIA_DURATION:`mediaDuration`,MEDIA_ENDED:`mediaEnded`,MEDIA_ERROR:`mediaError`,MEDIA_ERROR_CODE:`mediaErrorCode`,MEDIA_ERROR_MESSAGE:`mediaErrorMessage`,MEDIA_FULLSCREEN_UNAVAILABLE:`mediaFullscreenUnavailable`,MEDIA_HAS_PLAYED:`mediaHasPlayed`,MEDIA_HEIGHT:`mediaHeight`,MEDIA_IS_AIRPLAYING:`mediaIsAirplaying`,MEDIA_IS_CASTING:`mediaIsCasting`,MEDIA_IS_FULLSCREEN:`mediaIsFullscreen`,MEDIA_IS_PIP:`mediaIsPip`,MEDIA_LOADING:`mediaLoading`,MEDIA_MUTED:`mediaMuted`,MEDIA_LOOP:`mediaLoop`,MEDIA_PAUSED:`mediaPaused`,MEDIA_PIP_UNAVAILABLE:`mediaPipUnavailable`,MEDIA_PLAYBACK_RATE:`mediaPlaybackRate`,MEDIA_PREVIEW_CHAPTER:`mediaPreviewChapter`,MEDIA_PREVIEW_COORDS:`mediaPreviewCoords`,MEDIA_PREVIEW_IMAGE:`mediaPreviewImage`,MEDIA_PREVIEW_TIME:`mediaPreviewTime`,MEDIA_RENDITION_LIST:`mediaRenditionList`,MEDIA_RENDITION_SELECTED:`mediaRenditionSelected`,MEDIA_RENDITION_UNAVAILABLE:`mediaRenditionUnavailable`,MEDIA_SEEKABLE:`mediaSeekable`,MEDIA_STREAM_TYPE:`mediaStreamType`,MEDIA_SUBTITLES_LIST:`mediaSubtitlesList`,MEDIA_SUBTITLES_SHOWING:`mediaSubtitlesShowing`,MEDIA_TARGET_LIVE_WINDOW:`mediaTargetLiveWindow`,MEDIA_TIME_IS_LIVE:`mediaTimeIsLive`,MEDIA_VOLUME:`mediaVolume`,MEDIA_VOLUME_LEVEL:`mediaVolumeLevel`,MEDIA_VOLUME_UNAVAILABLE:`mediaVolumeUnavailable`,MEDIA_LANG:`mediaLang`,MEDIA_WIDTH:`mediaWidth`},fe=Object.entries(de),y=fe.reduce((e,[t,n])=>(e[t]=n.toLowerCase(),e),{}),b=fe.reduce((e,[t,n])=>(e[t]=n.toLowerCase(),e),{USER_INACTIVE_CHANGE:`userinactivechange`,BREAKPOINTS_CHANGE:`breakpointchange`,BREAKPOINTS_COMPUTED:`breakpointscomputed`});Object.entries(b).reduce((e,[t,n])=>{let r=y[t];return r&&(e[n]=r),e},{userinactivechange:`userinactive`});var pe=Object.entries(y).reduce((e,[t,n])=>{let r=b[t];return r&&(e[n]=r),e},{userinactive:`userinactivechange`}),x={SUBTITLES:`subtitles`,CAPTIONS:`captions`,DESCRIPTIONS:`descriptions`,CHAPTERS:`chapters`,METADATA:`metadata`},me={DISABLED:`disabled`,HIDDEN:`hidden`,SHOWING:`showing`},S={MOUSE:`mouse`,PEN:`pen`,TOUCH:`touch`},C={UNAVAILABLE:`unavailable`,UNSUPPORTED:`unsupported`},w={LIVE:`live`,ON_DEMAND:`on-demand`,UNKNOWN:`unknown`},he={INLINE:`inline`,FULLSCREEN:`fullscreen`,PICTURE_IN_PICTURE:`picture-in-picture`};function ge(e){return e?.map(_e).join(` `)}function _e(e){if(e){let{id:t,width:n,height:r}=e;return[t,n,r].filter(e=>e!=null).join(`:`)}}function ve(e){return e?.map(ye).join(` `)}function ye(e){if(e){let{id:t,kind:n,language:r,label:i}=e;return[t,n,r,i].filter(e=>e!=null).join(`:`)}}function be(e){return typeof e==`number`&&!Number.isNaN(e)&&Number.isFinite(e)}var xe=e=>new Promise(t=>setTimeout(t,e)),Se={en:{"Start airplay":`Start airplay`,"Stop airplay":`Stop airplay`,Audio:`Audio`,Captions:`Captions`,"Enable captions":`Enable captions`,"Disable captions":`Disable captions`,"Start casting":`Start casting`,"Stop casting":`Stop casting`,"Enter fullscreen mode":`Enter fullscreen mode`,"Exit fullscreen mode":`Exit fullscreen mode`,Mute:`Mute`,Unmute:`Unmute`,Loop:`Loop`,"Enter picture in picture mode":`Enter picture in picture mode`,"Exit picture in picture mode":`Exit picture in picture mode`,Play:`Play`,Pause:`Pause`,"Playback rate":`Playback rate`,"Playback rate {playbackRate}":`Playback rate {playbackRate}`,Quality:`Quality`,"Seek backward":`Seek backward`,"Seek forward":`Seek forward`,Settings:`Settings`,Auto:`Auto`,"audio player":`audio player`,"video player":`video player`,volume:`volume`,seek:`seek`,"closed captions":`closed captions`,"current playback rate":`current playback rate`,"playback time":`playback time`,"media loading":`media loading`,settings:`settings`,"audio tracks":`audio tracks`,quality:`quality`,play:`play`,pause:`pause`,mute:`mute`,unmute:`unmute`,"chapter: {chapterName}":`chapter: {chapterName}`,live:`live`,Off:`Off`,"start airplay":`start airplay`,"stop airplay":`stop airplay`,"start casting":`start casting`,"stop casting":`stop casting`,"enter fullscreen mode":`enter fullscreen mode`,"exit fullscreen mode":`exit fullscreen mode`,"enter picture in picture mode":`enter picture in picture mode`,"exit picture in picture mode":`exit picture in picture mode`,"seek to live":`seek to live`,"playing live":`playing live`,"seek back {seekOffset} seconds":`seek back {seekOffset} seconds`,"seek forward {seekOffset} seconds":`seek forward {seekOffset} seconds`,"Network Error":`Network Error`,"Decode Error":`Decode Error`,"Source Not Supported":`Source Not Supported`,"Encryption Error":`Encryption Error`,"A network error caused the media download to fail.":`A network error caused the media download to fail.`,"A media error caused playback to be aborted. The media could be corrupt or your browser does not support this format.":`A media error caused playback to be aborted. The media could be corrupt or your browser does not support this format.`,"An unsupported error occurred. The server or network failed, or your browser does not support this format.":`An unsupported error occurred. The server or network failed, or your browser does not support this format.`,"The media is encrypted and there are no keys to decrypt it.":`The media is encrypted and there are no keys to decrypt it.`,hour:`hour`,hours:`hours`,minute:`minute`,minutes:`minutes`,second:`second`,seconds:`seconds`,"{time} remaining":`{time} remaining`,"{currentTime} of {totalTime}":`{currentTime} of {totalTime}`,"video not loaded, unknown time.":`video not loaded, unknown time.`}},Ce=globalThis.navigator?.language||`en`,we=e=>{Ce=e},Te=(e,t)=>{Se[e]=t},Ee=e=>{let[t]=Ce.split(`-`);return Se[Ce]?.[e]||Se[t]?.[e]||Se.en?.[e]||e},De=()=>{let[e]=Ce.split(`-`);return Se[Ce]?Ce:Se[e]?e:`en`},T=(e,t={})=>Ee(e).replace(/\{(\w+)\}/g,(e,n)=>n in t?String(t[n]):`{${n}}`),Oe=[{singular:`hour`,plural:`hours`},{singular:`minute`,plural:`minutes`},{singular:`second`,plural:`seconds`}],ke=(e,t)=>`${e} ${T(e===1?Oe[t].singular:Oe[t].plural)}`,Ae=e=>{if(!be(e))return``;let t=Math.abs(e),n=t!==e,r=new Date(0,0,0,0,0,t,0),i=[r.getHours(),r.getMinutes(),r.getSeconds()].map((e,t)=>e&&ke(e,t)).filter(e=>e).join(`, `);return n?T(`{time} remaining`,{time:i}):i};function je(e,t){let n=!1;e<0&&(n=!0,e=0-e),e=e<0?0:e;let r=Math.floor(e%60),i=Math.floor(e/60%60),a=Math.floor(e/3600),o=Math.floor(t/60%60),s=Math.floor(t/3600);return(isNaN(e)||e===1/0)&&(a=i=r=`0`),a=a>0||s>0?a+`:`:``,i=((a||o>=10)&&i<10?`0`+i:i)+`:`,r=r<10?`0`+r:r,(n?`-`:``)+a+i+r}Object.freeze({length:0,start(e){let t=e>>>0;if(t>=this.length)throw new DOMException(`Failed to execute 'start' on 'TimeRanges': The index provided (${t}) is greater than or equal to the maximum bound (${this.length}).`);return 0},end(e){let t=e>>>0;if(t>=this.length)throw new DOMException(`Failed to execute 'end' on 'TimeRanges': The index provided (${t}) is greater than or equal to the maximum bound (${this.length}).`);return 0}});var Me=class{addEventListener(){}removeEventListener(){}dispatchEvent(){return!0}},Ne=class extends Me{},Pe=class extends Ne{constructor(){super(...arguments),this.role=null}},Fe=class{observe(){}unobserve(){}disconnect(){}},Ie={createElement:function(){return new Le.HTMLElement},createElementNS:function(){return new Le.HTMLElement},addEventListener(){},removeEventListener(){},dispatchEvent(e){return!1}},Le={ResizeObserver:Fe,document:Ie,Node:Ne,Element:Pe,HTMLElement:class extends Pe{constructor(){super(...arguments),this.innerHTML=``}get content(){return new Le.DocumentFragment}},DocumentFragment:class extends Me{},customElements:{get:function(){},define:function(){},whenDefined:function(){}},localStorage:{getItem(e){return null},setItem(e,t){},removeItem(e){}},CustomEvent:function(){},getComputedStyle:function(){},navigator:{languages:[],get userAgent(){return``}},matchMedia(e){return{matches:!1,media:e}},DOMParser:class{parseFromString(e,t){return{body:{textContent:e}}}}},Re=`global`in globalThis&&(globalThis==null?void 0:globalThis.global)===globalThis||typeof window>`u`||window.customElements===void 0,ze=Object.keys(Le).every(e=>e in globalThis),E=Re&&!ze?Le:globalThis,D=Re&&!ze?Ie:globalThis.document,Be=new WeakMap,Ve=e=>{let t=Be.get(e);return t||Be.set(e,t=new Set),t},He=new E.ResizeObserver(e=>{for(let t of e)for(let e of Ve(t.target))e(t)});function Ue(e,t){Ve(e).add(t),He.observe(e)}function We(e,t){let n=Ve(e);n.delete(t),n.size||He.unobserve(e)}function Ge(e){let t={};for(let n of e)t[n.name]=n.value;return t}function Ke(e){return qe(e)??Qe(e,`media-controller`)}function qe(e){let{MEDIA_CONTROLLER:t}=v,n=e.getAttribute(t);if(n)return et(e)?.getElementById(n)}var Je=(e,t,n=`.value`)=>{let r=e.querySelector(n);r&&(r.textContent=t)},Ye=(e,t)=>{let n=`slot[name="${t}"]`,r=e.shadowRoot.querySelector(n);return r?r.children:[]},Xe=(e,t)=>Ye(e,t)[0],Ze=(e,t)=>!e||!t?!1:e?.contains(t)?!0:Ze(e,t.getRootNode().host),Qe=(e,t)=>e?e.closest(t)||Qe(e.getRootNode().host,t):null;function $e(e=document){let t=e?.activeElement;return t?$e(t.shadowRoot)??t:null}function et(e){let t=(e?.getRootNode)?.call(e);return t instanceof ShadowRoot||t instanceof Document?t:null}function tt(e,{depth:t=3,checkOpacity:n=!0,checkVisibilityCSS:r=!0}={}){if(e.checkVisibility)return e.checkVisibility({checkOpacity:n,checkVisibilityCSS:r});let i=e;for(;i&&t>0;){let e=getComputedStyle(i);if(n&&e.opacity===`0`||r&&e.visibility===`hidden`||e.display===`none`)return!1;i=i.parentElement,t--}return!0}function nt(e,t,n,r){let i=r.x-n.x,a=r.y-n.y,o=i*i+a*a;if(o===0)return 0;let s=((e-n.x)*i+(t-n.y)*a)/o;return Math.max(0,Math.min(1,s))}function O(e,t){return rt(e,e=>e===t)||it(e,t)}function rt(e,t){let n;for(n of e.querySelectorAll(`style:not([media])`)??[]){let e;try{e=n.sheet?.cssRules}catch{continue}for(let n of e??[])if(t(n.selectorText))return n}}function it(e,t){let n=e.querySelectorAll(`style:not([media])`)??[],r=n?.[n.length-1];if(!r?.sheet)return console.warn(`Media Chrome: No style sheet found on style tag of`,e),{style:{setProperty:()=>{},removeProperty:()=>``,getPropertyValue:()=>``}};let i=r?.sheet.insertRule(`${t}{}`,r.sheet.cssRules.length);return r.sheet.cssRules?.[i]}function k(e,t,n=NaN){let r=e.getAttribute(t);return r==null?n:+r}function A(e,t,n){let r=+n;if(n==null||Number.isNaN(r)){e.hasAttribute(t)&&e.removeAttribute(t);return}k(e,t,void 0)!==r&&e.setAttribute(t,`${r}`)}function j(e,t){return e.hasAttribute(t)}function M(e,t,n){if(n==null){e.hasAttribute(t)&&e.removeAttribute(t);return}j(e,t)!=n&&e.toggleAttribute(t,n)}function N(e,t,n=null){return e.getAttribute(t)??n}function P(e,t,n){if(n==null){e.hasAttribute(t)&&e.removeAttribute(t);return}let r=`${n}`;N(e,t,void 0)!==r&&e.setAttribute(t,r)}var at=(e,t,n)=>{if(!t.has(e))throw TypeError(`Cannot `+n)},ot=(e,t,n)=>(at(e,t,`read from private field`),n?n.call(e):t.get(e)),st=(e,t,n)=>{if(t.has(e))throw TypeError(`Cannot add the same private member more than once`);t instanceof WeakSet?t.add(e):t.set(e,n)},ct=(e,t,n,r)=>(at(e,t,`write to private field`),r?r.call(e,n):t.set(e,n),n),F;function lt(e){return`
    <style>
      :host {
        display: var(--media-control-display, var(--media-gesture-receiver-display, inline-block));
        box-sizing: border-box;
      }
    </style>
  `}var ut=class extends E.HTMLElement{constructor(){if(super(),st(this,F,void 0),!this.shadowRoot){this.attachShadow(this.constructor.shadowRootOptions);let e=Ge(this.attributes);this.shadowRoot.innerHTML=this.constructor.getTemplateHTML(e)}}static get observedAttributes(){return[v.MEDIA_CONTROLLER,y.MEDIA_PAUSED]}attributeChangedCallback(e,t,n){var r,i,a,o;e===v.MEDIA_CONTROLLER&&(t&&((i=(r=ot(this,F))?.unassociateElement)==null||i.call(r,this),ct(this,F,null)),n&&this.isConnected&&(ct(this,F,this.getRootNode()?.getElementById(n)),(o=(a=ot(this,F))?.associateElement)==null||o.call(a,this)))}connectedCallback(){var e,t;this.tabIndex=-1,this.setAttribute(`aria-hidden`,`true`),ct(this,F,dt(this)),this.getAttribute(v.MEDIA_CONTROLLER)&&((t=(e=ot(this,F))?.associateElement)==null||t.call(e,this)),ot(this,F)&&(ot(this,F).addEventListener(`pointerdown`,this),ot(this,F).addEventListener(`click`,this),ot(this,F).hasAttribute(`tabindex`)||(ot(this,F).tabIndex=0))}disconnectedCallback(){var e,t,n,r;this.getAttribute(v.MEDIA_CONTROLLER)&&((t=(e=ot(this,F))?.unassociateElement)==null||t.call(e,this)),(n=ot(this,F))==null||n.removeEventListener(`pointerdown`,this),(r=ot(this,F))==null||r.removeEventListener(`click`,this),ct(this,F,null)}handleEvent(e){let t=e.composedPath()?.[0];if([`video`,`media-controller`].includes(t?.localName)){if(e.type===`pointerdown`)this._pointerType=e.pointerType;else if(e.type===`click`){let{clientX:t,clientY:n}=e,{left:r,top:i,width:a,height:o}=this.getBoundingClientRect(),s=t-r,c=n-i;if(s<0||c<0||s>a||c>o||a===0&&o===0)return;let l=this._pointerType||`mouse`;if(this._pointerType=void 0,l===S.TOUCH){this.handleTap(e);return}if(l===S.MOUSE||l===S.PEN){this.handleMouseClick(e);return}}}}get mediaPaused(){return j(this,y.MEDIA_PAUSED)}set mediaPaused(e){M(this,y.MEDIA_PAUSED,e)}handleTap(e){}handleMouseClick(e){let t=this.mediaPaused?_.MEDIA_PLAY_REQUEST:_.MEDIA_PAUSE_REQUEST;this.dispatchEvent(new E.CustomEvent(t,{composed:!0,bubbles:!0}))}};F=new WeakMap,ut.shadowRootOptions={mode:`open`},ut.getTemplateHTML=lt;function dt(e){let t=e.getAttribute(v.MEDIA_CONTROLLER);return t?e.getRootNode()?.getElementById(t):Qe(e,`media-controller`)}E.customElements.get(`media-gesture-receiver`)||E.customElements.define(`media-gesture-receiver`,ut);var ft=ut,pt=(e,t,n)=>{if(!t.has(e))throw TypeError(`Cannot `+n)},I=(e,t,n)=>(pt(e,t,`read from private field`),n?n.call(e):t.get(e)),L=(e,t,n)=>{if(t.has(e))throw TypeError(`Cannot add the same private member more than once`);t instanceof WeakSet?t.add(e):t.set(e,n)},mt=(e,t,n,r)=>(pt(e,t,`write to private field`),r?r.call(e,n):t.set(e,n),n),ht=(e,t,n)=>(pt(e,t,`access private method`),n),gt,_t,vt,yt,bt,xt,St,Ct,wt,Tt,Et,Dt,Ot,kt,At,jt,Mt,Nt,Pt,Ft,R={AUDIO:`audio`,AUTOHIDE:`autohide`,BREAKPOINTS:`breakpoints`,GESTURES_DISABLED:`gesturesdisabled`,KEYBOARD_CONTROL:`keyboardcontrol`,NO_AUTOHIDE:`noautohide`,USER_INACTIVE:`userinactive`,AUTOHIDE_OVER_CONTROLS:`autohideovercontrols`};function It(e){return`
    <style>
      
      :host([${y.MEDIA_IS_FULLSCREEN}]) ::slotted([slot=media]) {
        outline: none;
      }

      :host {
        box-sizing: border-box;
        position: relative;
        display: inline-block;
        line-height: 0;
        background-color: var(--media-background-color, #000);
        overflow: hidden;
      }

      :host(:not([${R.AUDIO}])) [part~=layer]:not([part~=media-layer]) {
        position: absolute;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
        display: flex;
        flex-flow: column nowrap;
        align-items: start;
        pointer-events: none;
        background: none;
      }

      slot[name=media] {
        display: var(--media-slot-display, contents);
      }

      
      :host([${R.AUDIO}]) slot[name=media] {
        display: var(--media-slot-display, none);
      }

      
      :host([${R.AUDIO}]) [part~=layer][part~=gesture-layer] {
        height: 0;
        display: block;
      }

      
      :host(:not([${R.AUDIO}])[${R.GESTURES_DISABLED}]) ::slotted([slot=gestures-chrome]),
          :host(:not([${R.AUDIO}])[${R.GESTURES_DISABLED}]) media-gesture-receiver[slot=gestures-chrome] {
        display: none;
      }

      
      ::slotted(:not([slot=media]):not([slot=poster]):not(media-loading-indicator):not([role=dialog]):not([hidden])) {
        pointer-events: auto;
      }

      :host(:not([${R.AUDIO}])) *[part~=layer][part~=centered-layer] {
        align-items: center;
        justify-content: center;
      }

      :host(:not([${R.AUDIO}])) ::slotted(media-gesture-receiver[slot=gestures-chrome]),
      :host(:not([${R.AUDIO}])) media-gesture-receiver[slot=gestures-chrome] {
        align-self: stretch;
        flex-grow: 1;
      }

      slot[name=middle-chrome] {
        display: inline;
        flex-grow: 1;
        pointer-events: none;
        background: none;
      }

      
      ::slotted([slot=media]),
      ::slotted([slot=poster]) {
        width: 100%;
        height: 100%;
      }

      
      :host(:not([${R.AUDIO}])) .spacer {
        flex-grow: 1;
      }

      
      :host(:-webkit-full-screen) {
        
        width: 100% !important;
        height: 100% !important;
      }

      
      ::slotted(:not([slot=media]):not([slot=poster]):not([${R.NO_AUTOHIDE}]):not([hidden]):not([role=dialog])) {
        opacity: 1;
        transition: var(--media-control-transition-in, opacity 0.25s);
      }

      
      :host([${R.USER_INACTIVE}]:not([${y.MEDIA_PAUSED}]):not([${y.MEDIA_IS_AIRPLAYING}]):not([${y.MEDIA_IS_CASTING}]):not([${R.AUDIO}])) ::slotted(:not([slot=media]):not([slot=poster]):not([${R.NO_AUTOHIDE}]):not([role=dialog])) {
        opacity: 0;
        transition: var(--media-control-transition-out, opacity 1s);
      }

      :host([${R.USER_INACTIVE}]:not([${R.NO_AUTOHIDE}]):not([${y.MEDIA_PAUSED}]):not([${y.MEDIA_IS_CASTING}]):not([${R.AUDIO}])) ::slotted([slot=media]) {
        cursor: none;
      }

      :host([${R.USER_INACTIVE}][${R.AUTOHIDE_OVER_CONTROLS}]:not([${R.NO_AUTOHIDE}]):not([${y.MEDIA_PAUSED}]):not([${y.MEDIA_IS_CASTING}]):not([${R.AUDIO}])) * {
        --media-cursor: none;
        cursor: none;
      }


      ::slotted(media-control-bar)  {
        align-self: stretch;
      }

      
      :host(:not([${R.AUDIO}])[${y.MEDIA_HAS_PLAYED}]) slot[name=poster] {
        display: none;
      }

      ::slotted([role=dialog]) {
        width: 100%;
        height: 100%;
        align-self: center;
      }

      ::slotted([role=menu]) {
        align-self: end;
      }
    </style>

    <slot name="media" part="layer media-layer"></slot>
    <slot name="poster" part="layer poster-layer"></slot>
    <slot name="gestures-chrome" part="layer gesture-layer">
      <media-gesture-receiver slot="gestures-chrome">
        <template shadowrootmode="${ft.shadowRootOptions.mode}">
          ${ft.getTemplateHTML({})}
        </template>
      </media-gesture-receiver>
    </slot>
    <span part="layer vertical-layer">
      <slot name="top-chrome" part="top chrome"></slot>
      <slot name="middle-chrome" part="middle chrome"></slot>
      <slot name="centered-chrome" part="layer centered-layer center centered chrome"></slot>
      
      <slot part="bottom chrome"></slot>
    </span>
    <slot name="dialog" part="layer dialog-layer"></slot>
  `}var Lt=Object.values(y),Rt=`sm:384 md:576 lg:768 xl:960`;function zt(e){Bt(e.target,e.contentRect.width)}function Bt(e,t){if(!e.isConnected)return;let n=Vt(e.getAttribute(R.BREAKPOINTS)??Rt),r=Ht(n,t),i=!1;if(Object.keys(n).forEach(t=>{if(r.includes(t)){e.hasAttribute(`breakpoint${t}`)||(e.setAttribute(`breakpoint${t}`,``),i=!0);return}e.hasAttribute(`breakpoint${t}`)&&(e.removeAttribute(`breakpoint${t}`),i=!0)}),i){let t=new CustomEvent(b.BREAKPOINTS_CHANGE,{detail:r});e.dispatchEvent(t)}e.breakpointsComputed||(e.breakpointsComputed=!0,e.dispatchEvent(new CustomEvent(b.BREAKPOINTS_COMPUTED,{bubbles:!0,composed:!0})))}function Vt(e){let t=e.split(/\s+/);return Object.fromEntries(t.map(e=>e.split(`:`)))}function Ht(e,t){return Object.keys(e).filter(n=>t>=parseInt(e[n]))}var Ut=class extends E.HTMLElement{constructor(){if(super(),L(this,wt),L(this,Et),L(this,Ot),L(this,At),L(this,Mt),L(this,gt,void 0),L(this,_t,0),L(this,vt,null),L(this,yt,null),L(this,bt,void 0),this.breakpointsComputed=!1,L(this,xt,e=>{let t=this.media;for(let n of e){if(n.type!==`childList`)continue;let e=n.removedNodes;for(let r of e){if(r.slot!=`media`||n.target!=this)continue;let e=n.previousSibling&&n.previousSibling.previousElementSibling;if(!e||!t)this.mediaUnsetCallback(r);else{let t=e.slot!==`media`;for(;(e=e.previousSibling)!==null;)e.slot==`media`&&(t=!1);t&&this.mediaUnsetCallback(r)}}if(t)for(let e of n.addedNodes)e===t&&this.handleMediaUpdated(t)}}),L(this,St,!1),L(this,Ct,e=>{I(this,St)||(setTimeout(()=>{zt(e),mt(this,St,!1)},0),mt(this,St,!0))}),L(this,Pt,void 0),L(this,Ft,()=>{if(!I(this,Pt).assignedElements({flatten:!0}).length){I(this,vt)&&this.mediaUnsetCallback(I(this,vt));return}this.handleMediaUpdated(this.media)}),!this.shadowRoot){this.attachShadow(this.constructor.shadowRootOptions);let e=Ge(this.attributes),t=this.constructor.getTemplateHTML(e);this.shadowRoot.setHTMLUnsafe?this.shadowRoot.setHTMLUnsafe(t):this.shadowRoot.innerHTML=t}mt(this,gt,new MutationObserver(I(this,xt)))}static get observedAttributes(){return[R.AUTOHIDE,R.GESTURES_DISABLED].concat(Lt).filter(e=>![y.MEDIA_RENDITION_LIST,y.MEDIA_AUDIO_TRACK_LIST,y.MEDIA_CHAPTERS_CUES,y.MEDIA_WIDTH,y.MEDIA_HEIGHT,y.MEDIA_ERROR,y.MEDIA_ERROR_MESSAGE].includes(e))}attributeChangedCallback(e,t,n){e.toLowerCase()==R.AUTOHIDE&&(this.autohide=n)}get media(){let e=this.querySelector(`:scope > [slot=media]`);return e?.nodeName==`SLOT`&&(e=e.assignedElements({flatten:!0})[0]),e}async handleMediaUpdated(e){e&&(mt(this,vt,e),e.localName.includes(`-`)&&await E.customElements.whenDefined(e.localName),this.mediaSetCallback(e))}connectedCallback(){var e;I(this,gt).observe(this,{childList:!0,subtree:!0}),Ue(this,I(this,Ct));let t=this.getAttribute(R.AUDIO)==null?T(`video player`):T(`audio player`);this.setAttribute(`role`,`region`),this.setAttribute(`aria-label`,t),this.handleMediaUpdated(this.media),this.setAttribute(R.USER_INACTIVE,``),Bt(this,this.getBoundingClientRect().width);let n=this.querySelector(`:scope > slot[slot=media]`);n&&(mt(this,Pt,n),I(this,Pt).addEventListener(`slotchange`,I(this,Ft))),this.addEventListener(`pointerdown`,this),this.addEventListener(`pointermove`,this),this.addEventListener(`pointerup`,this),this.addEventListener(`mouseleave`,this),this.addEventListener(`keyup`,this),(e=E.window)==null||e.addEventListener(`mouseup`,this)}disconnectedCallback(){var e;We(this,I(this,Ct)),clearTimeout(I(this,yt)),I(this,gt).disconnect(),this.media&&this.mediaUnsetCallback(this.media),(e=E.window)==null||e.removeEventListener(`mouseup`,this),this.removeEventListener(`pointerdown`,this),this.removeEventListener(`pointermove`,this),this.removeEventListener(`pointerup`,this),this.removeEventListener(`mouseleave`,this),this.removeEventListener(`keyup`,this),I(this,Pt)&&(I(this,Pt).removeEventListener(`slotchange`,I(this,Ft)),mt(this,Pt,null)),mt(this,St,!1)}mediaSetCallback(e){}mediaUnsetCallback(e){mt(this,vt,null)}handleEvent(e){switch(e.type){case`pointerdown`:mt(this,_t,e.timeStamp);break;case`pointermove`:ht(this,wt,Tt).call(this,e);break;case`pointerup`:ht(this,Et,Dt).call(this,e);break;case`mouseleave`:ht(this,Ot,kt).call(this);break;case`mouseup`:this.removeAttribute(R.KEYBOARD_CONTROL);break;case`keyup`:ht(this,Mt,Nt).call(this),this.setAttribute(R.KEYBOARD_CONTROL,``)}}set autohide(e){let t=Number(e);mt(this,bt,isNaN(t)?0:t)}get autohide(){return(I(this,bt)===void 0?2:I(this,bt)).toString()}get breakpoints(){return N(this,R.BREAKPOINTS)}set breakpoints(e){P(this,R.BREAKPOINTS,e)}get audio(){return j(this,R.AUDIO)}set audio(e){M(this,R.AUDIO,e)}get gesturesDisabled(){return j(this,R.GESTURES_DISABLED)}set gesturesDisabled(e){M(this,R.GESTURES_DISABLED,e)}get keyboardControl(){return j(this,R.KEYBOARD_CONTROL)}set keyboardControl(e){M(this,R.KEYBOARD_CONTROL,e)}get noAutohide(){return j(this,R.NO_AUTOHIDE)}set noAutohide(e){M(this,R.NO_AUTOHIDE,e)}get autohideOverControls(){return j(this,R.AUTOHIDE_OVER_CONTROLS)}set autohideOverControls(e){M(this,R.AUTOHIDE_OVER_CONTROLS,e)}get userInteractive(){return j(this,R.USER_INACTIVE)}set userInteractive(e){M(this,R.USER_INACTIVE,e)}};gt=new WeakMap,_t=new WeakMap,vt=new WeakMap,yt=new WeakMap,bt=new WeakMap,xt=new WeakMap,St=new WeakMap,Ct=new WeakMap,wt=new WeakSet,Tt=function(e){if(e.pointerType!==`mouse`&&e.timeStamp-I(this,_t)<250)return;ht(this,At,jt).call(this),clearTimeout(I(this,yt));let t=this.hasAttribute(R.AUTOHIDE_OVER_CONTROLS);([this,this.media].includes(e.target)||t)&&ht(this,Mt,Nt).call(this)},Et=new WeakSet,Dt=function(e){if(e.pointerType===`touch`){let t=!this.hasAttribute(R.USER_INACTIVE);[this,this.media].includes(e.target)&&t?ht(this,Ot,kt).call(this):ht(this,Mt,Nt).call(this)}else e.composedPath().some(e=>[`media-play-button`,`media-fullscreen-button`].includes(e?.localName))&&ht(this,Mt,Nt).call(this)},Ot=new WeakSet,kt=function(){if(I(this,bt)<0||this.hasAttribute(R.USER_INACTIVE))return;this.setAttribute(R.USER_INACTIVE,``);let e=new E.CustomEvent(b.USER_INACTIVE_CHANGE,{composed:!0,bubbles:!0,detail:!0});this.dispatchEvent(e)},At=new WeakSet,jt=function(){if(!this.hasAttribute(R.USER_INACTIVE))return;this.removeAttribute(R.USER_INACTIVE);let e=new E.CustomEvent(b.USER_INACTIVE_CHANGE,{composed:!0,bubbles:!0,detail:!1});this.dispatchEvent(e)},Mt=new WeakSet,Nt=function(){ht(this,At,jt).call(this),clearTimeout(I(this,yt));let e=parseInt(this.autohide);e<0||mt(this,yt,setTimeout(()=>{ht(this,Ot,kt).call(this)},e*1e3))},Pt=new WeakMap,Ft=new WeakMap,Ut.shadowRootOptions={mode:`open`},Ut.getTemplateHTML=It,E.customElements.get(`media-container`)||E.customElements.define(`media-container`,Ut);var Wt=(e,t,n)=>{if(!t.has(e))throw TypeError(`Cannot `+n)},z=(e,t,n)=>(Wt(e,t,`read from private field`),n?n.call(e):t.get(e)),Gt=(e,t,n)=>{if(t.has(e))throw TypeError(`Cannot add the same private member more than once`);t instanceof WeakSet?t.add(e):t.set(e,n)},Kt=(e,t,n,r)=>(Wt(e,t,`write to private field`),r?r.call(e,n):t.set(e,n),n),qt,Jt,Yt,Xt,Zt,Qt,$t=class{constructor(e,t,{defaultValue:n}={defaultValue:void 0}){Gt(this,Zt),Gt(this,qt,void 0),Gt(this,Jt,void 0),Gt(this,Yt,void 0),Gt(this,Xt,new Set),Kt(this,qt,e),Kt(this,Jt,t),Kt(this,Yt,new Set(n))}[Symbol.iterator](){return z(this,Zt,Qt).values()}get length(){return z(this,Zt,Qt).size}get value(){return[...z(this,Zt,Qt)].join(` `)??``}set value(e){e!==this.value&&(Kt(this,Xt,new Set),this.add(...e?.split(` `)??[]))}toString(){return this.value}item(e){return[...z(this,Zt,Qt)][e]}values(){return z(this,Zt,Qt).values()}forEach(e,t){z(this,Zt,Qt).forEach(e,t)}add(...e){var t;e.forEach(e=>z(this,Xt).add(e)),!(this.value===``&&!z(this,qt)?.hasAttribute(`${z(this,Jt)}`))&&((t=z(this,qt))==null||t.setAttribute(`${z(this,Jt)}`,`${this.value}`))}remove(...e){var t;e.forEach(e=>z(this,Xt).delete(e)),(t=z(this,qt))==null||t.setAttribute(`${z(this,Jt)}`,`${this.value}`)}contains(e){return z(this,Zt,Qt).has(e)}toggle(e,t){return t===void 0?this.contains(e)?(this.remove(e),!1):(this.add(e),!0):t?(this.add(e),!0):(this.remove(e),!1)}replace(e,t){return this.remove(e),this.add(t),e===t}};qt=new WeakMap,Jt=new WeakMap,Yt=new WeakMap,Xt=new WeakMap,Zt=new WeakSet,Qt=function(){return z(this,Xt).size?z(this,Xt):z(this,Yt)};var en=(e=``)=>e.split(/\s+/),tn=(e=``)=>{let[t,n,r]=e.split(`:`),i=r?decodeURIComponent(r):void 0;return{kind:t===`cc`?x.CAPTIONS:x.SUBTITLES,language:n,label:i}},nn=(e=``,t={})=>en(e).map(e=>{let n=tn(e);return{...t,...n}}),rn=e=>e?Array.isArray(e)?e.map(e=>typeof e==`string`?tn(e):e):typeof e==`string`?nn(e):[e]:[],an=({kind:e,label:t,language:n}={kind:`subtitles`})=>t?`${e===`captions`?`cc`:`sb`}:${n}:${encodeURIComponent(t)}`:n,on=(e=[])=>Array.prototype.map.call(e,an).join(` `),sn=(e,t)=>n=>n[e]===t,cn=e=>{let t=Object.entries(e).map(([e,t])=>sn(e,t));return e=>t.every(t=>t(e))},ln=(e,t=[],n=[])=>{let r=rn(n).map(cn);Array.from(t).filter(e=>r.some(t=>t(e))).forEach(t=>{t.mode=e})},un=(e,t=()=>!0)=>{if(!e?.textTracks)return[];let n=typeof t==`function`?t:cn(t);return Array.from(e.textTracks).filter(n)},dn=e=>!!e.mediaSubtitlesShowing?.length||e.hasAttribute(y.MEDIA_SUBTITLES_SHOWING),fn=e=>{let{media:t,fullscreenElement:n}=e;try{let e=n&&`requestFullscreen`in n?`requestFullscreen`:n&&`webkitRequestFullScreen`in n?`webkitRequestFullScreen`:void 0;if(e){let t=n[e]?.call(n);if(t instanceof Promise)return t.catch(()=>{})}else t?.webkitEnterFullscreen?t.webkitEnterFullscreen():t?.requestFullscreen&&t.requestFullscreen()}catch(e){console.error(e)}},pn=`exitFullscreen`in D?`exitFullscreen`:`webkitExitFullscreen`in D?`webkitExitFullscreen`:`webkitCancelFullScreen`in D?`webkitCancelFullScreen`:void 0,mn=e=>{let{documentElement:t}=e;if(pn){let e=(t?.[pn])?.call(t);if(e instanceof Promise)return e.catch(()=>{})}},hn=`fullscreenElement`in D?`fullscreenElement`:`webkitFullscreenElement`in D?`webkitFullscreenElement`:void 0,gn=e=>{let{documentElement:t,media:n}=e,r=t?.[hn];return!r&&`webkitDisplayingFullscreen`in n&&`webkitPresentationMode`in n&&n.webkitDisplayingFullscreen&&n.webkitPresentationMode===he.FULLSCREEN?n:r},_n=e=>{let{media:t,documentElement:n,fullscreenElement:r=t}=e;if(!t||!n)return!1;let i=gn(e);if(!i)return!1;if(i===r||i===t)return!0;if(i.localName.includes(`-`)){let e=i.shadowRoot;if(!(hn in e))return Ze(i,r);for(;e?.[hn];){if(e[hn]===r)return!0;e=e[hn]?.shadowRoot}}return!1},vn=`fullscreenEnabled`in D?`fullscreenEnabled`:`webkitFullscreenEnabled`in D?`webkitFullscreenEnabled`:void 0,yn=e=>{let{documentElement:t,media:n}=e;return!!t?.[vn]||n&&`webkitSupportsFullscreen`in n},bn,xn=()=>{var e;return bn||(bn=((e=D)?.createElement)?.call(e,`video`),bn)},Sn=async(e=xn())=>{if(!e)return!1;let t=e.volume;e.volume=t/2+.1;let n=new AbortController,r=await Promise.race([Cn(e,n.signal),wn(e,t)]);return n.abort(),r},Cn=(e,t)=>new Promise(n=>{e.addEventListener(`volumechange`,()=>n(!0),{signal:t})}),wn=async(e,t)=>{for(let n=0;n<10;n++){if(e.volume===t)return!1;await xe(10)}return e.volume!==t},Tn=/.*Version\/.*Safari\/.*/.test(E.navigator.userAgent),En=(e=xn())=>E.matchMedia(`(display-mode: standalone)`).matches&&Tn?!1:typeof e?.requestPictureInPicture==`function`,Dn=(e=xn())=>yn({documentElement:D,media:e}),On=Dn(),kn=En(),An=!!E.WebKitPlaybackTargetAvailabilityEvent,jn=!!E.chrome,Mn=e=>un(e.media,e=>[x.SUBTITLES,x.CAPTIONS].includes(e.kind)).sort((e,t)=>e.kind>=t.kind?1:-1),Nn=e=>un(e.media,e=>e.mode===me.SHOWING&&[x.SUBTITLES,x.CAPTIONS].includes(e.kind)),Pn=(e,t)=>{let n=Mn(e),r=Nn(e),i=!!r.length;if(n.length){if(t===!1||i&&t!==!0)ln(me.DISABLED,n,r);else if(t===!0||!i&&t!==!1){let t=n[0],{options:i}=e;if(!i?.noSubtitlesLangPref){let e=E.localStorage.getItem(`media-chrome-pref-subtitles-lang`),r=e?[e,...E.navigator.languages]:E.navigator.languages,i=n.filter(e=>r.some(t=>e.language.toLowerCase().startsWith(t.split(`-`)[0]))).sort((e,t)=>r.findIndex(t=>e.language.toLowerCase().startsWith(t.split(`-`)[0]))-r.findIndex(e=>t.language.toLowerCase().startsWith(e.split(`-`)[0])));i[0]&&(t=i[0])}let{language:a,label:o,kind:s}=t;ln(me.DISABLED,n,r),ln(me.SHOWING,n,[{language:a,label:o,kind:s}])}}},Fn=(e,t)=>e===t?!0:e==null||t==null||typeof e!=typeof t?!1:typeof e==`number`&&Number.isNaN(e)&&Number.isNaN(t)?!0:typeof e==`object`?Array.isArray(e)?In(e,t):Object.entries(e).every(([e,n])=>e in t&&Fn(n,t[e])):!1,In=(e,t)=>{let n=Array.isArray(e),r=Array.isArray(t);return n===r?n||r?e.length===t.length&&e.every((e,n)=>Fn(e,t[n])):!0:!1},Ln=Object.values(w),Rn,zn=Sn().then(e=>(Rn=e,Rn)),Bn=async(...e)=>{await Promise.all(e.filter(e=>e).map(async e=>{if(!(`localName`in e&&e instanceof E.HTMLElement))return;let t=e.localName;if(!t.includes(`-`))return;let n=E.customElements.get(t);n&&e instanceof n||(await E.customElements.whenDefined(t),E.customElements.upgrade(e))}))},Vn=new E.DOMParser,Hn=e=>e&&(Vn.parseFromString(e,`text/html`).body.textContent||e),Un={mediaError:{get(e,t){let{media:n}=e;if(t?.type!==`playing`)return n?.error},mediaEvents:[`emptied`,`error`,`playing`]},mediaErrorCode:{get(e,t){let{media:n}=e;if(t?.type!==`playing`)return n?.error?.code},mediaEvents:[`emptied`,`error`,`playing`]},mediaErrorMessage:{get(e,t){let{media:n}=e;if(t?.type!==`playing`)return n?.error?.message??``},mediaEvents:[`emptied`,`error`,`playing`]},mediaWidth:{get(e){let{media:t}=e;return t?.videoWidth??0},mediaEvents:[`resize`]},mediaHeight:{get(e){let{media:t}=e;return t?.videoHeight??0},mediaEvents:[`resize`]},mediaPaused:{get(e){let{media:t}=e;return t?.paused??!0},set(e,t){var n;let{media:r}=t;r&&(e?r.pause():(n=r.play())==null||n.catch(()=>{}))},mediaEvents:[`play`,`playing`,`pause`,`emptied`]},mediaHasPlayed:{get(e,t){let{media:n}=e;return n?t?t.type===`playing`:!n.paused:!1},mediaEvents:[`playing`,`emptied`]},mediaEnded:{get(e){let{media:t}=e;return t?.ended??!1},mediaEvents:[`seeked`,`ended`,`emptied`]},mediaPlaybackRate:{get(e){let{media:t}=e;return t?.playbackRate??1},set(e,t){let{media:n}=t;n&&Number.isFinite(+e)&&(n.playbackRate=+e)},mediaEvents:[`ratechange`,`loadstart`]},mediaMuted:{get(e){let{media:t}=e;return t?.muted??!1},set(e,t){let{media:n,options:{noMutedPref:r}={}}=t;if(n){n.muted=e;try{let t=E.localStorage.getItem(`media-chrome-pref-muted`)!==null,i=n.hasAttribute(`muted`);if(r){t&&E.localStorage.removeItem(`media-chrome-pref-muted`);return}if(i&&!t)return;E.localStorage.setItem(`media-chrome-pref-muted`,e?`true`:`false`)}catch(e){console.debug(`Error setting muted pref`,e)}}},mediaEvents:[`volumechange`],stateOwnersUpdateHandlers:[(e,t)=>{let{options:{noMutedPref:n}}=t,{media:r}=t;if(!(!r||r.muted||n))try{let n=E.localStorage.getItem(`media-chrome-pref-muted`)===`true`;Un.mediaMuted.set(n,t),e(n)}catch(e){console.debug(`Error getting muted pref`,e)}}]},mediaLoop:{get(e){let{media:t}=e;return t?.loop},set(e,t){let{media:n}=t;n&&(n.loop=e)},mediaEvents:[`medialooprequest`]},mediaVolume:{get(e){let{media:t}=e;return t?.volume??1},set(e,t){let{media:n,options:{noVolumePref:r}={}}=t;if(n){try{e==null?E.localStorage.removeItem(`media-chrome-pref-volume`):!n.hasAttribute(`muted`)&&!r&&E.localStorage.setItem(`media-chrome-pref-volume`,e.toString())}catch(e){console.debug(`Error setting volume pref`,e)}Number.isFinite(+e)&&(n.volume=+e)}},mediaEvents:[`volumechange`],stateOwnersUpdateHandlers:[(e,t)=>{let{options:{noVolumePref:n}}=t;if(!n)try{let{media:n}=t;if(!n)return;let r=E.localStorage.getItem(`media-chrome-pref-volume`);if(r==null)return;Un.mediaVolume.set(+r,t),e(+r)}catch(e){console.debug(`Error getting volume pref`,e)}}]},mediaVolumeLevel:{get(e){let{media:t}=e;return t?.volume===void 0?`high`:t.muted||t.volume===0?`off`:t.volume<.5?`low`:t.volume<.75?`medium`:`high`},mediaEvents:[`volumechange`]},mediaCurrentTime:{get(e){let{media:t}=e;return t?.currentTime??0},set(e,t){let{media:n}=t;!n||!be(e)||(n.currentTime=e)},mediaEvents:[`timeupdate`,`loadedmetadata`]},mediaDuration:{get(e){let{media:t,options:{defaultDuration:n}={}}=e;return n&&(!t||!t.duration||Number.isNaN(t.duration)||!Number.isFinite(t.duration))?n:Number.isFinite(t?.duration)?t.duration:NaN},mediaEvents:[`durationchange`,`loadedmetadata`,`emptied`]},mediaLoading:{get(e){let{media:t}=e;return t?.readyState<3},mediaEvents:[`waiting`,`playing`,`emptied`]},mediaSeekable:{get(e){let{media:t}=e;if(!t?.seekable?.length)return;let n=t.seekable.start(0),r=t.seekable.end(t.seekable.length-1);if(!(!n&&!r))return[Number(n.toFixed(3)),Number(r.toFixed(3))]},mediaEvents:[`loadedmetadata`,`emptied`,`progress`,`seekablechange`]},mediaBuffered:{get(e){let{media:t}=e,n=t?.buffered??[];return Array.from(n).map((e,t)=>[Number(n.start(t).toFixed(3)),Number(n.end(t).toFixed(3))])},mediaEvents:[`progress`,`emptied`]},mediaStreamType:{get(e){let{media:t,options:{defaultStreamType:n}={}}=e,r=[w.LIVE,w.ON_DEMAND].includes(n)?n:void 0;if(!t)return r;let{streamType:i}=t;if(Ln.includes(i))return i===w.UNKNOWN?r:i;let a=t.duration;return a===1/0?w.LIVE:Number.isFinite(a)?w.ON_DEMAND:r},mediaEvents:[`emptied`,`durationchange`,`loadedmetadata`,`streamtypechange`]},mediaTargetLiveWindow:{get(e){let{media:t}=e;if(!t)return NaN;let{targetLiveWindow:n}=t,r=Un.mediaStreamType.get(e);return(n==null||Number.isNaN(n))&&r===w.LIVE?0:n},mediaEvents:[`emptied`,`durationchange`,`loadedmetadata`,`streamtypechange`,`targetlivewindowchange`]},mediaTimeIsLive:{get(e){let{media:t,options:{liveEdgeOffset:n=10}={}}=e;if(!t)return!1;if(typeof t.liveEdgeStart==`number`)return!Number.isNaN(t.liveEdgeStart)&&t.currentTime>=t.liveEdgeStart;if(Un.mediaStreamType.get(e)!==w.LIVE)return!1;let r=t.seekable;if(!r)return!0;if(!r.length)return!1;let i=r.end(r.length-1)-n;return t.currentTime>=i},mediaEvents:[`playing`,`timeupdate`,`progress`,`waiting`,`emptied`]},mediaSubtitlesList:{get(e){return Mn(e).map(({kind:e,label:t,language:n})=>({kind:e,label:t,language:n}))},mediaEvents:[`loadstart`],textTracksEvents:[`addtrack`,`removetrack`]},mediaSubtitlesShowing:{get(e){return Nn(e).map(({kind:e,label:t,language:n})=>({kind:e,label:t,language:n}))},mediaEvents:[`loadstart`],textTracksEvents:[`addtrack`,`removetrack`,`change`],stateOwnersUpdateHandlers:[(e,t)=>{var n,r;let{media:i,options:a}=t;if(!i)return;let o=e=>{a.defaultSubtitles&&(e&&![x.CAPTIONS,x.SUBTITLES].includes(e?.track?.kind)||Pn(t,!0))};return i.addEventListener(`loadstart`,o),(n=i.textTracks)==null||n.addEventListener(`addtrack`,o),(r=i.textTracks)==null||r.addEventListener(`removetrack`,o),()=>{var e,t;i.removeEventListener(`loadstart`,o),(e=i.textTracks)==null||e.removeEventListener(`addtrack`,o),(t=i.textTracks)==null||t.removeEventListener(`removetrack`,o)}}]},mediaChaptersCues:{get(e){let{media:t}=e;if(!t)return[];let[n]=un(t,{kind:x.CHAPTERS});return Array.from(n?.cues??[]).map(({text:e,startTime:t,endTime:n})=>({text:Hn(e),startTime:t,endTime:n}))},mediaEvents:[`loadstart`,`loadedmetadata`],textTracksEvents:[`addtrack`,`removetrack`,`change`],stateOwnersUpdateHandlers:[(e,t)=>{let{media:n}=t;if(!n)return;let r=n.querySelector(`track[kind="chapters"][default][src]`),i=n.shadowRoot?.querySelector(`:is(video,audio) > track[kind="chapters"][default][src]`);return r?.addEventListener(`load`,e),i?.addEventListener(`load`,e),()=>{r?.removeEventListener(`load`,e),i?.removeEventListener(`load`,e)}}]},mediaIsPip:{get(e){let{media:t,documentElement:n}=e;if(!t||!n||!n.pictureInPictureElement)return!1;if(n.pictureInPictureElement===t)return!0;if(n.pictureInPictureElement instanceof HTMLMediaElement)return t.localName?.includes(`-`)?Ze(t,n.pictureInPictureElement):!1;if(n.pictureInPictureElement.localName.includes(`-`)){let e=n.pictureInPictureElement.shadowRoot;for(;e?.pictureInPictureElement;){if(e.pictureInPictureElement===t)return!0;e=e.pictureInPictureElement?.shadowRoot}}return!1},set(e,t){let{media:n}=t;if(n)if(e){if(!D.pictureInPictureEnabled){console.warn(`MediaChrome: Picture-in-picture is not enabled`);return}if(!n.requestPictureInPicture){console.warn(`MediaChrome: The current media does not support picture-in-picture`);return}let e=()=>{console.warn(`MediaChrome: The media is not ready for picture-in-picture. It must have a readyState > 0.`)};n.requestPictureInPicture().catch(t=>{if(t.code===11){if(!n.src){console.warn(`MediaChrome: The media is not ready for picture-in-picture. It must have a src set.`);return}if(n.readyState===0&&n.preload===`none`){let t=()=>{n.removeEventListener(`loadedmetadata`,r),n.preload=`none`},r=()=>{n.requestPictureInPicture().catch(e),t()};n.addEventListener(`loadedmetadata`,r),n.preload=`metadata`,setTimeout(()=>{n.readyState===0&&e(),t()},1e3)}else throw t}else throw t})}else D.pictureInPictureElement&&D.exitPictureInPicture()},mediaEvents:[`enterpictureinpicture`,`leavepictureinpicture`]},mediaRenditionList:{get(e){let{media:t}=e;return[...t?.videoRenditions??[]].map(e=>({...e}))},mediaEvents:[`emptied`,`loadstart`],videoRenditionsEvents:[`addrendition`,`removerendition`]},mediaRenditionSelected:{get(e){let{media:t}=e;return t?.videoRenditions?.[t.videoRenditions?.selectedIndex]?.id},set(e,t){let{media:n}=t;if(!n?.videoRenditions){console.warn(`MediaController: Rendition selection not supported by this media.`);return}let r=e,i=Array.prototype.findIndex.call(n.videoRenditions,e=>e.id==r);n.videoRenditions.selectedIndex!=i&&(n.videoRenditions.selectedIndex=i)},mediaEvents:[`emptied`],videoRenditionsEvents:[`addrendition`,`removerendition`,`change`]},mediaAudioTrackList:{get(e){let{media:t}=e;return[...t?.audioTracks??[]]},mediaEvents:[`emptied`,`loadstart`],audioTracksEvents:[`addtrack`,`removetrack`]},mediaAudioTrackEnabled:{get(e){let{media:t}=e;return[...t?.audioTracks??[]].find(e=>e.enabled)?.id},set(e,t){let{media:n}=t;if(!n?.audioTracks){console.warn(`MediaChrome: Audio track selection not supported by this media.`);return}let r=e;for(let e of n.audioTracks)e.enabled=r==e.id},mediaEvents:[`emptied`],audioTracksEvents:[`addtrack`,`removetrack`,`change`]},mediaIsFullscreen:{get(e){return _n(e)},set(e,t,n){var r;e?(fn(t),n.detail&&!t.media?.inert&&((r=t.media)==null||r.focus())):mn(t)},rootEvents:[`fullscreenchange`,`webkitfullscreenchange`],mediaEvents:[`webkitbeginfullscreen`,`webkitendfullscreen`,`webkitpresentationmodechanged`]},mediaIsCasting:{get(e){let{media:t}=e;return!t?.remote||t.remote?.state===`disconnected`?!1:t.remote.state===`connected`},set(e,t){let{media:n}=t;if(n&&!(e&&n.remote?.state!==`disconnected`)&&!(!e&&n.remote?.state!==`connected`)){if(typeof n.remote.prompt!=`function`){console.warn(`MediaChrome: Casting is not supported in this environment`);return}n.remote.prompt().catch(()=>{})}},remoteEvents:[`connect`,`connecting`,`disconnect`]},mediaIsAirplaying:{get(){return!1},set(e,t){let{media:n}=t;if(n){if(!(n.webkitShowPlaybackTargetPicker&&E.WebKitPlaybackTargetAvailabilityEvent)){console.error(`MediaChrome: received a request to select AirPlay but AirPlay is not supported in this environment`);return}n.webkitShowPlaybackTargetPicker()}},mediaEvents:[`webkitcurrentplaybacktargetiswirelesschanged`]},mediaFullscreenUnavailable:{get(e){let{media:t}=e;if(!On||!Dn(t))return C.UNSUPPORTED}},mediaPipUnavailable:{get(e){let{media:t}=e;if(!kn||!En(t))return C.UNSUPPORTED;if(t?.disablePictureInPicture)return C.UNAVAILABLE}},mediaVolumeUnavailable:{get(e){let{media:t}=e;if(Rn===!1||t?.volume==null)return C.UNSUPPORTED},stateOwnersUpdateHandlers:[e=>{Rn??zn.then(t=>e(t?void 0:C.UNSUPPORTED))}]},mediaCastUnavailable:{get(e,{availability:t=`not-available`}={}){let{media:n}=e;if(!jn||!n?.remote?.state)return C.UNSUPPORTED;if(t!=null&&t!==`available`)return C.UNAVAILABLE},stateOwnersUpdateHandlers:[(e,t)=>{var n;let{media:r}=t;if(r)return r.disableRemotePlayback||r.hasAttribute(`disableremoteplayback`)||(n=r?.remote)==null||n.watchAvailability(t=>{e({availability:t?`available`:`not-available`})}).catch(t=>{t.name===`NotSupportedError`?e({availability:null}):e({availability:`not-available`})}),()=>{var e;(e=r?.remote)==null||e.cancelWatchAvailability().catch(()=>{})}}]},mediaAirplayUnavailable:{get(e,t){if(!An)return C.UNSUPPORTED;if(t?.availability===`not-available`)return C.UNAVAILABLE},mediaEvents:[`webkitplaybacktargetavailabilitychanged`],stateOwnersUpdateHandlers:[(e,t)=>{var n;let{media:r}=t;if(r)return r.disableRemotePlayback||r.hasAttribute(`disableremoteplayback`)||(n=r?.remote)==null||n.watchAvailability(t=>{e({availability:t?`available`:`not-available`})}).catch(t=>{t.name===`NotSupportedError`?e({availability:null}):e({availability:`not-available`})}),()=>{var e;(e=r?.remote)==null||e.cancelWatchAvailability().catch(()=>{})}}]},mediaRenditionUnavailable:{get(e){let{media:t}=e;if(!t?.videoRenditions)return C.UNSUPPORTED;if(!t.videoRenditions?.length)return C.UNAVAILABLE},mediaEvents:[`emptied`,`loadstart`],videoRenditionsEvents:[`addrendition`,`removerendition`]},mediaAudioTrackUnavailable:{get(e){let{media:t}=e;if(!t?.audioTracks)return C.UNSUPPORTED;if((t.audioTracks?.length??0)<=1)return C.UNAVAILABLE},mediaEvents:[`emptied`,`loadstart`],audioTracksEvents:[`addtrack`,`removetrack`]},mediaLang:{get(e){let{options:{mediaLang:t}={}}=e;return t??`en`}}},Wn={[_.MEDIA_PREVIEW_REQUEST](e,t,{detail:n}){let{media:r}=t,i=n??void 0,a,o;if(r&&i!=null){let[e]=un(r,{kind:x.METADATA,label:`thumbnails`}),t=Array.prototype.find.call(e?.cues??[],(e,t,n)=>t===0?e.endTime>i:t===n.length-1?e.startTime<=i:e.startTime<=i&&e.endTime>i);if(t){let e=/'^(?:[a-z]+:)?\/\//i.test(t.text)?void 0:r?.querySelector(`track[label="thumbnails"]`)?.src,n=new URL(t.text,e);o=new URLSearchParams(n.hash).get(`#xywh`).split(`,`).map(e=>+e),a=n.href}}let s=e.mediaDuration.get(t),c=e.mediaChaptersCues.get(t).find((e,t,n)=>t===n.length-1&&s===e.endTime?e.startTime<=i&&e.endTime>=i:e.startTime<=i&&e.endTime>i)?.text;return n!=null&&c==null&&(c=``),{mediaPreviewTime:i,mediaPreviewImage:a,mediaPreviewCoords:o,mediaPreviewChapter:c}},[_.MEDIA_PAUSE_REQUEST](e,t){e.mediaPaused.set(!0,t)},[_.MEDIA_PLAY_REQUEST](e,t){let n=e.mediaStreamType.get(t)===w.LIVE,r=!t.options?.noAutoSeekToLive,i=e.mediaTargetLiveWindow.get(t)>0;if(n&&r&&!i){let n=e.mediaSeekable.get(t)?.[1];if(n){let r=n-(t.options?.seekToLiveOffset??0);e.mediaCurrentTime.set(r,t)}}e.mediaPaused.set(!1,t)},[_.MEDIA_PLAYBACK_RATE_REQUEST](e,t,{detail:n}){let r=n;e.mediaPlaybackRate.set(r,t)},[_.MEDIA_MUTE_REQUEST](e,t){e.mediaMuted.set(!0,t)},[_.MEDIA_UNMUTE_REQUEST](e,t){e.mediaVolume.get(t)||e.mediaVolume.set(.25,t),e.mediaMuted.set(!1,t)},[_.MEDIA_LOOP_REQUEST](e,t,{detail:n}){let r=!!n;return e.mediaLoop.set(r,t),{mediaLoop:r}},[_.MEDIA_VOLUME_REQUEST](e,t,{detail:n}){let r=n;r&&e.mediaMuted.get(t)&&e.mediaMuted.set(!1,t),e.mediaVolume.set(r,t)},[_.MEDIA_SEEK_REQUEST](e,t,{detail:n}){let r=n;e.mediaCurrentTime.set(r,t)},[_.MEDIA_SEEK_TO_LIVE_REQUEST](e,t){let n=e.mediaSeekable.get(t)?.[1];if(Number.isNaN(Number(n)))return;let r=n-(t.options?.seekToLiveOffset??0);e.mediaCurrentTime.set(r,t)},[_.MEDIA_SHOW_SUBTITLES_REQUEST](e,t,{detail:n}){let{options:r}=t,i=Mn(t),a=rn(n),o=a[0]?.language;o&&!r.noSubtitlesLangPref&&E.localStorage.setItem(`media-chrome-pref-subtitles-lang`,o),ln(me.SHOWING,i,a)},[_.MEDIA_DISABLE_SUBTITLES_REQUEST](e,t,{detail:n}){let r=Mn(t),i=n??[];ln(me.DISABLED,r,i)},[_.MEDIA_TOGGLE_SUBTITLES_REQUEST](e,t,{detail:n}){Pn(t,n)},[_.MEDIA_RENDITION_REQUEST](e,t,{detail:n}){let r=n;e.mediaRenditionSelected.set(r,t)},[_.MEDIA_AUDIO_TRACK_REQUEST](e,t,{detail:n}){let r=n;e.mediaAudioTrackEnabled.set(r,t)},[_.MEDIA_ENTER_PIP_REQUEST](e,t){e.mediaIsFullscreen.get(t)&&e.mediaIsFullscreen.set(!1,t),e.mediaIsPip.set(!0,t)},[_.MEDIA_EXIT_PIP_REQUEST](e,t){e.mediaIsPip.set(!1,t)},[_.MEDIA_ENTER_FULLSCREEN_REQUEST](e,t,n){e.mediaIsPip.get(t)&&e.mediaIsPip.set(!1,t),e.mediaIsFullscreen.set(!0,t,n)},[_.MEDIA_EXIT_FULLSCREEN_REQUEST](e,t){e.mediaIsFullscreen.set(!1,t)},[_.MEDIA_ENTER_CAST_REQUEST](e,t){e.mediaIsFullscreen.get(t)&&e.mediaIsFullscreen.set(!1,t),e.mediaIsCasting.set(!0,t)},[_.MEDIA_EXIT_CAST_REQUEST](e,t){e.mediaIsCasting.set(!1,t)},[_.MEDIA_AIRPLAY_REQUEST](e,t){e.mediaIsAirplaying.set(!0,t)}},Gn=({media:e,fullscreenElement:t,documentElement:n,stateMediator:r=Un,requestMap:i=Wn,options:a={},monitorStateOwnersOnlyWithSubscriptions:o=!0})=>{let s=[],c={options:{...a}},l=Object.freeze({mediaPreviewTime:void 0,mediaPreviewImage:void 0,mediaPreviewCoords:void 0,mediaPreviewChapter:void 0}),u=e=>{e!=null&&(Fn(e,l)||(l=Object.freeze({...l,...e}),s.forEach(e=>e(l))))},d=()=>{let e=Object.entries(r).reduce((e,[t,{get:n}])=>(e[t]=n(c),e),{});u(e)},f={},p,m=async(e,t)=>{let n=!!p;if(p={...c,...p??{},...e},n)return;await Bn(...Object.values(e));let i=s.length>0&&t===0&&o,a=c.media!==p.media,l=c.media?.textTracks!==p.media?.textTracks,m=c.media?.videoRenditions!==p.media?.videoRenditions,ee=c.media?.audioTracks!==p.media?.audioTracks,te=c.media?.remote!==p.media?.remote,h=c.documentElement!==p.documentElement,g=!!c.media&&(a||i),ne=!!c.media?.textTracks&&(l||i),re=!!c.media?.videoRenditions&&(m||i),ie=!!c.media?.audioTracks&&(ee||i),ae=!!c.media?.remote&&(te||i),oe=!!c.documentElement&&(h||i),se=g||ne||re||ie||ae||oe,ce=s.length===0&&t===1&&o,le=!!p.media&&(a||ce),ue=!!p.media?.textTracks&&(l||ce),_=!!p.media?.videoRenditions&&(m||ce),v=!!p.media?.audioTracks&&(ee||ce),de=!!p.media?.remote&&(te||ce),fe=!!p.documentElement&&(h||ce),y=le||ue||_||v||de||fe;if(!(se||y)){Object.entries(p).forEach(([e,t])=>{c[e]=t}),d(),p=void 0;return}Object.entries(r).forEach(([e,{get:t,mediaEvents:n=[],textTracksEvents:r=[],videoRenditionsEvents:i=[],audioTracksEvents:a=[],remoteEvents:o=[],rootEvents:s=[],stateOwnersUpdateHandlers:l=[]}])=>{f[e]||(f[e]={});let d=n=>{let r=t(c,n);u({[e]:r})},m;m=f[e].mediaEvents,n.forEach(t=>{m&&g&&(c.media.removeEventListener(t,m),f[e].mediaEvents=void 0),le&&(p.media.addEventListener(t,d),f[e].mediaEvents=d)}),m=f[e].textTracksEvents,r.forEach(t=>{var n,r;m&&ne&&((n=c.media.textTracks)==null||n.removeEventListener(t,m),f[e].textTracksEvents=void 0),ue&&((r=p.media.textTracks)==null||r.addEventListener(t,d),f[e].textTracksEvents=d)}),m=f[e].videoRenditionsEvents,i.forEach(t=>{var n,r;m&&re&&((n=c.media.videoRenditions)==null||n.removeEventListener(t,m),f[e].videoRenditionsEvents=void 0),_&&((r=p.media.videoRenditions)==null||r.addEventListener(t,d),f[e].videoRenditionsEvents=d)}),m=f[e].audioTracksEvents,a.forEach(t=>{var n,r;m&&ie&&((n=c.media.audioTracks)==null||n.removeEventListener(t,m),f[e].audioTracksEvents=void 0),v&&((r=p.media.audioTracks)==null||r.addEventListener(t,d),f[e].audioTracksEvents=d)}),m=f[e].remoteEvents,o.forEach(t=>{var n,r;m&&ae&&((n=c.media.remote)==null||n.removeEventListener(t,m),f[e].remoteEvents=void 0),de&&((r=p.media.remote)==null||r.addEventListener(t,d),f[e].remoteEvents=d)}),m=f[e].rootEvents,s.forEach(t=>{m&&oe&&(c.documentElement.removeEventListener(t,m),f[e].rootEvents=void 0),fe&&(p.documentElement.addEventListener(t,d),f[e].rootEvents=d)});let ee=f[e].stateOwnersUpdateHandlers;if(ee&&se&&(Array.isArray(ee)?ee:[ee]).forEach(e=>{typeof e==`function`&&e()}),y){let t=l.map(e=>e(d,p)).filter(e=>typeof e==`function`);f[e].stateOwnersUpdateHandlers=t.length===1?t[0]:t}else se&&(f[e].stateOwnersUpdateHandlers=void 0)}),Object.entries(p).forEach(([e,t])=>{c[e]=t}),d(),p=void 0};return m({media:e,fullscreenElement:t,documentElement:n,options:a}),{dispatch(e){let{type:t,detail:n}=e;if(i[t]&&l.mediaErrorCode==null){u(i[t](r,c,e));return}t===`mediaelementchangerequest`?m({media:n}):t===`fullscreenelementchangerequest`?m({fullscreenElement:n}):t===`documentelementchangerequest`?m({documentElement:n}):t===`optionschangerequest`&&(Object.entries(n??{}).forEach(([e,t])=>{c.options[e]=t}),d())},getState(){return l},subscribe(e){return m({},s.length+1),s.push(e),e(l),()=>{let t=s.indexOf(e);t>=0&&(m({},s.length-1),s.splice(t,1))}}}},Kn=(e,t,n)=>{if(!t.has(e))throw TypeError(`Cannot `+n)},B=(e,t,n)=>(Kn(e,t,`read from private field`),n?n.call(e):t.get(e)),V=(e,t,n)=>{if(t.has(e))throw TypeError(`Cannot add the same private member more than once`);t instanceof WeakSet?t.add(e):t.set(e,n)},qn=(e,t,n,r)=>(Kn(e,t,`write to private field`),r?r.call(e,n):t.set(e,n),n),Jn=(e,t,n)=>(Kn(e,t,`access private method`),n),Yn,Xn,H,Zn,Qn,$n,er,tr,nr,rr,ir,ar,or,sr,cr,lr=[`ArrowLeft`,`ArrowRight`,`ArrowUp`,`ArrowDown`,`Enter`,` `,`f`,`m`,`k`,`c`,`l`,`j`,`>`,`<`,`p`],ur=10,dr=.025,fr=.25,pr=.25,mr=2,U={DEFAULT_SUBTITLES:`defaultsubtitles`,DEFAULT_STREAM_TYPE:`defaultstreamtype`,DEFAULT_DURATION:`defaultduration`,FULLSCREEN_ELEMENT:`fullscreenelement`,HOTKEYS:`hotkeys`,KEYBOARD_BACKWARD_SEEK_OFFSET:`keyboardbackwardseekoffset`,KEYBOARD_FORWARD_SEEK_OFFSET:`keyboardforwardseekoffset`,KEYBOARD_DOWN_VOLUME_STEP:`keyboarddownvolumestep`,KEYBOARD_UP_VOLUME_STEP:`keyboardupvolumestep`,KEYS_USED:`keysused`,LANG:`lang`,LOOP:`loop`,LIVE_EDGE_OFFSET:`liveedgeoffset`,NO_AUTO_SEEK_TO_LIVE:`noautoseektolive`,NO_DEFAULT_STORE:`nodefaultstore`,NO_HOTKEYS:`nohotkeys`,NO_MUTED_PREF:`nomutedpref`,NO_SUBTITLES_LANG_PREF:`nosubtitleslangpref`,NO_VOLUME_PREF:`novolumepref`,SEEK_TO_LIVE_OFFSET:`seektoliveoffset`},hr=class extends Ut{constructor(){super(),V(this,nr),V(this,ar),V(this,sr),this.mediaStateReceivers=[],this.associatedElementSubscriptions=new Map,V(this,Yn,new $t(this,U.HOTKEYS)),V(this,Xn,void 0),V(this,H,void 0),V(this,Zn,null),V(this,Qn,void 0),V(this,$n,void 0),V(this,er,e=>{var t;(t=B(this,H))==null||t.dispatch(e)}),V(this,tr,void 0),V(this,ir,e=>{let{key:t,shiftKey:n}=e;if(!(n&&(t===`/`||t===`?`)||lr.includes(t))){this.removeEventListener(`keyup`,B(this,ir));return}this.keyboardShortcutHandler(e)}),this.associateElement(this);let e={};qn(this,Qn,t=>{Object.entries(t).forEach(([t,n])=>{if(t in e&&e[t]===n)return;this.propagateMediaState(t,n);let r=t.toLowerCase(),i=new E.CustomEvent(pe[r],{composed:!0,detail:n});this.dispatchEvent(i)}),e=t})}static get observedAttributes(){return super.observedAttributes.concat(U.NO_HOTKEYS,U.HOTKEYS,U.DEFAULT_STREAM_TYPE,U.DEFAULT_SUBTITLES,U.DEFAULT_DURATION,U.NO_MUTED_PREF,U.NO_VOLUME_PREF,U.LANG,U.LOOP,U.LIVE_EDGE_OFFSET,U.SEEK_TO_LIVE_OFFSET,U.NO_AUTO_SEEK_TO_LIVE)}get mediaStore(){return B(this,H)}set mediaStore(e){var t;if(B(this,H)&&((t=B(this,$n))==null||t.call(this),qn(this,$n,void 0)),qn(this,H,e),!B(this,H)&&!this.hasAttribute(U.NO_DEFAULT_STORE)){Jn(this,nr,rr).call(this);return}qn(this,$n,B(this,H)?.subscribe(B(this,Qn)))}get fullscreenElement(){return B(this,Xn)??this}set fullscreenElement(e){var t;this.hasAttribute(U.FULLSCREEN_ELEMENT)&&this.removeAttribute(U.FULLSCREEN_ELEMENT),qn(this,Xn,e),(t=B(this,H))==null||t.dispatch({type:`fullscreenelementchangerequest`,detail:this.fullscreenElement})}get defaultSubtitles(){return j(this,U.DEFAULT_SUBTITLES)}set defaultSubtitles(e){M(this,U.DEFAULT_SUBTITLES,e)}get defaultStreamType(){return N(this,U.DEFAULT_STREAM_TYPE)}set defaultStreamType(e){P(this,U.DEFAULT_STREAM_TYPE,e)}get defaultDuration(){return k(this,U.DEFAULT_DURATION)}set defaultDuration(e){A(this,U.DEFAULT_DURATION,e)}get noHotkeys(){return j(this,U.NO_HOTKEYS)}set noHotkeys(e){M(this,U.NO_HOTKEYS,e)}get keysUsed(){return N(this,U.KEYS_USED)}set keysUsed(e){P(this,U.KEYS_USED,e)}get liveEdgeOffset(){return k(this,U.LIVE_EDGE_OFFSET)}set liveEdgeOffset(e){A(this,U.LIVE_EDGE_OFFSET,e)}get noAutoSeekToLive(){return j(this,U.NO_AUTO_SEEK_TO_LIVE)}set noAutoSeekToLive(e){M(this,U.NO_AUTO_SEEK_TO_LIVE,e)}get noVolumePref(){return j(this,U.NO_VOLUME_PREF)}set noVolumePref(e){M(this,U.NO_VOLUME_PREF,e)}get noMutedPref(){return j(this,U.NO_MUTED_PREF)}set noMutedPref(e){M(this,U.NO_MUTED_PREF,e)}get noSubtitlesLangPref(){return j(this,U.NO_SUBTITLES_LANG_PREF)}set noSubtitlesLangPref(e){M(this,U.NO_SUBTITLES_LANG_PREF,e)}get noDefaultStore(){return j(this,U.NO_DEFAULT_STORE)}set noDefaultStore(e){M(this,U.NO_DEFAULT_STORE,e)}get resolvedLang(){return De()}attributeChangedCallback(e,t,n){var r,i,a,o,s,c,l,u,d,f;if(super.attributeChangedCallback(e,t,n),e===U.NO_HOTKEYS)n!==t&&n===``?(this.hasAttribute(U.HOTKEYS)&&console.warn("Media Chrome: Both `hotkeys` and `nohotkeys` have been set. All hotkeys will be disabled."),this.disableHotkeys()):n!==t&&n===null&&this.enableHotkeys();else if(e===U.HOTKEYS)B(this,Yn).value=n;else if(e===U.DEFAULT_SUBTITLES&&n!==t)(r=B(this,H))==null||r.dispatch({type:`optionschangerequest`,detail:{defaultSubtitles:this.hasAttribute(U.DEFAULT_SUBTITLES)}});else if(e===U.DEFAULT_STREAM_TYPE)(i=B(this,H))==null||i.dispatch({type:`optionschangerequest`,detail:{defaultStreamType:this.getAttribute(U.DEFAULT_STREAM_TYPE)??void 0}});else if(e===U.LIVE_EDGE_OFFSET&&n!==t)(a=B(this,H))==null||a.dispatch({type:`optionschangerequest`,detail:{liveEdgeOffset:this.hasAttribute(U.LIVE_EDGE_OFFSET)?+this.getAttribute(U.LIVE_EDGE_OFFSET):void 0,seekToLiveOffset:this.hasAttribute(U.SEEK_TO_LIVE_OFFSET)?+this.getAttribute(U.SEEK_TO_LIVE_OFFSET):this.hasAttribute(U.LIVE_EDGE_OFFSET)?+this.getAttribute(U.LIVE_EDGE_OFFSET):void 0}});else if(e===U.SEEK_TO_LIVE_OFFSET&&n!==t)(o=B(this,H))==null||o.dispatch({type:`optionschangerequest`,detail:{seekToLiveOffset:this.hasAttribute(U.SEEK_TO_LIVE_OFFSET)?+this.getAttribute(U.SEEK_TO_LIVE_OFFSET):this.hasAttribute(U.LIVE_EDGE_OFFSET)?+this.getAttribute(U.LIVE_EDGE_OFFSET):void 0}});else if(e===U.NO_AUTO_SEEK_TO_LIVE)(s=B(this,H))==null||s.dispatch({type:`optionschangerequest`,detail:{noAutoSeekToLive:this.hasAttribute(U.NO_AUTO_SEEK_TO_LIVE)}});else if(e===U.FULLSCREEN_ELEMENT){let e=n?this.getRootNode()?.getElementById(n):void 0;qn(this,Xn,e),(c=B(this,H))==null||c.dispatch({type:`fullscreenelementchangerequest`,detail:this.fullscreenElement})}else e===U.LANG&&n!==t?(we(n),(l=B(this,H))==null||l.dispatch({type:`optionschangerequest`,detail:{mediaLang:n}})):e===U.LOOP&&n!==t?(u=B(this,H))==null||u.dispatch({type:_.MEDIA_LOOP_REQUEST,detail:n!=null}):e===U.NO_VOLUME_PREF&&n!==t?(d=B(this,H))==null||d.dispatch({type:`optionschangerequest`,detail:{noVolumePref:this.hasAttribute(U.NO_VOLUME_PREF)}}):e===U.NO_MUTED_PREF&&n!==t&&((f=B(this,H))==null||f.dispatch({type:`optionschangerequest`,detail:{noMutedPref:this.hasAttribute(U.NO_MUTED_PREF)}}))}connectedCallback(){var e,t;this.associateElement(this),!B(this,H)&&!this.hasAttribute(U.NO_DEFAULT_STORE)&&Jn(this,nr,rr).call(this),(e=B(this,H))==null||e.dispatch({type:`documentelementchangerequest`,detail:D}),(t=B(this,H))==null||t.dispatch({type:`fullscreenelementchangerequest`,detail:this.fullscreenElement}),super.connectedCallback(),B(this,H)&&!B(this,$n)&&qn(this,$n,B(this,H)?.subscribe(B(this,Qn))),B(this,tr)!==void 0&&B(this,H)&&this.media&&setTimeout(()=>{var e;this.media?.textTracks?.length&&((e=B(this,H))==null||e.dispatch({type:_.MEDIA_TOGGLE_SUBTITLES_REQUEST,detail:B(this,tr)}))},0),this.hasAttribute(U.NO_HOTKEYS)?this.disableHotkeys():this.enableHotkeys()}disconnectedCallback(){var e,t,n,r,i;if((e=super.disconnectedCallback)==null||e.call(this),this.disableHotkeys(),B(this,H)){let e=B(this,H).getState();qn(this,tr,!!e.mediaSubtitlesShowing?.length),(t=B(this,H))==null||t.dispatch({type:`fullscreenelementchangerequest`,detail:void 0}),(n=B(this,H))==null||n.dispatch({type:`documentelementchangerequest`,detail:void 0}),(r=B(this,H))==null||r.dispatch({type:_.MEDIA_TOGGLE_SUBTITLES_REQUEST,detail:!1})}B(this,$n)&&((i=B(this,$n))==null||i.call(this),qn(this,$n,void 0)),this.unassociateElement(this),B(this,Zn)&&(B(this,Zn).remove(),qn(this,Zn,null))}mediaSetCallback(e){var t;super.mediaSetCallback(e),(t=B(this,H))==null||t.dispatch({type:`mediaelementchangerequest`,detail:e}),e.hasAttribute(`tabindex`)||(e.tabIndex=-1)}mediaUnsetCallback(e){var t;super.mediaUnsetCallback(e),(t=B(this,H))==null||t.dispatch({type:`mediaelementchangerequest`,detail:void 0})}propagateMediaState(e,t){Er(this.mediaStateReceivers,e,t)}associateElement(e){if(!e)return;let{associatedElementSubscriptions:t}=this;if(t.has(e))return;let n=Dr(e,this.registerMediaStateReceiver.bind(this),this.unregisterMediaStateReceiver.bind(this));Object.values(_).forEach(t=>{e.addEventListener(t,B(this,er))}),t.set(e,n)}unassociateElement(e){if(!e)return;let{associatedElementSubscriptions:t}=this;t.has(e)&&(t.get(e)(),t.delete(e),Object.values(_).forEach(t=>{e.removeEventListener(t,B(this,er))}))}registerMediaStateReceiver(e){if(!e)return;let t=this.mediaStateReceivers;t.indexOf(e)>-1||(t.push(e),B(this,H)&&Object.entries(B(this,H).getState()).forEach(([t,n])=>{Er([e],t,n)}))}unregisterMediaStateReceiver(e){let t=this.mediaStateReceivers,n=t.indexOf(e);n<0||t.splice(n,1)}enableHotkeys(){this.addEventListener(`keydown`,Jn(this,ar,or))}disableHotkeys(){this.removeEventListener(`keydown`,Jn(this,ar,or)),this.removeEventListener(`keyup`,B(this,ir))}get hotkeys(){return B(this,Yn)}set hotkeys(e){P(this,U.HOTKEYS,e)}keyboardShortcutHandler(e){let t=e.target;if((t.getAttribute(U.KEYS_USED)?.split(` `)??t?.keysUsed??[]).map(e=>e===`Space`?` `:e).filter(Boolean).includes(e.key))return;let n,r,i;if(!B(this,Yn).contains(`no${e.key.toLowerCase()}`)&&!(e.key===` `&&B(this,Yn).contains(`nospace`))&&!(e.shiftKey&&(e.key===`/`||e.key===`?`)&&B(this,Yn).contains(`noshift+/`)))switch(e.key){case` `:case`k`:n=B(this,H).getState().mediaPaused?_.MEDIA_PLAY_REQUEST:_.MEDIA_PAUSE_REQUEST,this.dispatchEvent(new E.CustomEvent(n,{composed:!0,bubbles:!0}));break;case`m`:n=this.mediaStore.getState().mediaVolumeLevel===`off`?_.MEDIA_UNMUTE_REQUEST:_.MEDIA_MUTE_REQUEST,this.dispatchEvent(new E.CustomEvent(n,{composed:!0,bubbles:!0}));break;case`f`:n=this.mediaStore.getState().mediaIsFullscreen?_.MEDIA_EXIT_FULLSCREEN_REQUEST:_.MEDIA_ENTER_FULLSCREEN_REQUEST,this.dispatchEvent(new E.CustomEvent(n,{composed:!0,bubbles:!0}));break;case`c`:this.dispatchEvent(new E.CustomEvent(_.MEDIA_TOGGLE_SUBTITLES_REQUEST,{composed:!0,bubbles:!0}));break;case`ArrowLeft`:case`j`:{let e=this.hasAttribute(U.KEYBOARD_BACKWARD_SEEK_OFFSET)?+this.getAttribute(U.KEYBOARD_BACKWARD_SEEK_OFFSET):ur;r=Math.max((this.mediaStore.getState().mediaCurrentTime??0)-e,0),i=new E.CustomEvent(_.MEDIA_SEEK_REQUEST,{composed:!0,bubbles:!0,detail:r}),this.dispatchEvent(i);break}case`ArrowRight`:case`l`:{let e=this.hasAttribute(U.KEYBOARD_FORWARD_SEEK_OFFSET)?+this.getAttribute(U.KEYBOARD_FORWARD_SEEK_OFFSET):ur;r=Math.max((this.mediaStore.getState().mediaCurrentTime??0)+e,0),i=new E.CustomEvent(_.MEDIA_SEEK_REQUEST,{composed:!0,bubbles:!0,detail:r}),this.dispatchEvent(i);break}case`ArrowUp`:{let e=this.hasAttribute(U.KEYBOARD_UP_VOLUME_STEP)?+this.getAttribute(U.KEYBOARD_UP_VOLUME_STEP):dr;r=Math.min((this.mediaStore.getState().mediaVolume??1)+e,1),i=new E.CustomEvent(_.MEDIA_VOLUME_REQUEST,{composed:!0,bubbles:!0,detail:r}),this.dispatchEvent(i);break}case`ArrowDown`:{let e=this.hasAttribute(U.KEYBOARD_DOWN_VOLUME_STEP)?+this.getAttribute(U.KEYBOARD_DOWN_VOLUME_STEP):dr;r=Math.max((this.mediaStore.getState().mediaVolume??1)-e,0),i=new E.CustomEvent(_.MEDIA_VOLUME_REQUEST,{composed:!0,bubbles:!0,detail:r}),this.dispatchEvent(i);break}case`<`:{let e=this.mediaStore.getState().mediaPlaybackRate??1;r=Math.max(e-fr,pr).toFixed(2),i=new E.CustomEvent(_.MEDIA_PLAYBACK_RATE_REQUEST,{composed:!0,bubbles:!0,detail:r}),this.dispatchEvent(i);break}case`>`:{let e=this.mediaStore.getState().mediaPlaybackRate??1;r=Math.min(e+fr,mr).toFixed(2),i=new E.CustomEvent(_.MEDIA_PLAYBACK_RATE_REQUEST,{composed:!0,bubbles:!0,detail:r}),this.dispatchEvent(i);break}case`/`:case`?`:e.shiftKey&&Jn(this,sr,cr).call(this);break;case`p`:n=this.mediaStore.getState().mediaIsPip?_.MEDIA_EXIT_PIP_REQUEST:_.MEDIA_ENTER_PIP_REQUEST,i=new E.CustomEvent(n,{composed:!0,bubbles:!0}),this.dispatchEvent(i)}}};Yn=new WeakMap,Xn=new WeakMap,H=new WeakMap,Zn=new WeakMap,Qn=new WeakMap,$n=new WeakMap,er=new WeakMap,tr=new WeakMap,nr=new WeakSet,rr=function(){this.mediaStore=Gn({media:this.media,fullscreenElement:this.fullscreenElement,options:{defaultSubtitles:this.hasAttribute(U.DEFAULT_SUBTITLES),defaultDuration:this.hasAttribute(U.DEFAULT_DURATION)?+this.getAttribute(U.DEFAULT_DURATION):void 0,defaultStreamType:this.getAttribute(U.DEFAULT_STREAM_TYPE)??void 0,liveEdgeOffset:this.hasAttribute(U.LIVE_EDGE_OFFSET)?+this.getAttribute(U.LIVE_EDGE_OFFSET):void 0,seekToLiveOffset:this.hasAttribute(U.SEEK_TO_LIVE_OFFSET)?+this.getAttribute(U.SEEK_TO_LIVE_OFFSET):this.hasAttribute(U.LIVE_EDGE_OFFSET)?+this.getAttribute(U.LIVE_EDGE_OFFSET):void 0,noAutoSeekToLive:this.hasAttribute(U.NO_AUTO_SEEK_TO_LIVE),noVolumePref:this.hasAttribute(U.NO_VOLUME_PREF),noMutedPref:this.hasAttribute(U.NO_MUTED_PREF),noSubtitlesLangPref:this.hasAttribute(U.NO_SUBTITLES_LANG_PREF)}})},ir=new WeakMap,ar=new WeakSet,or=function(e){let{metaKey:t,altKey:n,key:r,shiftKey:i}=e,a=i&&(r===`/`||r===`?`);if(a&&B(this,Zn)?.open){this.removeEventListener(`keyup`,B(this,ir));return}if(t||n||!a&&!lr.includes(r)){this.removeEventListener(`keyup`,B(this,ir));return}let o=e.target,s=o instanceof HTMLElement&&(o.tagName.toLowerCase()===`media-volume-range`||o.tagName.toLowerCase()===`media-time-range`);[` `,`ArrowLeft`,`ArrowRight`,`ArrowUp`,`ArrowDown`].includes(r)&&!(B(this,Yn).contains(`no${r.toLowerCase()}`)||r===` `&&B(this,Yn).contains(`nospace`))&&!s&&e.preventDefault(),this.addEventListener(`keyup`,B(this,ir),{once:!0})},sr=new WeakSet,cr=function(){B(this,Zn)||(qn(this,Zn,D.createElement(`media-keyboard-shortcuts-dialog`)),this.appendChild(B(this,Zn))),B(this,Zn).open=!0};var gr=Object.values(y),_r=Object.values(de),vr=e=>{var t;let{observedAttributes:n}=e.constructor;!n&&e.nodeName?.includes(`-`)&&(E.customElements.upgrade(e),{observedAttributes:n}=e.constructor);let r=((t=(e?.getAttribute)?.call(e,v.MEDIA_CHROME_ATTRIBUTES))?.split)?.call(t,/\s+/);return Array.isArray(n||r)?(n||r).filter(e=>gr.includes(e)):[]},yr=e=>(e.nodeName?.includes(`-`)&&E.customElements.get(e.nodeName?.toLowerCase())&&!(e instanceof E.customElements.get(e.nodeName.toLowerCase()))&&E.customElements.upgrade(e),_r.some(t=>t in e)),br=e=>yr(e)||!!vr(e).length,xr=e=>(e?.join)?.call(e,`:`),Sr={[y.MEDIA_SUBTITLES_LIST]:on,[y.MEDIA_SUBTITLES_SHOWING]:on,[y.MEDIA_SEEKABLE]:xr,[y.MEDIA_BUFFERED]:e=>e?.map(xr).join(` `),[y.MEDIA_PREVIEW_COORDS]:e=>e?.join(` `),[y.MEDIA_RENDITION_LIST]:ge,[y.MEDIA_AUDIO_TRACK_LIST]:ve},Cr=async(e,t,n)=>{if(e.isConnected||await xe(0),typeof n==`boolean`||n==null)return M(e,t,n);if(typeof n==`number`)return A(e,t,n);if(typeof n==`string`)return P(e,t,n);if(Array.isArray(n)&&!n.length)return e.removeAttribute(t);let r=Sr[t]?.call(Sr,n)??n;return e.setAttribute(t,r)},wr=e=>!!e.closest?.call(e,`*[slot="media"]`),Tr=(e,t)=>{if(wr(e))return;let n=(e,t)=>{br(e)&&t(e);let{children:n=[]}=e??{},r=e?.shadowRoot?.children??[];[...n,...r].forEach(e=>Tr(e,t))},r=e?.nodeName.toLowerCase();if(r.includes(`-`)&&!br(e)){E.customElements.whenDefined(r).then(()=>{n(e,t)});return}n(e,t)},Er=(e,t,n)=>{e.forEach(e=>{if(t in e){e[t]=n;return}let r=vr(e),i=t.toLowerCase();r.includes(i)&&Cr(e,i,n)})},Dr=(e,t,n)=>{Tr(e,t);let r=e=>{t(e?.composedPath()[0]??e.target)},i=e=>{n(e?.composedPath()[0]??e.target)};e.addEventListener(_.REGISTER_MEDIA_STATE_RECEIVER,r),e.addEventListener(_.UNREGISTER_MEDIA_STATE_RECEIVER,i);let a=e=>{e.forEach(e=>{let{addedNodes:r=[],removedNodes:i=[],type:a,target:o,attributeName:s}=e;a===`childList`?(Array.prototype.forEach.call(r,e=>Tr(e,t)),Array.prototype.forEach.call(i,e=>Tr(e,n))):a===`attributes`&&s===v.MEDIA_CHROME_ATTRIBUTES&&(br(o)?t(o):n(o))})},o=[],s=e=>{let r=e.target;r.name!==`media`&&(o.forEach(e=>Tr(e,n)),o=[...r.assignedElements({flatten:!0})],o.forEach(e=>Tr(e,t)))};e.addEventListener(`slotchange`,s);let c=new MutationObserver(a);return c.observe(e,{childList:!0,attributes:!0,subtree:!0}),()=>{Tr(e,n),e.removeEventListener(`slotchange`,s),c.disconnect(),e.removeEventListener(_.REGISTER_MEDIA_STATE_RECEIVER,r),e.removeEventListener(_.UNREGISTER_MEDIA_STATE_RECEIVER,i)}};E.customElements.get(`media-controller`)||E.customElements.define(`media-controller`,hr);var Or={PLACEMENT:`placement`,BOUNDS:`bounds`};function kr(e){return`
    <style>
      :host {
        --_tooltip-background-color: var(--media-tooltip-background-color, var(--media-secondary-color, rgba(20, 20, 30, .7)));
        --_tooltip-background: var(--media-tooltip-background, var(--_tooltip-background-color));
        --_tooltip-arrow-half-width: calc(var(--media-tooltip-arrow-width, 12px) / 2);
        --_tooltip-arrow-height: var(--media-tooltip-arrow-height, 5px);
        --_tooltip-arrow-background: var(--media-tooltip-arrow-color, var(--_tooltip-background-color));
        position: relative;
        pointer-events: none;
        display: var(--media-tooltip-display, inline-flex);
        justify-content: center;
        align-items: center;
        box-sizing: border-box;
        z-index: var(--media-tooltip-z-index, 1);
        background: var(--_tooltip-background);
        color: var(--media-text-color, var(--media-primary-color, rgb(238 238 238)));
        font: var(--media-font,
          var(--media-font-weight, 400)
          var(--media-font-size, 13px) /
          var(--media-text-content-height, var(--media-control-height, 18px))
          var(--media-font-family, helvetica neue, segoe ui, roboto, arial, sans-serif));
        padding: var(--media-tooltip-padding, .35em .7em);
        border: var(--media-tooltip-border, none);
        border-radius: var(--media-tooltip-border-radius, 5px);
        filter: var(--media-tooltip-filter, drop-shadow(0 0 4px rgba(0, 0, 0, .2)));
        white-space: var(--media-tooltip-white-space, nowrap);
      }

      :host([hidden]) {
        display: none;
      }

      img, svg {
        display: inline-block;
      }

      #arrow {
        position: absolute;
        width: 0px;
        height: 0px;
        border-style: solid;
        display: var(--media-tooltip-arrow-display, block);
      }

      :host(:not([placement])),
      :host([placement="top"]) {
        position: absolute;
        bottom: calc(100% + var(--media-tooltip-distance, 12px));
        left: 50%;
        transform: translate(calc(-50% - var(--media-tooltip-offset-x, 0px)), 0);
      }
      :host(:not([placement])) #arrow,
      :host([placement="top"]) #arrow {
        top: 100%;
        left: 50%;
        border-width: var(--_tooltip-arrow-height) var(--_tooltip-arrow-half-width) 0 var(--_tooltip-arrow-half-width);
        border-color: var(--_tooltip-arrow-background) transparent transparent transparent;
        transform: translate(calc(-50% + var(--media-tooltip-offset-x, 0px)), 0);
      }

      :host([placement="right"]) {
        position: absolute;
        left: calc(100% + var(--media-tooltip-distance, 12px));
        top: 50%;
        transform: translate(0, -50%);
      }
      :host([placement="right"]) #arrow {
        top: 50%;
        right: 100%;
        border-width: var(--_tooltip-arrow-half-width) var(--_tooltip-arrow-height) var(--_tooltip-arrow-half-width) 0;
        border-color: transparent var(--_tooltip-arrow-background) transparent transparent;
        transform: translate(0, -50%);
      }

      :host([placement="bottom"]) {
        position: absolute;
        top: calc(100% + var(--media-tooltip-distance, 12px));
        left: 50%;
        transform: translate(calc(-50% - var(--media-tooltip-offset-x, 0px)), 0);
      }
      :host([placement="bottom"]) #arrow {
        bottom: 100%;
        left: 50%;
        border-width: 0 var(--_tooltip-arrow-half-width) var(--_tooltip-arrow-height) var(--_tooltip-arrow-half-width);
        border-color: transparent transparent var(--_tooltip-arrow-background) transparent;
        transform: translate(calc(-50% + var(--media-tooltip-offset-x, 0px)), 0);
      }

      :host([placement="left"]) {
        position: absolute;
        right: calc(100% + var(--media-tooltip-distance, 12px));
        top: 50%;
        transform: translate(0, -50%);
      }
      :host([placement="left"]) #arrow {
        top: 50%;
        left: 100%;
        border-width: var(--_tooltip-arrow-half-width) 0 var(--_tooltip-arrow-half-width) var(--_tooltip-arrow-height);
        border-color: transparent transparent transparent var(--_tooltip-arrow-background);
        transform: translate(0, -50%);
      }
      
      :host([placement="none"]) #arrow {
        display: none;
      }
    </style>
    <slot></slot>
    <div id="arrow"></div>
  `}var Ar=class extends E.HTMLElement{constructor(){if(super(),this.updateXOffset=()=>{if(!tt(this,{checkOpacity:!1,checkVisibilityCSS:!1}))return;let e=this.placement;if(e===`left`||e===`right`){this.style.removeProperty(`--media-tooltip-offset-x`);return}let t=getComputedStyle(this),n=Qe(this,`#`+this.bounds)??Ke(this);if(!n)return;let{x:r,width:i}=n.getBoundingClientRect(),{x:a,width:o}=this.getBoundingClientRect(),s=a+o,c=r+i,l=t.getPropertyValue(`--media-tooltip-offset-x`),u=l?parseFloat(l.replace(`px`,``)):0,d=t.getPropertyValue(`--media-tooltip-container-margin`),f=d?parseFloat(d.replace(`px`,``)):0,p=a-r+u-f,m=s-c+u+f;if(p<0){this.style.setProperty(`--media-tooltip-offset-x`,`${p}px`);return}if(m>0){this.style.setProperty(`--media-tooltip-offset-x`,`${m}px`);return}this.style.removeProperty(`--media-tooltip-offset-x`)},!this.shadowRoot){this.attachShadow(this.constructor.shadowRootOptions);let e=Ge(this.attributes);this.shadowRoot.innerHTML=this.constructor.getTemplateHTML(e)}if(this.arrowEl=this.shadowRoot.querySelector(`#arrow`),Object.prototype.hasOwnProperty.call(this,`placement`)){let e=this.placement;delete this.placement,this.placement=e}}static get observedAttributes(){return[Or.PLACEMENT,Or.BOUNDS]}get placement(){return N(this,Or.PLACEMENT)}set placement(e){P(this,Or.PLACEMENT,e)}get bounds(){return N(this,Or.BOUNDS)}set bounds(e){P(this,Or.BOUNDS,e)}};Ar.shadowRootOptions={mode:`open`},Ar.getTemplateHTML=kr,E.customElements.get(`media-tooltip`)||E.customElements.define(`media-tooltip`,Ar);var jr=Ar,Mr=(e,t,n)=>{if(!t.has(e))throw TypeError(`Cannot `+n)},W=(e,t,n)=>(Mr(e,t,`read from private field`),n?n.call(e):t.get(e)),Nr=(e,t,n)=>{if(t.has(e))throw TypeError(`Cannot add the same private member more than once`);t instanceof WeakSet?t.add(e):t.set(e,n)},Pr=(e,t,n,r)=>(Mr(e,t,`write to private field`),r?r.call(e,n):t.set(e,n),n),Fr=(e,t,n)=>(Mr(e,t,`access private method`),n),Ir,Lr,Rr,zr,Br,Vr,Hr,Ur={TOOLTIP_PLACEMENT:`tooltipplacement`,DISABLED:`disabled`,NO_TOOLTIP:`notooltip`};function Wr(e,t={}){return`
    <style>
      :host {
        position: relative;
        font: var(--media-font,
          var(--media-font-weight, bold)
          var(--media-font-size, 14px) /
          var(--media-text-content-height, var(--media-control-height, 24px))
          var(--media-font-family, helvetica neue, segoe ui, roboto, arial, sans-serif));
        color: var(--media-text-color, var(--media-primary-color, rgb(238 238 238)));
        background: var(--media-control-background, var(--media-secondary-color, rgb(20 20 30 / .7)));
        padding: var(--media-button-padding, var(--media-control-padding, 10px));
        justify-content: var(--media-button-justify-content, center);
        display: inline-flex;
        align-items: center;
        vertical-align: middle;
        box-sizing: border-box;
        transition: background .15s linear;
        pointer-events: auto;
        cursor: var(--media-cursor, pointer);
        -webkit-tap-highlight-color: transparent;
      }

      
      :host(:focus-visible) {
        box-shadow: var(--media-focus-box-shadow, inset 0 0 0 2px rgb(27 127 204 / .9));
        outline: 0;
      }
      
      :host(:where(:focus)) {
        box-shadow: none;
        outline: 0;
      }

      :host(:hover) {
        background: var(--media-control-hover-background, rgba(50 50 70 / .7));
      }

      slot[name="icon"] {
        display: inline-flex;
        align-items: center;
      }

      svg, img, ::slotted(svg), ::slotted(img) {
        width: var(--media-button-icon-width);
        height: var(--media-button-icon-height, var(--media-control-height, 24px));
        transform: var(--media-button-icon-transform);
        transition: var(--media-button-icon-transition);
        fill: var(--media-icon-color, var(--media-primary-color, rgb(238 238 238)));
        vertical-align: middle;
        max-width: 100%;
        max-height: 100%;
        min-width: 100%;
      }

      media-tooltip {
        
        max-width: 0;
        overflow-x: clip;
        opacity: 0;
        transition: opacity .3s, max-width 0s 9s;
      }

      :host(:hover) media-tooltip,
      :host(:focus-visible) media-tooltip {
        max-width: 100vw;
        opacity: 1;
        transition: opacity .3s;
      }

      :host([notooltip]) slot[name="tooltip"] {
        display: none;
      }
    </style>

    ${this.getSlotTemplateHTML(e,t)}

    <slot name="tooltip">
      <media-tooltip part="tooltip" aria-hidden="true">
        <template shadowrootmode="${jr.shadowRootOptions.mode}">
          ${jr.getTemplateHTML({})}
        </template>
        <slot name="tooltip-content">
          ${this.getTooltipContentHTML(e)}
        </slot>
      </media-tooltip>
    </slot>
  `}function Gr(e,t){return`
    <slot></slot>
  `}function Kr(){return``}var G=class extends E.HTMLElement{constructor(){if(super(),Nr(this,Vr),Nr(this,Ir,void 0),this.preventClick=!1,this.tooltipEl=null,Nr(this,Lr,e=>{this.preventClick||this.handleClick(e),setTimeout(W(this,Rr),0)}),Nr(this,Rr,()=>{var e,t;(t=(e=this.tooltipEl)?.updateXOffset)==null||t.call(e)}),Nr(this,zr,e=>{let{key:t}=e;if(!this.keysUsed.includes(t)){this.removeEventListener(`keyup`,W(this,zr));return}this.preventClick||this.handleClick(e)}),Nr(this,Br,e=>{let{metaKey:t,altKey:n,key:r}=e;if(t||n||!this.keysUsed.includes(r)){this.removeEventListener(`keyup`,W(this,zr));return}this.addEventListener(`keyup`,W(this,zr),{once:!0})}),!this.shadowRoot){this.attachShadow(this.constructor.shadowRootOptions);let e=Ge(this.attributes),t=this.constructor.getTemplateHTML(e);this.shadowRoot.setHTMLUnsafe?this.shadowRoot.setHTMLUnsafe(t):this.shadowRoot.innerHTML=t}this.tooltipEl=this.shadowRoot.querySelector(`media-tooltip`)}static get observedAttributes(){return[`disabled`,Ur.TOOLTIP_PLACEMENT,v.MEDIA_CONTROLLER,y.MEDIA_LANG]}enable(){this.addEventListener(`click`,W(this,Lr)),this.addEventListener(`keydown`,W(this,Br)),this.tabIndex=0}disable(){this.removeEventListener(`click`,W(this,Lr)),this.removeEventListener(`keydown`,W(this,Br)),this.removeEventListener(`keyup`,W(this,zr)),this.tabIndex=-1}attributeChangedCallback(e,t,n){var r,i,a,o;e===v.MEDIA_CONTROLLER?(t&&((i=(r=W(this,Ir))?.unassociateElement)==null||i.call(r,this),Pr(this,Ir,null)),n&&this.isConnected&&(Pr(this,Ir,this.getRootNode()?.getElementById(n)),(o=(a=W(this,Ir))?.associateElement)==null||o.call(a,this))):e===`disabled`&&n!==t?n==null?this.enable():this.disable():e===Ur.TOOLTIP_PLACEMENT&&this.tooltipEl&&n!==t?this.tooltipEl.placement=n:e===y.MEDIA_LANG&&(this.shadowRoot.querySelector(`slot[name="tooltip-content"]`).innerHTML=this.constructor.getTooltipContentHTML()),W(this,Rr).call(this)}connectedCallback(){var e,t;let{style:n}=O(this.shadowRoot,`:host`);n.setProperty(`display`,`var(--media-control-display, var(--${this.localName}-display, inline-flex))`),this.hasAttribute(`disabled`)?this.disable():this.enable(),this.setAttribute(`role`,`button`);let r=this.getAttribute(v.MEDIA_CONTROLLER);r&&(Pr(this,Ir,this.getRootNode()?.getElementById(r)),(t=(e=W(this,Ir))?.associateElement)==null||t.call(e,this)),E.customElements.whenDefined(`media-tooltip`).then(()=>Fr(this,Vr,Hr).call(this))}disconnectedCallback(){var e,t;this.disable(),(t=(e=W(this,Ir))?.unassociateElement)==null||t.call(e,this),Pr(this,Ir,null),this.removeEventListener(`mouseenter`,W(this,Rr)),this.removeEventListener(`focus`,W(this,Rr)),this.removeEventListener(`click`,W(this,Lr))}get keysUsed(){return[`Enter`,` `]}get tooltipPlacement(){return N(this,Ur.TOOLTIP_PLACEMENT)}set tooltipPlacement(e){P(this,Ur.TOOLTIP_PLACEMENT,e)}get mediaController(){return N(this,v.MEDIA_CONTROLLER)}set mediaController(e){P(this,v.MEDIA_CONTROLLER,e)}get disabled(){return j(this,Ur.DISABLED)}set disabled(e){M(this,Ur.DISABLED,e)}get noTooltip(){return j(this,Ur.NO_TOOLTIP)}set noTooltip(e){M(this,Ur.NO_TOOLTIP,e)}handleClick(e){}};Ir=new WeakMap,Lr=new WeakMap,Rr=new WeakMap,zr=new WeakMap,Br=new WeakMap,Vr=new WeakSet,Hr=function(){this.addEventListener(`mouseenter`,W(this,Rr)),this.addEventListener(`focus`,W(this,Rr)),this.addEventListener(`click`,W(this,Lr));let e=this.tooltipPlacement;e&&this.tooltipEl&&(this.tooltipEl.placement=e)},G.shadowRootOptions={mode:`open`},G.getTemplateHTML=Wr,G.getSlotTemplateHTML=Gr,G.getTooltipContentHTML=Kr,E.customElements.get(`media-chrome-button`)||E.customElements.define(`media-chrome-button`,G);var qr=`<svg aria-hidden="true" viewBox="0 0 26 24">
  <path d="M22.13 3H3.87a.87.87 0 0 0-.87.87v13.26a.87.87 0 0 0 .87.87h3.4L9 16H5V5h16v11h-4l1.72 2h3.4a.87.87 0 0 0 .87-.87V3.87a.87.87 0 0 0-.86-.87Zm-8.75 11.44a.5.5 0 0 0-.76 0l-4.91 5.73a.5.5 0 0 0 .38.83h9.82a.501.501 0 0 0 .38-.83l-4.91-5.73Z"/>
</svg>
`;function Jr(e){return`
    <style>
      :host([${y.MEDIA_IS_AIRPLAYING}]) slot[name=icon] slot:not([name=exit]) {
        display: none !important;
      }

      
      :host(:not([${y.MEDIA_IS_AIRPLAYING}])) slot[name=icon] slot:not([name=enter]) {
        display: none !important;
      }

      :host([${y.MEDIA_IS_AIRPLAYING}]) slot[name=tooltip-enter],
      :host(:not([${y.MEDIA_IS_AIRPLAYING}])) slot[name=tooltip-exit] {
        display: none;
      }
    </style>

    <slot name="icon">
      <slot name="enter">${qr}</slot>
      <slot name="exit">${qr}</slot>
    </slot>
  `}function Yr(){return`
    <slot name="tooltip-enter">${T(`start airplay`)}</slot>
    <slot name="tooltip-exit">${T(`stop airplay`)}</slot>
  `}var Xr=e=>{let t=e.mediaIsAirplaying?T(`stop airplay`):T(`start airplay`);e.setAttribute(`aria-label`,t)},Zr=class extends G{static get observedAttributes(){return[...super.observedAttributes,y.MEDIA_IS_AIRPLAYING,y.MEDIA_AIRPLAY_UNAVAILABLE]}connectedCallback(){super.connectedCallback(),Xr(this)}attributeChangedCallback(e,t,n){super.attributeChangedCallback(e,t,n),e===y.MEDIA_IS_AIRPLAYING&&Xr(this)}get mediaIsAirplaying(){return j(this,y.MEDIA_IS_AIRPLAYING)}set mediaIsAirplaying(e){M(this,y.MEDIA_IS_AIRPLAYING,e)}get mediaAirplayUnavailable(){return N(this,y.MEDIA_AIRPLAY_UNAVAILABLE)}set mediaAirplayUnavailable(e){P(this,y.MEDIA_AIRPLAY_UNAVAILABLE,e)}handleClick(){let e=new E.CustomEvent(_.MEDIA_AIRPLAY_REQUEST,{composed:!0,bubbles:!0});this.dispatchEvent(e)}};Zr.getSlotTemplateHTML=Jr,Zr.getTooltipContentHTML=Yr,E.customElements.get(`media-airplay-button`)||E.customElements.define(`media-airplay-button`,Zr);var Qr=`<svg aria-hidden="true" viewBox="0 0 26 24">
  <path d="M22.83 5.68a2.58 2.58 0 0 0-2.3-2.5c-3.62-.24-11.44-.24-15.06 0a2.58 2.58 0 0 0-2.3 2.5c-.23 4.21-.23 8.43 0 12.64a2.58 2.58 0 0 0 2.3 2.5c3.62.24 11.44.24 15.06 0a2.58 2.58 0 0 0 2.3-2.5c.23-4.21.23-8.43 0-12.64Zm-11.39 9.45a3.07 3.07 0 0 1-1.91.57 3.06 3.06 0 0 1-2.34-1 3.75 3.75 0 0 1-.92-2.67 3.92 3.92 0 0 1 .92-2.77 3.18 3.18 0 0 1 2.43-1 2.94 2.94 0 0 1 2.13.78c.364.359.62.813.74 1.31l-1.43.35a1.49 1.49 0 0 0-1.51-1.17 1.61 1.61 0 0 0-1.29.58 2.79 2.79 0 0 0-.5 1.89 3 3 0 0 0 .49 1.93 1.61 1.61 0 0 0 1.27.58 1.48 1.48 0 0 0 1-.37 2.1 2.1 0 0 0 .59-1.14l1.4.44a3.23 3.23 0 0 1-1.07 1.69Zm7.22 0a3.07 3.07 0 0 1-1.91.57 3.06 3.06 0 0 1-2.34-1 3.75 3.75 0 0 1-.92-2.67 3.88 3.88 0 0 1 .93-2.77 3.14 3.14 0 0 1 2.42-1 3 3 0 0 1 2.16.82 2.8 2.8 0 0 1 .73 1.31l-1.43.35a1.49 1.49 0 0 0-1.51-1.21 1.61 1.61 0 0 0-1.29.58A2.79 2.79 0 0 0 15 12a3 3 0 0 0 .49 1.93 1.61 1.61 0 0 0 1.27.58 1.44 1.44 0 0 0 1-.37 2.1 2.1 0 0 0 .6-1.15l1.4.44a3.17 3.17 0 0 1-1.1 1.7Z"/>
</svg>`,$r=`<svg aria-hidden="true" viewBox="0 0 26 24">
  <path d="M17.73 14.09a1.4 1.4 0 0 1-1 .37 1.579 1.579 0 0 1-1.27-.58A3 3 0 0 1 15 12a2.8 2.8 0 0 1 .5-1.85 1.63 1.63 0 0 1 1.29-.57 1.47 1.47 0 0 1 1.51 1.2l1.43-.34A2.89 2.89 0 0 0 19 9.07a3 3 0 0 0-2.14-.78 3.14 3.14 0 0 0-2.42 1 3.91 3.91 0 0 0-.93 2.78 3.74 3.74 0 0 0 .92 2.66 3.07 3.07 0 0 0 2.34 1 3.07 3.07 0 0 0 1.91-.57 3.17 3.17 0 0 0 1.07-1.74l-1.4-.45c-.083.43-.3.822-.62 1.12Zm-7.22 0a1.43 1.43 0 0 1-1 .37 1.58 1.58 0 0 1-1.27-.58A3 3 0 0 1 7.76 12a2.8 2.8 0 0 1 .5-1.85 1.63 1.63 0 0 1 1.29-.57 1.47 1.47 0 0 1 1.51 1.2l1.43-.34a2.81 2.81 0 0 0-.74-1.32 2.94 2.94 0 0 0-2.13-.78 3.18 3.18 0 0 0-2.43 1 4 4 0 0 0-.92 2.78 3.74 3.74 0 0 0 .92 2.66 3.07 3.07 0 0 0 2.34 1 3.07 3.07 0 0 0 1.91-.57 3.23 3.23 0 0 0 1.07-1.74l-1.4-.45a2.06 2.06 0 0 1-.6 1.07Zm12.32-8.41a2.59 2.59 0 0 0-2.3-2.51C18.72 3.05 15.86 3 13 3c-2.86 0-5.72.05-7.53.17a2.59 2.59 0 0 0-2.3 2.51c-.23 4.207-.23 8.423 0 12.63a2.57 2.57 0 0 0 2.3 2.5c1.81.13 4.67.19 7.53.19 2.86 0 5.72-.06 7.53-.19a2.57 2.57 0 0 0 2.3-2.5c.23-4.207.23-8.423 0-12.63Zm-1.49 12.53a1.11 1.11 0 0 1-.91 1.11c-1.67.11-4.45.18-7.43.18-2.98 0-5.76-.07-7.43-.18a1.11 1.11 0 0 1-.91-1.11c-.21-4.14-.21-8.29 0-12.43a1.11 1.11 0 0 1 .91-1.11C7.24 4.56 10 4.49 13 4.49s5.76.07 7.43.18a1.11 1.11 0 0 1 .91 1.11c.21 4.14.21 8.29 0 12.43Z"/>
</svg>`;function ei(e){return`
    <style>
      :host([aria-checked="true"]) slot[name=off] {
        display: none !important;
      }

      
      :host(:not([aria-checked="true"])) slot[name=on] {
        display: none !important;
      }

      :host([aria-checked="true"]) slot[name=tooltip-enable],
      :host(:not([aria-checked="true"])) slot[name=tooltip-disable] {
        display: none;
      }
    </style>

    <slot name="icon">
      <slot name="on">${Qr}</slot>
      <slot name="off">${$r}</slot>
    </slot>
  `}function ti(){return`
    <slot name="tooltip-enable">${T(`Enable captions`)}</slot>
    <slot name="tooltip-disable">${T(`Disable captions`)}</slot>
  `}var ni=e=>{e.setAttribute(`aria-checked`,dn(e).toString())},ri=class extends G{static get observedAttributes(){return[...super.observedAttributes,y.MEDIA_SUBTITLES_LIST,y.MEDIA_SUBTITLES_SHOWING]}connectedCallback(){super.connectedCallback(),this.setAttribute(`role`,`button`),this.setAttribute(`aria-label`,T(`closed captions`)),ni(this)}attributeChangedCallback(e,t,n){super.attributeChangedCallback(e,t,n),e===y.MEDIA_SUBTITLES_SHOWING&&ni(this)}get mediaSubtitlesList(){return ii(this,y.MEDIA_SUBTITLES_LIST)}set mediaSubtitlesList(e){ai(this,y.MEDIA_SUBTITLES_LIST,e)}get mediaSubtitlesShowing(){return ii(this,y.MEDIA_SUBTITLES_SHOWING)}set mediaSubtitlesShowing(e){ai(this,y.MEDIA_SUBTITLES_SHOWING,e)}handleClick(){this.dispatchEvent(new E.CustomEvent(_.MEDIA_TOGGLE_SUBTITLES_REQUEST,{composed:!0,bubbles:!0}))}};ri.getSlotTemplateHTML=ei,ri.getTooltipContentHTML=ti;var ii=(e,t)=>{let n=e.getAttribute(t);return n?nn(n):[]},ai=(e,t,n)=>{if(!n?.length){e.removeAttribute(t);return}let r=on(n);e.getAttribute(t)!==r&&e.setAttribute(t,r)};E.customElements.get(`media-captions-button`)||E.customElements.define(`media-captions-button`,ri);var oi=`<svg aria-hidden="true" viewBox="0 0 24 24"><g><path class="cast_caf_icon_arch0" d="M1,18 L1,21 L4,21 C4,19.3 2.66,18 1,18 L1,18 Z"/><path class="cast_caf_icon_arch1" d="M1,14 L1,16 C3.76,16 6,18.2 6,21 L8,21 C8,17.13 4.87,14 1,14 L1,14 Z"/><path class="cast_caf_icon_arch2" d="M1,10 L1,12 C5.97,12 10,16.0 10,21 L12,21 C12,14.92 7.07,10 1,10 L1,10 Z"/><path class="cast_caf_icon_box" d="M21,3 L3,3 C1.9,3 1,3.9 1,5 L1,8 L3,8 L3,5 L21,5 L21,19 L14,19 L14,21 L21,21 C22.1,21 23,20.1 23,19 L23,5 C23,3.9 22.1,3 21,3 L21,3 Z"/></g></svg>`,si=`<svg aria-hidden="true" viewBox="0 0 24 24"><g><path class="cast_caf_icon_arch0" d="M1,18 L1,21 L4,21 C4,19.3 2.66,18 1,18 L1,18 Z"/><path class="cast_caf_icon_arch1" d="M1,14 L1,16 C3.76,16 6,18.2 6,21 L8,21 C8,17.13 4.87,14 1,14 L1,14 Z"/><path class="cast_caf_icon_arch2" d="M1,10 L1,12 C5.97,12 10,16.0 10,21 L12,21 C12,14.92 7.07,10 1,10 L1,10 Z"/><path class="cast_caf_icon_box" d="M21,3 L3,3 C1.9,3 1,3.9 1,5 L1,8 L3,8 L3,5 L21,5 L21,19 L14,19 L14,21 L21,21 C22.1,21 23,20.1 23,19 L23,5 C23,3.9 22.1,3 21,3 L21,3 Z"/><path class="cast_caf_icon_boxfill" d="M5,7 L5,8.63 C8,8.6 13.37,14 13.37,17 L19,17 L19,7 Z"/></g></svg>`;function ci(e){return`
    <style>
      :host([${y.MEDIA_IS_CASTING}]) slot[name=icon] slot:not([name=exit]) {
        display: none !important;
      }

      
      :host(:not([${y.MEDIA_IS_CASTING}])) slot[name=icon] slot:not([name=enter]) {
        display: none !important;
      }

      :host([${y.MEDIA_IS_CASTING}]) slot[name=tooltip-enter],
      :host(:not([${y.MEDIA_IS_CASTING}])) slot[name=tooltip-exit] {
        display: none;
      }
    </style>

    <slot name="icon">
      <slot name="enter">${oi}</slot>
      <slot name="exit">${si}</slot>
    </slot>
  `}function li(){return`
    <slot name="tooltip-enter">${T(`Start casting`)}</slot>
    <slot name="tooltip-exit">${T(`Stop casting`)}</slot>
  `}var ui=e=>{let t=e.mediaIsCasting?T(`stop casting`):T(`start casting`);e.setAttribute(`aria-label`,t)},di=class extends G{static get observedAttributes(){return[...super.observedAttributes,y.MEDIA_IS_CASTING,y.MEDIA_CAST_UNAVAILABLE]}connectedCallback(){super.connectedCallback(),ui(this)}attributeChangedCallback(e,t,n){super.attributeChangedCallback(e,t,n),e===y.MEDIA_IS_CASTING&&ui(this)}get mediaIsCasting(){return j(this,y.MEDIA_IS_CASTING)}set mediaIsCasting(e){M(this,y.MEDIA_IS_CASTING,e)}get mediaCastUnavailable(){return N(this,y.MEDIA_CAST_UNAVAILABLE)}set mediaCastUnavailable(e){P(this,y.MEDIA_CAST_UNAVAILABLE,e)}handleClick(){let e=this.mediaIsCasting?_.MEDIA_EXIT_CAST_REQUEST:_.MEDIA_ENTER_CAST_REQUEST;this.dispatchEvent(new E.CustomEvent(e,{composed:!0,bubbles:!0}))}};di.getSlotTemplateHTML=ci,di.getTooltipContentHTML=li,E.customElements.get(`media-cast-button`)||E.customElements.define(`media-cast-button`,di);var fi=(e,t,n)=>{if(!t.has(e))throw TypeError(`Cannot `+n)},pi=(e,t,n)=>(fi(e,t,`read from private field`),n?n.call(e):t.get(e)),mi=(e,t,n)=>{if(t.has(e))throw TypeError(`Cannot add the same private member more than once`);t instanceof WeakSet?t.add(e):t.set(e,n)},hi=(e,t,n,r)=>(fi(e,t,`write to private field`),r?r.call(e,n):t.set(e,n),n),gi=(e,t,n)=>(fi(e,t,`access private method`),n),_i,vi,yi,bi,xi,Si,Ci,wi,Ti,Ei,Di,Oi,ki,Ai,ji;function Mi(e){return`
    <style>
      :host {
        font: var(--media-font,
          var(--media-font-weight, normal)
          var(--media-font-size, 14px) /
          var(--media-text-content-height, var(--media-control-height, 24px))
          var(--media-font-family, helvetica neue, segoe ui, roboto, arial, sans-serif));
        color: var(--media-text-color, var(--media-primary-color, rgb(238 238 238)));
        display: var(--media-dialog-display, inline-flex);
        justify-content: center;
        align-items: center;
        
        transition-behavior: allow-discrete;
        visibility: hidden;
        opacity: 0;
        transform: translateY(2px) scale(.99);
        pointer-events: none;
      }

      :host([open]) {
        transition: display .2s, visibility 0s, opacity .2s ease-out, transform .15s ease-out;
        visibility: visible;
        opacity: 1;
        transform: translateY(0) scale(1);
        pointer-events: auto;
      }

      #content {
        display: flex;
        position: relative;
        box-sizing: border-box;
        width: min(320px, 100%);
        word-wrap: break-word;
        max-height: 100%;
        overflow: auto;
        text-align: center;
        line-height: 1.4;
      }
    </style>
    ${this.getSlotTemplateHTML(e)}
  `}function Ni(e){return`
    <slot id="content"></slot>
  `}var Pi={OPEN:`open`,ANCHOR:`anchor`},Fi=class extends E.HTMLElement{constructor(){super(),mi(this,bi),mi(this,Si),mi(this,wi),mi(this,Ei),mi(this,Oi),mi(this,Ai),mi(this,_i,!1),mi(this,vi,null),mi(this,yi,null)}static get observedAttributes(){return[Pi.OPEN,Pi.ANCHOR]}get open(){return j(this,Pi.OPEN)}set open(e){M(this,Pi.OPEN,e)}handleEvent(e){switch(e.type){case`invoke`:gi(this,Ei,Di).call(this,e);break;case`focusout`:gi(this,Oi,ki).call(this,e);break;case`keydown`:gi(this,Ai,ji).call(this,e)}}connectedCallback(){gi(this,bi,xi).call(this),this.role||=`dialog`,this.addEventListener(`invoke`,this),this.addEventListener(`focusout`,this),this.addEventListener(`keydown`,this)}disconnectedCallback(){this.removeEventListener(`invoke`,this),this.removeEventListener(`focusout`,this),this.removeEventListener(`keydown`,this)}attributeChangedCallback(e,t,n){gi(this,bi,xi).call(this),e===Pi.OPEN&&n!==t&&(this.open?gi(this,Si,Ci).call(this):gi(this,wi,Ti).call(this))}focus(){hi(this,vi,$e());let e=!this.dispatchEvent(new Event(`focus`,{composed:!0,cancelable:!0})),t=!this.dispatchEvent(new Event(`focusin`,{composed:!0,bubbles:!0,cancelable:!0}));e||t||this.querySelector(`[autofocus], [tabindex]:not([tabindex="-1"]), [role="menu"]`)?.focus()}get keysUsed(){return[`Escape`,`Tab`]}};_i=new WeakMap,vi=new WeakMap,yi=new WeakMap,bi=new WeakSet,xi=function(){if(!pi(this,_i)&&(hi(this,_i,!0),!this.shadowRoot)){this.attachShadow(this.constructor.shadowRootOptions);let e=Ge(this.attributes);this.shadowRoot.innerHTML=this.constructor.getTemplateHTML(e),queueMicrotask(()=>{let{style:e}=O(this.shadowRoot,`:host`);e.setProperty(`transition`,`display .15s, visibility .15s, opacity .15s ease-in, transform .15s ease-in`)})}},Si=new WeakSet,Ci=function(){var e;(e=pi(this,yi))==null||e.setAttribute(`aria-expanded`,`true`),this.dispatchEvent(new Event(`open`,{composed:!0,bubbles:!0})),this.addEventListener(`transitionend`,()=>this.focus(),{once:!0})},wi=new WeakSet,Ti=function(){var e;(e=pi(this,yi))==null||e.setAttribute(`aria-expanded`,`false`),this.dispatchEvent(new Event(`close`,{composed:!0,bubbles:!0}))},Ei=new WeakSet,Di=function(e){hi(this,yi,e.relatedTarget),Ze(this,e.relatedTarget)||(this.open=!this.open)},Oi=new WeakSet,ki=function(e){var t;Ze(this,e.relatedTarget)||((t=pi(this,vi))==null||t.focus(),pi(this,yi)&&pi(this,yi)!==e.relatedTarget&&this.open&&(this.open=!1))},Ai=new WeakSet,ji=function(e){var t,n,r,i,a;let{key:o,ctrlKey:s,altKey:c,metaKey:l}=e;s||c||l||this.keysUsed.includes(o)&&(e.preventDefault(),e.stopPropagation(),o===`Tab`?(e.shiftKey?(n=(t=this.previousElementSibling)?.focus)==null||n.call(t):(i=(r=this.nextElementSibling)?.focus)==null||i.call(r),this.blur()):o===`Escape`&&((a=pi(this,vi))==null||a.focus(),this.open=!1))},Fi.shadowRootOptions={mode:`open`},Fi.getTemplateHTML=Mi,Fi.getSlotTemplateHTML=Ni,E.customElements.get(`media-chrome-dialog`)||E.customElements.define(`media-chrome-dialog`,Fi);var Ii=(e,t,n)=>{if(!t.has(e))throw TypeError(`Cannot `+n)},K=(e,t,n)=>(Ii(e,t,`read from private field`),n?n.call(e):t.get(e)),q=(e,t,n)=>{if(t.has(e))throw TypeError(`Cannot add the same private member more than once`);t instanceof WeakSet?t.add(e):t.set(e,n)},Li=(e,t,n,r)=>(Ii(e,t,`write to private field`),r?r.call(e,n):t.set(e,n),n),Ri=(e,t,n)=>(Ii(e,t,`access private method`),n),zi,Bi,Vi,Hi,Ui,Wi,Gi,Ki,qi,Ji,Yi,Xi,Zi,Qi,$i,ea,ta,na,ra,ia,aa,oa,sa,ca,la;function ua(e){return`
    <style>
      :host {
        --_focus-box-shadow: var(--media-focus-box-shadow, inset 0 0 0 2px rgb(27 127 204 / .9));
        --_media-range-padding: var(--media-range-padding, var(--media-control-padding, 10px));

        box-shadow: var(--_focus-visible-box-shadow, none);
        background: var(--media-control-background, var(--media-secondary-color, rgb(20 20 30 / .7)));
        height: calc(var(--media-control-height, 24px) + 2 * var(--_media-range-padding));
        display: inline-flex;
        align-items: center;
        
        vertical-align: middle;
        box-sizing: border-box;
        position: relative;
        width: 100px;
        transition: background .15s linear;
        cursor: var(--media-cursor, pointer);
        pointer-events: auto;
        touch-action: none; 
      }

      
      input[type=range]:focus {
        outline: 0;
      }
      input[type=range]:focus::-webkit-slider-runnable-track {
        outline: 0;
      }

      :host(:hover) {
        background: var(--media-control-hover-background, rgb(50 50 70 / .7));
      }

      #leftgap {
        padding-left: var(--media-range-padding-left, var(--_media-range-padding));
      }

      #rightgap {
        padding-right: var(--media-range-padding-right, var(--_media-range-padding));
      }

      #startpoint,
      #endpoint {
        position: absolute;
      }

      #endpoint {
        right: 0;
      }

      #container {
        
        width: var(--media-range-track-width, 100%);
        transform: translate(var(--media-range-track-translate-x, 0px), var(--media-range-track-translate-y, 0px));
        position: relative;
        height: 100%;
        display: flex;
        align-items: center;
        min-width: 40px;
      }

      #range {
        
        display: var(--media-time-range-hover-display, block);
        bottom: var(--media-time-range-hover-bottom, 0);
        height: var(--media-time-range-hover-height, max(100% , 25px));
        width: 100%;
        position: absolute;
        cursor: var(--media-cursor, pointer);

        -webkit-appearance: none; 
        -webkit-tap-highlight-color: transparent;
        background: transparent; 
        margin: 0;
        z-index: 1;
      }

      @media (hover: hover) {
        #range {
          bottom: var(--media-time-range-hover-bottom, 0);
          height: var(--media-time-range-hover-height, max(100%, 20px));
        }
      }

      
      
      #range::-webkit-slider-thumb {
        -webkit-appearance: none;
        background: transparent;
        width: .1px;
        height: .1px;
      }

      
      #range::-moz-range-thumb {
        background: transparent;
        border: transparent;
        width: .1px;
        height: .1px;
      }

      #appearance {
        height: var(--media-range-track-height, 4px);
        display: flex;
        flex-direction: column;
        justify-content: center;
        width: 100%;
        position: absolute;
        
        will-change: transform;
      }

      #track {
        background: var(--media-range-track-background, rgb(255 255 255 / .2));
        border-radius: var(--media-range-track-border-radius, 1px);
        border: var(--media-range-track-border, none);
        outline: var(--media-range-track-outline);
        outline-offset: var(--media-range-track-outline-offset);
        backdrop-filter: var(--media-range-track-backdrop-filter);
        -webkit-backdrop-filter: var(--media-range-track-backdrop-filter);
        box-shadow: var(--media-range-track-box-shadow, none);
        position: absolute;
        width: 100%;
        height: 100%;
        overflow: hidden;
      }

      #progress,
      #pointer {
        position: absolute;
        height: 100%;
        will-change: width;
      }

      #progress {
        background: var(--media-range-bar-color, var(--media-primary-color, rgb(238 238 238)));
        transition: var(--media-range-track-transition);
      }

      #pointer {
        background: var(--media-range-track-pointer-background);
        border-right: var(--media-range-track-pointer-border-right);
        transition: visibility .25s, opacity .25s;
        visibility: hidden;
        opacity: 0;
      }

      @media (hover: hover) {
        :host(:hover) #pointer {
          transition: visibility .5s, opacity .5s;
          visibility: visible;
          opacity: 1;
        }
      }

      #thumb,
      ::slotted([slot=thumb]) {
        width: var(--media-range-thumb-width, 10px);
        height: var(--media-range-thumb-height, 10px);
        transition: var(--media-range-thumb-transition);
        transform: var(--media-range-thumb-transform, none);
        opacity: var(--media-range-thumb-opacity, 1);
        translate: -50%;
        position: absolute;
        left: 0;
        cursor: var(--media-cursor, pointer);
      }

      #thumb {
        border-radius: var(--media-range-thumb-border-radius, 10px);
        background: var(--media-range-thumb-background, var(--media-primary-color, rgb(238 238 238)));
        box-shadow: var(--media-range-thumb-box-shadow, 1px 1px 1px transparent);
        border: var(--media-range-thumb-border, none);
      }

      :host([disabled]) #thumb {
        background-color: #777;
      }

      .segments #appearance {
        height: var(--media-range-segment-hover-height, 7px);
      }

      #track {
        clip-path: url(#segments-clipping);
      }

      #segments {
        --segments-gap: var(--media-range-segments-gap, 2px);
        position: absolute;
        width: 100%;
        height: 100%;
      }

      #segments-clipping {
        transform: translateX(calc(var(--segments-gap) / 2));
      }

      #segments-clipping:empty {
        display: none;
      }

      #segments-clipping rect {
        height: var(--media-range-track-height, 4px);
        y: calc((var(--media-range-segment-hover-height, 7px) - var(--media-range-track-height, 4px)) / 2);
        transition: var(--media-range-segment-transition, transform .1s ease-in-out);
        transform: var(--media-range-segment-transform, scaleY(1));
        transform-origin: center;
      }

      /* Visible label for accessibility - positioned off-screen but technically visible (Firefox requires visible labels) */
      #range-label {
        position: absolute;
        left: -10000px;
        background: var(--media-control-background, var(--media-secondary-color, rgb(20 20 30 / .7)));
        pointer-events: none;
      }
    </style>
    <div id="leftgap"></div>
    <div id="container">
      <div id="startpoint"></div>
      <div id="endpoint"></div>
      <div id="appearance">
        <div id="track" part="track">
          <div id="pointer"></div>
          <div id="progress" part="progress"></div>
        </div>
        <slot name="thumb">
          <div id="thumb" part="thumb"></div>
        </slot>
        <svg id="segments" aria-hidden="true"><clipPath id="segments-clipping"></clipPath></svg>
      </div>
        <input id="range" type="range" min="0" max="1" step="any" value="0">
        <label for="range" id="range-label"></label>

      ${this.getContainerTemplateHTML(e)}
    </div>
    <div id="rightgap"></div>
  `}function da(e){return``}var fa=class extends E.HTMLElement{constructor(){if(super(),q(this,Ji),q(this,Xi),q(this,Qi),q(this,ea),q(this,na),q(this,ia),q(this,oa),q(this,ca),q(this,zi,void 0),q(this,Bi,void 0),q(this,Vi,void 0),q(this,Hi,void 0),q(this,Ui,{}),q(this,Wi,[]),q(this,Gi,()=>{if(this.range.matches(`:focus-visible`)){let{style:e}=O(this.shadowRoot,`:host`);e.setProperty(`--_focus-visible-box-shadow`,`var(--_focus-box-shadow)`)}}),q(this,Ki,()=>{let{style:e}=O(this.shadowRoot,`:host`);e.removeProperty(`--_focus-visible-box-shadow`)}),q(this,qi,()=>{let e=this.shadowRoot.querySelector(`#segments-clipping`);e&&e.parentNode.append(e)}),!this.shadowRoot){this.attachShadow(this.constructor.shadowRootOptions);let e=Ge(this.attributes),t=this.constructor.getTemplateHTML(e);this.shadowRoot.setHTMLUnsafe?this.shadowRoot.setHTMLUnsafe(t):this.shadowRoot.innerHTML=t}this.container=this.shadowRoot.querySelector(`#container`),Li(this,Vi,this.shadowRoot.querySelector(`#startpoint`)),Li(this,Hi,this.shadowRoot.querySelector(`#endpoint`)),this.range=this.shadowRoot.querySelector(`#range`),this.appearance=this.shadowRoot.querySelector(`#appearance`)}static get observedAttributes(){return[`disabled`,`aria-disabled`,v.MEDIA_CONTROLLER]}attributeChangedCallback(e,t,n){var r,i,a,o;e===v.MEDIA_CONTROLLER?(t&&((i=(r=K(this,zi))?.unassociateElement)==null||i.call(r,this),Li(this,zi,null)),n&&this.isConnected&&(Li(this,zi,this.getRootNode()?.getElementById(n)),(o=(a=K(this,zi))?.associateElement)==null||o.call(a,this))):(e===`disabled`||e===`aria-disabled`&&t!==n)&&(n==null?(this.range.removeAttribute(e),Ri(this,Xi,Zi).call(this)):(this.range.setAttribute(e,n),Ri(this,Qi,$i).call(this)))}connectedCallback(){var e,t;let{style:n}=O(this.shadowRoot,`:host`);n.setProperty(`display`,`var(--media-control-display, var(--${this.localName}-display, inline-flex))`),K(this,Ui).pointer=O(this.shadowRoot,`#pointer`),K(this,Ui).progress=O(this.shadowRoot,`#progress`),K(this,Ui).thumb=O(this.shadowRoot,`#thumb, ::slotted([slot="thumb"])`),K(this,Ui).activeSegment=O(this.shadowRoot,`#segments-clipping rect:nth-child(0)`);let r=this.getAttribute(v.MEDIA_CONTROLLER);r&&(Li(this,zi,this.getRootNode()?.getElementById(r)),(t=(e=K(this,zi))?.associateElement)==null||t.call(e,this)),this.updateBar(),this.shadowRoot.addEventListener(`focusin`,K(this,Gi)),this.shadowRoot.addEventListener(`focusout`,K(this,Ki)),Ri(this,Xi,Zi).call(this),Ue(this.container,K(this,qi))}disconnectedCallback(){var e,t;Ri(this,Qi,$i).call(this),(t=(e=K(this,zi))?.unassociateElement)==null||t.call(e,this),Li(this,zi,null),this.shadowRoot.removeEventListener(`focusin`,K(this,Gi)),this.shadowRoot.removeEventListener(`focusout`,K(this,Ki)),We(this.container,K(this,qi))}updatePointerBar(e){var t;(t=K(this,Ui).pointer)==null||t.style.setProperty(`width`,`${this.getPointerRatio(e)*100}%`)}updateBar(){var e,t;let n=this.range.valueAsNumber*100;(e=K(this,Ui).progress)==null||e.style.setProperty(`width`,`${n}%`),(t=K(this,Ui).thumb)==null||t.style.setProperty(`left`,`${n}%`)}updateSegments(e){let t=this.shadowRoot.querySelector(`#segments-clipping`);if(t.textContent=``,this.container.classList.toggle(`segments`,!!e?.length),!e?.length)return;let n=[...new Set([+this.range.min,...e.flatMap(e=>[e.start,e.end]),+this.range.max])];Li(this,Wi,[...n]);let r=n.pop();for(let[e,i]of n.entries()){let[a,o]=[e===0,e===n.length-1],s=a?`calc(var(--segments-gap) / -1)`:`${i*100}%`,c=`calc(${((o?r:n[e+1])-i)*100}%${a||o?``:` - var(--segments-gap)`})`,l=D.createElementNS(`http://www.w3.org/2000/svg`,`rect`),u=it(this.shadowRoot,`#segments-clipping rect:nth-child(${e+1})`);u.style.setProperty(`x`,s),u.style.setProperty(`width`,c),t.append(l)}}getPointerRatio(e){return nt(e.clientX,e.clientY,K(this,Vi).getBoundingClientRect(),K(this,Hi).getBoundingClientRect())}get dragging(){return this.hasAttribute(`dragging`)}handleEvent(e){switch(e.type){case`pointermove`:Ri(this,ca,la).call(this,e);break;case`input`:this.updateBar();break;case`pointerenter`:Ri(this,na,ra).call(this,e);break;case`pointerdown`:Ri(this,ea,ta).call(this,e);break;case`pointerup`:Ri(this,ia,aa).call(this);break;case`pointerleave`:Ri(this,oa,sa).call(this)}}get keysUsed(){return[`ArrowUp`,`ArrowRight`,`ArrowDown`,`ArrowLeft`]}};zi=new WeakMap,Bi=new WeakMap,Vi=new WeakMap,Hi=new WeakMap,Ui=new WeakMap,Wi=new WeakMap,Gi=new WeakMap,Ki=new WeakMap,qi=new WeakMap,Ji=new WeakSet,Yi=function(e){let t=K(this,Ui).activeSegment;if(!t)return;let n=this.getPointerRatio(e),r=`#segments-clipping rect:nth-child(${K(this,Wi).findIndex((e,t,r)=>{let i=r[t+1];return i!=null&&n>=e&&n<=i})+1})`;(t.selectorText!=r||!t.style.transform)&&(t.selectorText=r,t.style.setProperty(`transform`,`var(--media-range-segment-hover-transform, scaleY(2))`))},Xi=new WeakSet,Zi=function(){this.hasAttribute(`disabled`)||!this.isConnected||(this.addEventListener(`input`,this),this.addEventListener(`pointerdown`,this),this.addEventListener(`pointerenter`,this))},Qi=new WeakSet,$i=function(){var e,t;this.removeEventListener(`input`,this),this.removeEventListener(`pointerdown`,this),this.removeEventListener(`pointerenter`,this),this.removeEventListener(`pointerleave`,this),(e=E.window)==null||e.removeEventListener(`pointerup`,this),(t=E.window)==null||t.removeEventListener(`pointermove`,this)},ea=new WeakSet,ta=function(e){var t;Li(this,Bi,e.composedPath().includes(this.range)),(t=E.window)==null||t.addEventListener(`pointerup`,this,{once:!0})},na=new WeakSet,ra=function(e){var t;e.pointerType!==`mouse`&&Ri(this,ea,ta).call(this,e),this.addEventListener(`pointerleave`,this,{once:!0}),(t=E.window)==null||t.addEventListener(`pointermove`,this)},ia=new WeakSet,aa=function(){var e;(e=E.window)==null||e.removeEventListener(`pointerup`,this),this.toggleAttribute(`dragging`,!1),this.range.disabled=this.hasAttribute(`disabled`)},oa=new WeakSet,sa=function(){var e,t;this.removeEventListener(`pointerleave`,this),(e=E.window)==null||e.removeEventListener(`pointermove`,this),this.toggleAttribute(`dragging`,!1),this.range.disabled=this.hasAttribute(`disabled`),(t=K(this,Ui).activeSegment)==null||t.style.removeProperty(`transform`)},ca=new WeakSet,la=function(e){(e.pointerType!==`pen`||e.buttons!==0)&&(this.toggleAttribute(`dragging`,e.buttons===1||e.pointerType!==`mouse`),this.updatePointerBar(e),Ri(this,Ji,Yi).call(this,e),this.dragging&&(e.pointerType!==`mouse`||!K(this,Bi))&&(this.range.disabled=!0,this.range.valueAsNumber=this.getPointerRatio(e),this.range.dispatchEvent(new Event(`input`,{bubbles:!0,composed:!0}))))},fa.shadowRootOptions={mode:`open`},fa.getTemplateHTML=ua,fa.getContainerTemplateHTML=da,E.customElements.get(`media-chrome-range`)||E.customElements.define(`media-chrome-range`,fa);var pa=(e,t,n)=>{if(!t.has(e))throw TypeError(`Cannot `+n)},ma=(e,t,n)=>(pa(e,t,`read from private field`),n?n.call(e):t.get(e)),ha=(e,t,n)=>{if(t.has(e))throw TypeError(`Cannot add the same private member more than once`);t instanceof WeakSet?t.add(e):t.set(e,n)},ga=(e,t,n,r)=>(pa(e,t,`write to private field`),r?r.call(e,n):t.set(e,n),n),_a;function va(e){return`
    <style>
      :host {
        
        box-sizing: border-box;
        display: var(--media-control-display, var(--media-control-bar-display, inline-flex));
        color: var(--media-text-color, var(--media-primary-color, rgb(238 238 238)));
        --media-loading-indicator-icon-height: 44px;
      }

      ::slotted(media-time-range),
      ::slotted(media-volume-range) {
        min-height: 100%;
      }

      ::slotted(media-time-range),
      ::slotted(media-clip-selector) {
        flex-grow: 1;
      }

      ::slotted([role="menu"]) {
        position: absolute;
      }
    </style>

    <slot></slot>
  `}var ya=class extends E.HTMLElement{constructor(){if(super(),ha(this,_a,void 0),!this.shadowRoot){this.attachShadow(this.constructor.shadowRootOptions);let e=Ge(this.attributes);this.shadowRoot.innerHTML=this.constructor.getTemplateHTML(e)}}static get observedAttributes(){return[v.MEDIA_CONTROLLER]}attributeChangedCallback(e,t,n){var r,i,a,o;e===v.MEDIA_CONTROLLER&&(t&&((i=(r=ma(this,_a))?.unassociateElement)==null||i.call(r,this),ga(this,_a,null)),n&&this.isConnected&&(ga(this,_a,this.getRootNode()?.getElementById(n)),(o=(a=ma(this,_a))?.associateElement)==null||o.call(a,this)))}connectedCallback(){var e,t;let n=this.getAttribute(v.MEDIA_CONTROLLER);n&&(ga(this,_a,this.getRootNode()?.getElementById(n)),(t=(e=ma(this,_a))?.associateElement)==null||t.call(e,this))}disconnectedCallback(){var e,t;(t=(e=ma(this,_a))?.unassociateElement)==null||t.call(e,this),ga(this,_a,null)}};_a=new WeakMap,ya.shadowRootOptions={mode:`open`},ya.getTemplateHTML=va,E.customElements.get(`media-control-bar`)||E.customElements.define(`media-control-bar`,ya);var ba=(e,t,n)=>{if(!t.has(e))throw TypeError(`Cannot `+n)},xa=(e,t,n)=>(ba(e,t,`read from private field`),n?n.call(e):t.get(e)),Sa=(e,t,n)=>{if(t.has(e))throw TypeError(`Cannot add the same private member more than once`);t instanceof WeakSet?t.add(e):t.set(e,n)},Ca=(e,t,n,r)=>(ba(e,t,`write to private field`),r?r.call(e,n):t.set(e,n),n),wa;function Ta(e,t={}){return`
    <style>
      :host {
        font: var(--media-font,
          var(--media-font-weight, normal)
          var(--media-font-size, 14px) /
          var(--media-text-content-height, var(--media-control-height, 24px))
          var(--media-font-family, helvetica neue, segoe ui, roboto, arial, sans-serif));
        color: var(--media-text-color, var(--media-primary-color, rgb(238 238 238)));
        background: var(--media-text-background, var(--media-control-background, var(--media-secondary-color, rgb(20 20 30 / .7))));
        padding: var(--media-control-padding, 10px);
        display: inline-flex;
        justify-content: center;
        align-items: center;
        vertical-align: middle;
        box-sizing: border-box;
        text-align: center;
        pointer-events: auto;
      }

      
      :host(:focus-visible) {
        box-shadow: var(--media-focus-box-shadow, inset 0 0 0 2px rgb(27 127 204 / .9));
        outline: 0;
      }

      
      :host(:where(:focus)) {
        box-shadow: none;
        outline: 0;
      }
    </style>

    ${this.getSlotTemplateHTML(e,t)}
  `}function Ea(e,t){return`
    <slot></slot>
  `}var Da=class extends E.HTMLElement{constructor(){if(super(),Sa(this,wa,void 0),!this.shadowRoot){this.attachShadow(this.constructor.shadowRootOptions);let e=Ge(this.attributes);this.shadowRoot.innerHTML=this.constructor.getTemplateHTML(e)}}static get observedAttributes(){return[v.MEDIA_CONTROLLER]}attributeChangedCallback(e,t,n){var r,i,a,o;e===v.MEDIA_CONTROLLER&&(t&&((i=(r=xa(this,wa))?.unassociateElement)==null||i.call(r,this),Ca(this,wa,null)),n&&this.isConnected&&(Ca(this,wa,this.getRootNode()?.getElementById(n)),(o=(a=xa(this,wa))?.associateElement)==null||o.call(a,this)))}connectedCallback(){var e,t;let{style:n}=O(this.shadowRoot,`:host`);n.setProperty(`display`,`var(--media-control-display, var(--${this.localName}-display, inline-flex))`);let r=this.getAttribute(v.MEDIA_CONTROLLER);r&&(Ca(this,wa,this.getRootNode()?.getElementById(r)),(t=(e=xa(this,wa))?.associateElement)==null||t.call(e,this))}disconnectedCallback(){var e,t;(t=(e=xa(this,wa))?.unassociateElement)==null||t.call(e,this),Ca(this,wa,null)}};wa=new WeakMap,Da.shadowRootOptions={mode:`open`},Da.getTemplateHTML=Ta,Da.getSlotTemplateHTML=Ea,E.customElements.get(`media-text-display`)||E.customElements.define(`media-text-display`,Da);var Oa=(e,t,n)=>{if(!t.has(e))throw TypeError(`Cannot `+n)},ka=(e,t,n)=>(Oa(e,t,`read from private field`),n?n.call(e):t.get(e)),Aa=(e,t,n)=>{if(t.has(e))throw TypeError(`Cannot add the same private member more than once`);t instanceof WeakSet?t.add(e):t.set(e,n)},ja=(e,t,n,r)=>(Oa(e,t,`write to private field`),r?r.call(e,n):t.set(e,n),n),Ma;function Na(e,t){return`
    <slot>${je(t.mediaDuration)}</slot>
  `}var Pa=class extends Da{constructor(){super(),Aa(this,Ma,void 0),ja(this,Ma,this.shadowRoot.querySelector(`slot`)),ka(this,Ma).textContent=je(this.mediaDuration??0)}static get observedAttributes(){return[...super.observedAttributes,y.MEDIA_DURATION]}attributeChangedCallback(e,t,n){e===y.MEDIA_DURATION&&(ka(this,Ma).textContent=je(+n)),super.attributeChangedCallback(e,t,n)}get mediaDuration(){return k(this,y.MEDIA_DURATION)}set mediaDuration(e){A(this,y.MEDIA_DURATION,e)}};Ma=new WeakMap,Pa.getSlotTemplateHTML=Na,E.customElements.get(`media-duration-display`)||E.customElements.define(`media-duration-display`,Pa);var Fa={2:T(`Network Error`),3:T(`Decode Error`),4:T(`Source Not Supported`),5:T(`Encryption Error`)},Ia={2:T(`A network error caused the media download to fail.`),3:T(`A media error caused playback to be aborted. The media could be corrupt or your browser does not support this format.`),4:T(`An unsupported error occurred. The server or network failed, or your browser does not support this format.`),5:T(`The media is encrypted and there are no keys to decrypt it.`)},La=e=>e.code===1?null:{title:Fa[e.code]??`Error ${e.code}`,message:Ia[e.code]??e.message},Ra=(e,t,n)=>{if(!t.has(e))throw TypeError(`Cannot `+n)},za=(e,t,n)=>(Ra(e,t,`read from private field`),n?n.call(e):t.get(e)),Ba=(e,t,n)=>{if(t.has(e))throw TypeError(`Cannot add the same private member more than once`);t instanceof WeakSet?t.add(e):t.set(e,n)},Va=(e,t,n,r)=>(Ra(e,t,`write to private field`),r?r.call(e,n):t.set(e,n),n),Ha;function Ua(e){return`
    <style>
      :host {
        background: rgb(20 20 30 / .8);
      }

      #content {
        display: block;
        padding: 1.2em 1.5em;
      }

      h3,
      p {
        margin-block: 0 .3em;
      }
    </style>
    <slot name="error-${e.mediaerrorcode}" id="content">
      ${Ga({code:+e.mediaerrorcode,message:e.mediaerrormessage})}
    </slot>
  `}function Wa(e){return e.code&&La(e)!==null}function Ga(e){let{title:t,message:n}=La(e)??{},r=``;return t&&(r+=`<slot name="error-${e.code}-title"><h3>${t}</h3></slot>`),n&&(r+=`<slot name="error-${e.code}-message"><p>${n}</p></slot>`),r}var Ka=[y.MEDIA_ERROR_CODE,y.MEDIA_ERROR_MESSAGE],qa=class extends Fi{constructor(){super(...arguments),Ba(this,Ha,null)}static get observedAttributes(){return[...super.observedAttributes,...Ka]}formatErrorMessage(e){return this.constructor.formatErrorMessage(e)}attributeChangedCallback(e,t,n){if(super.attributeChangedCallback(e,t,n),!Ka.includes(e))return;let r=this.mediaError??{code:this.mediaErrorCode,message:this.mediaErrorMessage};if(this.open=Wa(r),this.open&&(this.shadowRoot.querySelector(`slot`).name=`error-${this.mediaErrorCode}`,this.shadowRoot.querySelector(`#content`).innerHTML=this.formatErrorMessage(r),!this.hasAttribute(`aria-label`))){let{title:e}=La(r);e&&this.setAttribute(`aria-label`,e)}}get mediaError(){return za(this,Ha)}set mediaError(e){Va(this,Ha,e)}get mediaErrorCode(){return k(this,`mediaerrorcode`)}set mediaErrorCode(e){A(this,`mediaerrorcode`,e)}get mediaErrorMessage(){return N(this,`mediaerrormessage`)}set mediaErrorMessage(e){P(this,`mediaerrormessage`,e)}};Ha=new WeakMap,qa.getSlotTemplateHTML=Ua,qa.formatErrorMessage=Ga,E.customElements.get(`media-error-dialog`)||E.customElements.define(`media-error-dialog`,qa);var Ja=(e,t,n)=>{if(!t.has(e))throw TypeError(`Cannot `+n)},Ya=(e,t,n)=>(Ja(e,t,`read from private field`),n?n.call(e):t.get(e)),Xa=(e,t,n)=>{if(t.has(e))throw TypeError(`Cannot add the same private member more than once`);t instanceof WeakSet?t.add(e):t.set(e,n)},Za,Qa;function $a(e){return`
    <style>
      :host {
        position: fixed;
        top: 0;
        left: 0;
        z-index: 9999;
        background: rgb(20 20 30 / .8);
        backdrop-filter: blur(10px);
      }

      #content {
        display: block;
        width: clamp(400px, 40vw, 700px);
        max-width: 90vw;
        text-align: left;
      }

      h2 {
        margin: 0 0 1.5rem 0;
        font-size: 1.5rem;
        font-weight: 500;
        text-align: center;
      }

      .shortcuts-table {
        width: 100%;
        border-collapse: collapse;
      }

      .shortcuts-table tr {
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      }

      .shortcuts-table tr:last-child {
        border-bottom: none;
      }

      .shortcuts-table td {
        padding: 0.75rem 0.5rem;
      }

      .shortcuts-table td:first-child {
        text-align: right;
        padding-right: 1rem;
        width: 40%;
        min-width: 120px;
      }

      .shortcuts-table td:last-child {
        padding-left: 1rem;
      }

      .key {
        display: inline-block;
        background: rgba(255, 255, 255, 0.15);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 4px;
        padding: 0.25rem 0.5rem;
        font-family: 'Courier New', monospace;
        font-size: 0.9rem;
        font-weight: 500;
        min-width: 1.5rem;
        text-align: center;
        margin: 0 0.2rem;
      }

      .description {
        color: rgba(255, 255, 255, 0.9);
        font-size: 0.95rem;
      }

      .key-combo {
        display: flex;
        align-items: center;
        justify-content: flex-end;
        gap: 0.3rem;
      }

      .key-separator {
        color: rgba(255, 255, 255, 0.5);
        font-size: 0.9rem;
      }
    </style>
    <slot id="content">
      ${eo()}
    </slot>
  `}function eo(){return`
    <h2>Keyboard Shortcuts</h2>
    <table class="shortcuts-table">${[{keys:[`Space`,`k`],description:`Toggle Playback`},{keys:[`m`],description:`Toggle mute`},{keys:[`f`],description:`Toggle fullscreen`},{keys:[`c`],description:`Toggle captions or subtitles, if available`},{keys:[`p`],description:`Toggle Picture in Picture`},{keys:[`←`,`j`],description:`Seek back 10s`},{keys:[`→`,`l`],description:`Seek forward 10s`},{keys:[`↑`],description:`Turn volume up`},{keys:[`↓`],description:`Turn volume down`},{keys:[`< (SHIFT+,)`],description:`Decrease playback rate`},{keys:[`> (SHIFT+.)`],description:`Increase playback rate`}].map(({keys:e,description:t})=>`
      <tr>
        <td>
          <div class="key-combo">${e.map((e,t)=>t>0?`<span class="key-separator">or</span><span class="key">${e}</span>`:`<span class="key">${e}</span>`).join(``)}</div>
        </td>
        <td class="description">${t}</td>
      </tr>
    `).join(``)}</table>
  `}var to=class extends Fi{constructor(){super(...arguments),Xa(this,Za,e=>{if(!this.open)return;let t=this.shadowRoot?.querySelector(`#content`);if(!t)return;let n=e.composedPath(),r=n[0]===this||n.includes(this),i=n.includes(t);r&&!i&&(this.open=!1)}),Xa(this,Qa,e=>{if(!this.open)return;let t=e.shiftKey&&(e.key===`/`||e.key===`?`);(e.key===`Escape`||t)&&!e.ctrlKey&&!e.altKey&&!e.metaKey&&(this.open=!1,e.preventDefault(),e.stopPropagation())})}connectedCallback(){super.connectedCallback(),this.open&&(this.addEventListener(`click`,Ya(this,Za)),document.addEventListener(`keydown`,Ya(this,Qa)))}disconnectedCallback(){this.removeEventListener(`click`,Ya(this,Za)),document.removeEventListener(`keydown`,Ya(this,Qa))}attributeChangedCallback(e,t,n){super.attributeChangedCallback(e,t,n),e===`open`&&(this.open?(this.addEventListener(`click`,Ya(this,Za)),document.addEventListener(`keydown`,Ya(this,Qa))):(this.removeEventListener(`click`,Ya(this,Za)),document.removeEventListener(`keydown`,Ya(this,Qa))))}};Za=new WeakMap,Qa=new WeakMap,to.getSlotTemplateHTML=$a,E.customElements.get(`media-keyboard-shortcuts-dialog`)||E.customElements.define(`media-keyboard-shortcuts-dialog`,to);var no=(e,t,n)=>{if(!t.has(e))throw TypeError(`Cannot `+n)},ro=(e,t,n)=>(no(e,t,`read from private field`),n?n.call(e):t.get(e)),io=(e,t,n)=>{if(t.has(e))throw TypeError(`Cannot add the same private member more than once`);t instanceof WeakSet?t.add(e):t.set(e,n)},ao=(e,t,n,r)=>(no(e,t,`write to private field`),r?r.call(e,n):t.set(e,n),n),oo,so=`<svg aria-hidden="true" viewBox="0 0 26 24">
  <path d="M16 3v2.5h3.5V9H22V3h-6ZM4 9h2.5V5.5H10V3H4v6Zm15.5 9.5H16V21h6v-6h-2.5v3.5ZM6.5 15H4v6h6v-2.5H6.5V15Z"/>
</svg>`,co=`<svg aria-hidden="true" viewBox="0 0 26 24">
  <path d="M18.5 6.5V3H16v6h6V6.5h-3.5ZM16 21h2.5v-3.5H22V15h-6v6ZM4 17.5h3.5V21H10v-6H4v2.5Zm3.5-11H4V9h6V3H7.5v3.5Z"/>
</svg>`;function lo(e){return`
    <style>
      :host([${y.MEDIA_IS_FULLSCREEN}]) slot[name=icon] slot:not([name=exit]) {
        display: none !important;
      }

      
      :host(:not([${y.MEDIA_IS_FULLSCREEN}])) slot[name=icon] slot:not([name=enter]) {
        display: none !important;
      }

      :host([${y.MEDIA_IS_FULLSCREEN}]) slot[name=tooltip-enter],
      :host(:not([${y.MEDIA_IS_FULLSCREEN}])) slot[name=tooltip-exit] {
        display: none;
      }
    </style>

    <slot name="icon">
      <slot name="enter">${so}</slot>
      <slot name="exit">${co}</slot>
    </slot>
  `}function uo(){return`
    <slot name="tooltip-enter">${T(`Enter fullscreen mode`)}</slot>
    <slot name="tooltip-exit">${T(`Exit fullscreen mode`)}</slot>
  `}var fo=e=>{let t=e.mediaIsFullscreen?T(`exit fullscreen mode`):T(`enter fullscreen mode`);e.setAttribute(`aria-label`,t)},po=class extends G{constructor(){super(...arguments),io(this,oo,null)}static get observedAttributes(){return[...super.observedAttributes,y.MEDIA_IS_FULLSCREEN,y.MEDIA_FULLSCREEN_UNAVAILABLE]}connectedCallback(){super.connectedCallback(),fo(this)}attributeChangedCallback(e,t,n){super.attributeChangedCallback(e,t,n),e===y.MEDIA_IS_FULLSCREEN&&fo(this)}get mediaFullscreenUnavailable(){return N(this,y.MEDIA_FULLSCREEN_UNAVAILABLE)}set mediaFullscreenUnavailable(e){P(this,y.MEDIA_FULLSCREEN_UNAVAILABLE,e)}get mediaIsFullscreen(){return j(this,y.MEDIA_IS_FULLSCREEN)}set mediaIsFullscreen(e){M(this,y.MEDIA_IS_FULLSCREEN,e)}handleClick(e){ao(this,oo,e);let t=ro(this,oo)instanceof PointerEvent,n=this.mediaIsFullscreen?new E.CustomEvent(_.MEDIA_EXIT_FULLSCREEN_REQUEST,{composed:!0,bubbles:!0}):new E.CustomEvent(_.MEDIA_ENTER_FULLSCREEN_REQUEST,{composed:!0,bubbles:!0,detail:t});this.dispatchEvent(n)}};oo=new WeakMap,po.getSlotTemplateHTML=lo,po.getTooltipContentHTML=uo,E.customElements.get(`media-fullscreen-button`)||E.customElements.define(`media-fullscreen-button`,po);var{MEDIA_TIME_IS_LIVE:mo,MEDIA_PAUSED:ho}=y,{MEDIA_SEEK_TO_LIVE_REQUEST:go,MEDIA_PLAY_REQUEST:_o}=_,vo=`<svg viewBox="0 0 6 12" aria-hidden="true"><circle cx="3" cy="6" r="2"></circle></svg>`;function yo(e){return`
    <style>
      :host { --media-tooltip-display: none; }
      
      slot[name=indicator] > *,
      :host ::slotted([slot=indicator]) {
        
        min-width: auto;
        fill: var(--media-live-button-icon-color, rgb(140, 140, 140));
        color: var(--media-live-button-icon-color, rgb(140, 140, 140));
      }

      :host([${mo}]:not([${ho}])) slot[name=indicator] > *,
      :host([${mo}]:not([${ho}])) ::slotted([slot=indicator]) {
        fill: var(--media-live-button-indicator-color, rgb(255, 0, 0));
        color: var(--media-live-button-indicator-color, rgb(255, 0, 0));
      }

      :host([${mo}]:not([${ho}])) {
        cursor: var(--media-cursor, not-allowed);
      }

      slot[name=text]{
        text-transform: uppercase;
      }

    </style>

    <slot name="indicator">${vo}</slot>
    
    <slot name="spacer">&nbsp;</slot><slot name="text">${T(`live`)}</slot>
  `}var bo=e=>{let t=e.mediaPaused||!e.mediaTimeIsLive,n=T(t?`seek to live`:`playing live`);e.setAttribute(`aria-label`,n);let r=e.shadowRoot?.querySelector(`slot[name="text"]`);r&&(r.textContent=T(`live`)),t?e.removeAttribute(`aria-disabled`):e.setAttribute(`aria-disabled`,`true`)},xo=class extends G{static get observedAttributes(){return[...super.observedAttributes,mo,ho]}connectedCallback(){super.connectedCallback(),bo(this)}attributeChangedCallback(e,t,n){super.attributeChangedCallback(e,t,n),bo(this)}get mediaPaused(){return j(this,y.MEDIA_PAUSED)}set mediaPaused(e){M(this,y.MEDIA_PAUSED,e)}get mediaTimeIsLive(){return j(this,y.MEDIA_TIME_IS_LIVE)}set mediaTimeIsLive(e){M(this,y.MEDIA_TIME_IS_LIVE,e)}handleClick(){!this.mediaPaused&&this.mediaTimeIsLive||(this.dispatchEvent(new E.CustomEvent(go,{composed:!0,bubbles:!0})),this.hasAttribute(ho)&&this.dispatchEvent(new E.CustomEvent(_o,{composed:!0,bubbles:!0})))}};xo.getSlotTemplateHTML=yo,E.customElements.get(`media-live-button`)||E.customElements.define(`media-live-button`,xo);var So=(e,t,n)=>{if(!t.has(e))throw TypeError(`Cannot `+n)},Co=(e,t,n)=>(So(e,t,`read from private field`),n?n.call(e):t.get(e)),wo=(e,t,n)=>{if(t.has(e))throw TypeError(`Cannot add the same private member more than once`);t instanceof WeakSet?t.add(e):t.set(e,n)},To=(e,t,n,r)=>(So(e,t,`write to private field`),r?r.call(e,n):t.set(e,n),n),Eo,Do,Oo={LOADING_DELAY:`loadingdelay`,NO_AUTOHIDE:`noautohide`},ko=500,Ao=`
<svg aria-hidden="true" viewBox="0 0 100 100">
  <path d="M73,50c0-12.7-10.3-23-23-23S27,37.3,27,50 M30.9,50c0-10.5,8.5-19.1,19.1-19.1S69.1,39.5,69.1,50">
    <animateTransform
       attributeName="transform"
       attributeType="XML"
       type="rotate"
       dur="1s"
       from="0 50 50"
       to="360 50 50"
       repeatCount="indefinite" />
  </path>
</svg>
`;function jo(e){return`
    <style>
      :host {
        display: var(--media-control-display, var(--media-loading-indicator-display, inline-block));
        vertical-align: middle;
        box-sizing: border-box;
        --_loading-indicator-delay: var(--media-loading-indicator-transition-delay, ${ko}ms);
      }

      #status {
        color: rgba(0,0,0,0);
        width: 0px;
        height: 0px;
      }

      :host slot[name=icon] > *,
      :host ::slotted([slot=icon]) {
        opacity: var(--media-loading-indicator-opacity, 0);
        transition: opacity 0.15s;
      }

      :host([${y.MEDIA_LOADING}]:not([${y.MEDIA_PAUSED}])) slot[name=icon] > *,
      :host([${y.MEDIA_LOADING}]:not([${y.MEDIA_PAUSED}])) ::slotted([slot=icon]) {
        opacity: var(--media-loading-indicator-opacity, 1);
        transition: opacity 0.15s var(--_loading-indicator-delay);
      }

      :host #status {
        visibility: var(--media-loading-indicator-opacity, hidden);
        transition: visibility 0.15s;
      }

      :host([${y.MEDIA_LOADING}]:not([${y.MEDIA_PAUSED}])) #status {
        visibility: var(--media-loading-indicator-opacity, visible);
        transition: visibility 0.15s var(--_loading-indicator-delay);
      }

      svg, img, ::slotted(svg), ::slotted(img) {
        width: var(--media-loading-indicator-icon-width);
        height: var(--media-loading-indicator-icon-height, 100px);
        fill: var(--media-icon-color, var(--media-primary-color, rgb(238 238 238)));
        vertical-align: middle;
      }
    </style>

    <slot name="icon">${Ao}</slot>
    <div id="status" role="status" aria-live="polite">${T(`media loading`)}</div>
  `}var Mo=class extends E.HTMLElement{constructor(){if(super(),wo(this,Eo,void 0),wo(this,Do,ko),!this.shadowRoot){this.attachShadow(this.constructor.shadowRootOptions);let e=Ge(this.attributes);this.shadowRoot.innerHTML=this.constructor.getTemplateHTML(e)}}static get observedAttributes(){return[v.MEDIA_CONTROLLER,y.MEDIA_PAUSED,y.MEDIA_LOADING,Oo.LOADING_DELAY]}attributeChangedCallback(e,t,n){var r,i,a,o;e===Oo.LOADING_DELAY&&t!==n?this.loadingDelay=Number(n):e===v.MEDIA_CONTROLLER&&(t&&((i=(r=Co(this,Eo))?.unassociateElement)==null||i.call(r,this),To(this,Eo,null)),n&&this.isConnected&&(To(this,Eo,this.getRootNode()?.getElementById(n)),(o=(a=Co(this,Eo))?.associateElement)==null||o.call(a,this)))}connectedCallback(){var e,t;let n=this.getAttribute(v.MEDIA_CONTROLLER);n&&(To(this,Eo,this.getRootNode()?.getElementById(n)),(t=(e=Co(this,Eo))?.associateElement)==null||t.call(e,this))}disconnectedCallback(){var e,t;(t=(e=Co(this,Eo))?.unassociateElement)==null||t.call(e,this),To(this,Eo,null)}get loadingDelay(){return Co(this,Do)}set loadingDelay(e){To(this,Do,e);let{style:t}=O(this.shadowRoot,`:host`);t.setProperty(`--_loading-indicator-delay`,`var(--media-loading-indicator-transition-delay, ${e}ms)`)}get mediaPaused(){return j(this,y.MEDIA_PAUSED)}set mediaPaused(e){M(this,y.MEDIA_PAUSED,e)}get mediaLoading(){return j(this,y.MEDIA_LOADING)}set mediaLoading(e){M(this,y.MEDIA_LOADING,e)}get mediaController(){return N(this,v.MEDIA_CONTROLLER)}set mediaController(e){P(this,v.MEDIA_CONTROLLER,e)}get noAutohide(){return j(this,Oo.NO_AUTOHIDE)}set noAutohide(e){M(this,Oo.NO_AUTOHIDE,e)}};Eo=new WeakMap,Do=new WeakMap,Mo.shadowRootOptions={mode:`open`},Mo.getTemplateHTML=jo,E.customElements.get(`media-loading-indicator`)||E.customElements.define(`media-loading-indicator`,Mo);var No=`<svg aria-hidden="true" viewBox="0 0 24 24">
  <path d="M16.5 12A4.5 4.5 0 0 0 14 8v2.18l2.45 2.45a4.22 4.22 0 0 0 .05-.63Zm2.5 0a6.84 6.84 0 0 1-.54 2.64L20 16.15A8.8 8.8 0 0 0 21 12a9 9 0 0 0-7-8.77v2.06A7 7 0 0 1 19 12ZM4.27 3 3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25A6.92 6.92 0 0 1 14 18.7v2.06A9 9 0 0 0 17.69 19l2 2.05L21 19.73l-9-9L4.27 3ZM12 4 9.91 6.09 12 8.18V4Z"/>
</svg>`,Po=`<svg aria-hidden="true" viewBox="0 0 24 24">
  <path d="M3 9v6h4l5 5V4L7 9H3Zm13.5 3A4.5 4.5 0 0 0 14 8v8a4.47 4.47 0 0 0 2.5-4Z"/>
</svg>`,Fo=`<svg aria-hidden="true" viewBox="0 0 24 24">
  <path d="M3 9v6h4l5 5V4L7 9H3Zm13.5 3A4.5 4.5 0 0 0 14 8v8a4.47 4.47 0 0 0 2.5-4ZM14 3.23v2.06a7 7 0 0 1 0 13.42v2.06a9 9 0 0 0 0-17.54Z"/>
</svg>`;function Io(e){return`
    <style>
      :host(:not([${y.MEDIA_VOLUME_LEVEL}])) slot[name=icon] slot:not([name=high]),
      :host([${y.MEDIA_VOLUME_LEVEL}=high]) slot[name=icon] slot:not([name=high]) {
        display: none !important;
      }

      :host([${y.MEDIA_VOLUME_LEVEL}=off]) slot[name=icon] slot:not([name=off]) {
        display: none !important;
      }

      :host([${y.MEDIA_VOLUME_LEVEL}=low]) slot[name=icon] slot:not([name=low]) {
        display: none !important;
      }

      :host([${y.MEDIA_VOLUME_LEVEL}=medium]) slot[name=icon] slot:not([name=medium]) {
        display: none !important;
      }

      :host(:not([${y.MEDIA_VOLUME_LEVEL}=off])) slot[name=tooltip-unmute],
      :host([${y.MEDIA_VOLUME_LEVEL}=off]) slot[name=tooltip-mute] {
        display: none;
      }
    </style>

    <slot name="icon">
      <slot name="off">${No}</slot>
      <slot name="low">${Po}</slot>
      <slot name="medium">${Po}</slot>
      <slot name="high">${Fo}</slot>
    </slot>
  `}function Lo(){return`
    <slot name="tooltip-mute">${T(`Mute`)}</slot>
    <slot name="tooltip-unmute">${T(`Unmute`)}</slot>
  `}var Ro=e=>{let t=e.mediaVolumeLevel===`off`?T(`unmute`):T(`mute`);e.setAttribute(`aria-label`,t)},zo=class extends G{static get observedAttributes(){return[...super.observedAttributes,y.MEDIA_VOLUME_LEVEL]}connectedCallback(){super.connectedCallback(),Ro(this)}attributeChangedCallback(e,t,n){super.attributeChangedCallback(e,t,n),e===y.MEDIA_VOLUME_LEVEL&&Ro(this)}get mediaVolumeLevel(){return N(this,y.MEDIA_VOLUME_LEVEL)}set mediaVolumeLevel(e){P(this,y.MEDIA_VOLUME_LEVEL,e)}handleClick(){let e=this.mediaVolumeLevel===`off`?_.MEDIA_UNMUTE_REQUEST:_.MEDIA_MUTE_REQUEST;this.dispatchEvent(new E.CustomEvent(e,{composed:!0,bubbles:!0}))}};zo.getSlotTemplateHTML=Io,zo.getTooltipContentHTML=Lo,E.customElements.get(`media-mute-button`)||E.customElements.define(`media-mute-button`,zo);var Bo=`<svg aria-hidden="true" viewBox="0 0 28 24">
  <path d="M24 3H4a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h20a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1Zm-1 16H5V5h18v14Zm-3-8h-7v5h7v-5Z"/>
</svg>`;function Vo(e){return`
    <style>
      :host([${y.MEDIA_IS_PIP}]) slot[name=icon] slot:not([name=exit]) {
        display: none !important;
      }

      :host(:not([${y.MEDIA_IS_PIP}])) slot[name=icon] slot:not([name=enter]) {
        display: none !important;
      }

      :host([${y.MEDIA_IS_PIP}]) slot[name=tooltip-enter],
      :host(:not([${y.MEDIA_IS_PIP}])) slot[name=tooltip-exit] {
        display: none;
      }
    </style>

    <slot name="icon">
      <slot name="enter">${Bo}</slot>
      <slot name="exit">${Bo}</slot>
    </slot>
  `}function Ho(){return`
    <slot name="tooltip-enter">${T(`Enter picture in picture mode`)}</slot>
    <slot name="tooltip-exit">${T(`Exit picture in picture mode`)}</slot>
  `}var Uo=e=>{let t=e.mediaIsPip?T(`exit picture in picture mode`):T(`enter picture in picture mode`);e.setAttribute(`aria-label`,t)},Wo=class extends G{static get observedAttributes(){return[...super.observedAttributes,y.MEDIA_IS_PIP,y.MEDIA_PIP_UNAVAILABLE]}connectedCallback(){super.connectedCallback(),Uo(this)}attributeChangedCallback(e,t,n){super.attributeChangedCallback(e,t,n),e===y.MEDIA_IS_PIP&&Uo(this)}get mediaPipUnavailable(){return N(this,y.MEDIA_PIP_UNAVAILABLE)}set mediaPipUnavailable(e){P(this,y.MEDIA_PIP_UNAVAILABLE,e)}get mediaIsPip(){return j(this,y.MEDIA_IS_PIP)}set mediaIsPip(e){M(this,y.MEDIA_IS_PIP,e)}handleClick(){let e=this.mediaIsPip?_.MEDIA_EXIT_PIP_REQUEST:_.MEDIA_ENTER_PIP_REQUEST;this.dispatchEvent(new E.CustomEvent(e,{composed:!0,bubbles:!0}))}};Wo.getSlotTemplateHTML=Vo,Wo.getTooltipContentHTML=Ho,E.customElements.get(`media-pip-button`)||E.customElements.define(`media-pip-button`,Wo);var Go=(e,t,n)=>{if(!t.has(e))throw TypeError(`Cannot `+n)},Ko=(e,t,n)=>(Go(e,t,`read from private field`),n?n.call(e):t.get(e)),qo=(e,t,n)=>{if(t.has(e))throw TypeError(`Cannot add the same private member more than once`);t instanceof WeakSet?t.add(e):t.set(e,n)},Jo,Yo={RATES:`rates`},Xo=[1,1.2,1.5,1.7,2];function Zo(e){return Math.round(e*100)/100}function Qo(e){return`
    <style>
      :host {
        min-width: 5ch;
        padding: var(--media-button-padding, var(--media-control-padding, 10px 5px));
      }
    </style>
    <slot name="icon">${e.mediaplaybackrate?Zo(+e.mediaplaybackrate):1}x</slot>
  `}function $o(){return T(`Playback rate`)}var es=class extends G{constructor(){super(),qo(this,Jo,new $t(this,Yo.RATES,{defaultValue:Xo})),this.container=this.shadowRoot.querySelector(`slot[name="icon"]`),this.container.innerHTML=`${Zo(this.mediaPlaybackRate??1)}x`}static get observedAttributes(){return[...super.observedAttributes,y.MEDIA_PLAYBACK_RATE,Yo.RATES]}attributeChangedCallback(e,t,n){if(super.attributeChangedCallback(e,t,n),e===Yo.RATES&&(Ko(this,Jo).value=n),e===y.MEDIA_PLAYBACK_RATE){let e=n?+n:NaN,t=Zo(Number.isNaN(e)?1:e);this.container.innerHTML=`${t}x`,this.setAttribute(`aria-label`,T(`Playback rate {playbackRate}`,{playbackRate:t}))}}get rates(){return Ko(this,Jo)}set rates(e){e?Array.isArray(e)?Ko(this,Jo).value=e.join(` `):typeof e==`string`&&(Ko(this,Jo).value=e):Ko(this,Jo).value=``}get mediaPlaybackRate(){return k(this,y.MEDIA_PLAYBACK_RATE,1)}set mediaPlaybackRate(e){A(this,y.MEDIA_PLAYBACK_RATE,e)}handleClick(){let e=Array.from(Ko(this,Jo).values(),e=>+e).sort((e,t)=>e-t),t=e.find(e=>e>this.mediaPlaybackRate)??e[0]??1,n=new E.CustomEvent(_.MEDIA_PLAYBACK_RATE_REQUEST,{composed:!0,bubbles:!0,detail:t});this.dispatchEvent(n)}};Jo=new WeakMap,es.getSlotTemplateHTML=Qo,es.getTooltipContentHTML=$o,E.customElements.get(`media-playback-rate-button`)||E.customElements.define(`media-playback-rate-button`,es);var ts=`<svg aria-hidden="true" viewBox="0 0 24 24">
  <path d="m6 21 15-9L6 3v18Z"/>
</svg>`,ns=`<svg aria-hidden="true" viewBox="0 0 24 24">
  <path d="M6 20h4V4H6v16Zm8-16v16h4V4h-4Z"/>
</svg>`;function rs(e){return`
    <style>
      :host([${y.MEDIA_PAUSED}]) slot[name=pause],
      :host(:not([${y.MEDIA_PAUSED}])) slot[name=play] {
        display: none !important;
      }

      :host([${y.MEDIA_PAUSED}]) slot[name=tooltip-pause],
      :host(:not([${y.MEDIA_PAUSED}])) slot[name=tooltip-play] {
        display: none;
      }
    </style>

    <slot name="icon">
      <slot name="play">${ts}</slot>
      <slot name="pause">${ns}</slot>
    </slot>
  `}function is(){return`
    <slot name="tooltip-play">${T(`Play`)}</slot>
    <slot name="tooltip-pause">${T(`Pause`)}</slot>
  `}var as=e=>{let t=e.mediaPaused?T(`play`):T(`pause`);e.setAttribute(`aria-label`,t)},os=class extends G{static get observedAttributes(){return[...super.observedAttributes,y.MEDIA_PAUSED,y.MEDIA_ENDED]}connectedCallback(){super.connectedCallback(),as(this)}attributeChangedCallback(e,t,n){super.attributeChangedCallback(e,t,n),(e===y.MEDIA_PAUSED||e===y.MEDIA_LANG)&&as(this)}get mediaPaused(){return j(this,y.MEDIA_PAUSED)}set mediaPaused(e){M(this,y.MEDIA_PAUSED,e)}handleClick(){let e=this.mediaPaused?_.MEDIA_PLAY_REQUEST:_.MEDIA_PAUSE_REQUEST;this.dispatchEvent(new E.CustomEvent(e,{composed:!0,bubbles:!0}))}};os.getSlotTemplateHTML=rs,os.getTooltipContentHTML=is,E.customElements.get(`media-play-button`)||E.customElements.define(`media-play-button`,os);var ss={PLACEHOLDER_SRC:`placeholdersrc`,SRC:`src`};function cs(e){return`
    <style>
      :host {
        pointer-events: none;
        display: var(--media-poster-image-display, inline-block);
        box-sizing: border-box;
      }

      img {
        max-width: 100%;
        max-height: 100%;
        min-width: 100%;
        min-height: 100%;
        background-repeat: no-repeat;
        background-position: var(--media-poster-image-background-position, var(--media-object-position, center));
        background-size: var(--media-poster-image-background-size, var(--media-object-fit, contain));
        object-fit: var(--media-object-fit, contain);
        object-position: var(--media-object-position, center);
      }
    </style>

    <img part="poster img" aria-hidden="true" id="image"/>
  `}var ls=e=>{e.style.removeProperty(`background-image`)},us=(e,t)=>{e.style[`background-image`]=`url('${t}')`},ds=class extends E.HTMLElement{static get observedAttributes(){return[ss.PLACEHOLDER_SRC,ss.SRC]}constructor(){if(super(),!this.shadowRoot){this.attachShadow(this.constructor.shadowRootOptions);let e=Ge(this.attributes);this.shadowRoot.innerHTML=this.constructor.getTemplateHTML(e)}this.image=this.shadowRoot.querySelector(`#image`)}attributeChangedCallback(e,t,n){e===ss.SRC&&(n==null?this.image.removeAttribute(ss.SRC):this.image.setAttribute(ss.SRC,n)),e===ss.PLACEHOLDER_SRC&&(n==null?ls(this.image):us(this.image,n))}get placeholderSrc(){return N(this,ss.PLACEHOLDER_SRC)}set placeholderSrc(e){P(this,ss.SRC,e)}get src(){return N(this,ss.SRC)}set src(e){P(this,ss.SRC,e)}};ds.shadowRootOptions={mode:`open`},ds.getTemplateHTML=cs,E.customElements.get(`media-poster-image`)||E.customElements.define(`media-poster-image`,ds);var fs=(e,t,n)=>{if(!t.has(e))throw TypeError(`Cannot `+n)},ps=(e,t,n)=>(fs(e,t,`read from private field`),n?n.call(e):t.get(e)),ms=(e,t,n)=>{if(t.has(e))throw TypeError(`Cannot add the same private member more than once`);t instanceof WeakSet?t.add(e):t.set(e,n)},hs=(e,t,n,r)=>(fs(e,t,`write to private field`),r?r.call(e,n):t.set(e,n),n),gs,_s=class extends Da{constructor(){super(),ms(this,gs,void 0),hs(this,gs,this.shadowRoot.querySelector(`slot`))}static get observedAttributes(){return[...super.observedAttributes,y.MEDIA_PREVIEW_CHAPTER,y.MEDIA_LANG]}attributeChangedCallback(e,t,n){if(super.attributeChangedCallback(e,t,n),(e===y.MEDIA_PREVIEW_CHAPTER||e===y.MEDIA_LANG)&&n!==t&&n!=null)if(ps(this,gs).textContent=n,n!==``){let e=T(`chapter: {chapterName}`,{chapterName:n});this.setAttribute(`aria-valuetext`,e)}else this.removeAttribute(`aria-valuetext`)}get mediaPreviewChapter(){return N(this,y.MEDIA_PREVIEW_CHAPTER)}set mediaPreviewChapter(e){P(this,y.MEDIA_PREVIEW_CHAPTER,e)}};gs=new WeakMap,E.customElements.get(`media-preview-chapter-display`)||E.customElements.define(`media-preview-chapter-display`,_s);var vs=(e,t,n)=>{if(!t.has(e))throw TypeError(`Cannot `+n)},ys=(e,t,n)=>(vs(e,t,`read from private field`),n?n.call(e):t.get(e)),bs=(e,t,n)=>{if(t.has(e))throw TypeError(`Cannot add the same private member more than once`);t instanceof WeakSet?t.add(e):t.set(e,n)},xs=(e,t,n,r)=>(vs(e,t,`write to private field`),r?r.call(e,n):t.set(e,n),n),Ss;function Cs(e){return`
    <style>
      :host {
        box-sizing: border-box;
        display: var(--media-control-display, var(--media-preview-thumbnail-display, inline-block));
        overflow: hidden;
      }

      img {
        display: none;
        position: relative;
      }
    </style>
    <img crossorigin loading="eager" decoding="async">
  `}var ws=class extends E.HTMLElement{constructor(){if(super(),bs(this,Ss,void 0),!this.shadowRoot){this.attachShadow(this.constructor.shadowRootOptions);let e=Ge(this.attributes);this.shadowRoot.innerHTML=this.constructor.getTemplateHTML(e)}}static get observedAttributes(){return[v.MEDIA_CONTROLLER,y.MEDIA_PREVIEW_IMAGE,y.MEDIA_PREVIEW_COORDS]}connectedCallback(){var e,t;let n=this.getAttribute(v.MEDIA_CONTROLLER);n&&(xs(this,Ss,this.getRootNode()?.getElementById(n)),(t=(e=ys(this,Ss))?.associateElement)==null||t.call(e,this))}disconnectedCallback(){var e,t;(t=(e=ys(this,Ss))?.unassociateElement)==null||t.call(e,this),xs(this,Ss,null)}attributeChangedCallback(e,t,n){var r,i,a,o;[y.MEDIA_PREVIEW_IMAGE,y.MEDIA_PREVIEW_COORDS].includes(e)&&this.update(),e===v.MEDIA_CONTROLLER&&(t&&((i=(r=ys(this,Ss))?.unassociateElement)==null||i.call(r,this),xs(this,Ss,null)),n&&this.isConnected&&(xs(this,Ss,this.getRootNode()?.getElementById(n)),(o=(a=ys(this,Ss))?.associateElement)==null||o.call(a,this)))}get mediaPreviewImage(){return N(this,y.MEDIA_PREVIEW_IMAGE)}set mediaPreviewImage(e){P(this,y.MEDIA_PREVIEW_IMAGE,e)}get mediaPreviewCoords(){let e=this.getAttribute(y.MEDIA_PREVIEW_COORDS);if(e)return e.split(/\s+/).map(e=>+e)}set mediaPreviewCoords(e){if(!e){this.removeAttribute(y.MEDIA_PREVIEW_COORDS);return}this.setAttribute(y.MEDIA_PREVIEW_COORDS,e.join(` `))}update(){let e=this.mediaPreviewCoords,t=this.mediaPreviewImage;if(!(e&&t))return;let[n,r,i,a]=e,o=t.split(`#`)[0],s=getComputedStyle(this),{maxWidth:c,maxHeight:l,minWidth:u,minHeight:d}=s,f=s.getPropertyValue(`--media-preview-thumbnail-object-fit`).trim()||`contain`,p,m;if(f===`fill`){let e=parseInt(c)/i,t=parseInt(l)/a,n=parseInt(u)/i,r=parseInt(d)/a;p=e<1?e:Math.max(e,n),m=t<1?t:Math.max(t,r)}else{let e=Math.min(parseInt(c)/i,parseInt(l)/a),t=Math.max(parseInt(u)/i,parseInt(d)/a),n=e<1?e:t>1?t:1;p=n,m=n}let{style:ee}=O(this.shadowRoot,`:host`),te=O(this.shadowRoot,`img`).style,h=this.shadowRoot.querySelector(`img`),g=Math.min(p,m)<1?`min`:`max`;ee.setProperty(`${g}-width`,`initial`,`important`),ee.setProperty(`${g}-height`,`initial`,`important`),ee.width=`${i*p}px`,ee.height=`${a*m}px`;let ne=()=>{te.width=`${this.imgWidth*p}px`,te.height=`${this.imgHeight*m}px`,te.display=`block`};h.src!==o&&(h.onload=()=>{this.imgWidth=h.naturalWidth,this.imgHeight=h.naturalHeight,ne(),h.onload=null},h.src=o,ne()),ne(),te.transform=`translate(-${n*p}px, -${r*m}px)`}};Ss=new WeakMap,ws.shadowRootOptions={mode:`open`},ws.getTemplateHTML=Cs,E.customElements.get(`media-preview-thumbnail`)||E.customElements.define(`media-preview-thumbnail`,ws);var Ts=ws,Es=(e,t,n)=>{if(!t.has(e))throw TypeError(`Cannot `+n)},Ds=(e,t,n)=>(Es(e,t,`read from private field`),n?n.call(e):t.get(e)),Os=(e,t,n)=>{if(t.has(e))throw TypeError(`Cannot add the same private member more than once`);t instanceof WeakSet?t.add(e):t.set(e,n)},ks=(e,t,n,r)=>(Es(e,t,`write to private field`),r?r.call(e,n):t.set(e,n),n),As,js=class extends Da{constructor(){super(),Os(this,As,void 0),ks(this,As,this.shadowRoot.querySelector(`slot`)),Ds(this,As).textContent=je(0)}static get observedAttributes(){return[...super.observedAttributes,y.MEDIA_PREVIEW_TIME]}attributeChangedCallback(e,t,n){super.attributeChangedCallback(e,t,n),e===y.MEDIA_PREVIEW_TIME&&n!=null&&(Ds(this,As).textContent=je(parseFloat(n)))}get mediaPreviewTime(){return k(this,y.MEDIA_PREVIEW_TIME)}set mediaPreviewTime(e){A(this,y.MEDIA_PREVIEW_TIME,e)}};As=new WeakMap,E.customElements.get(`media-preview-time-display`)||E.customElements.define(`media-preview-time-display`,js);var Ms={SEEK_OFFSET:`seekoffset`},Ns=30,Ps=e=>`
  <svg aria-hidden="true" viewBox="0 0 20 24">
    <defs>
      <style>.text{font-size:8px;font-family:Arial-BoldMT, Arial;font-weight:700;}</style>
    </defs>
    <text class="text value" transform="translate(2.18 19.87)">${e}</text>
    <path d="M10 6V3L4.37 7 10 10.94V8a5.54 5.54 0 0 1 1.9 10.48v2.12A7.5 7.5 0 0 0 10 6Z"/>
  </svg>`;function Fs(e,t){return`
    <slot name="icon">${Ps(t.seekOffset)}</slot>
  `}var Is=(e,t)=>{e.setAttribute(`aria-label`,T(`seek back {seekOffset} seconds`,{seekOffset:t}))};function Ls(){return T(`Seek backward`)}var Rs=0,zs=class extends G{static get observedAttributes(){return[...super.observedAttributes,y.MEDIA_CURRENT_TIME,Ms.SEEK_OFFSET]}connectedCallback(){super.connectedCallback(),this.seekOffset=k(this,Ms.SEEK_OFFSET,Ns)}attributeChangedCallback(e,t,n){super.attributeChangedCallback(e,t,n),Is(this,this.seekOffset),e===Ms.SEEK_OFFSET&&(this.seekOffset=k(this,Ms.SEEK_OFFSET,Ns))}get seekOffset(){return k(this,Ms.SEEK_OFFSET,Ns)}set seekOffset(e){A(this,Ms.SEEK_OFFSET,e),this.setAttribute(`aria-label`,T(`seek back {seekOffset} seconds`,{seekOffset:this.seekOffset})),Je(Xe(this,`icon`),this.seekOffset)}get mediaCurrentTime(){return k(this,y.MEDIA_CURRENT_TIME,Rs)}set mediaCurrentTime(e){A(this,y.MEDIA_CURRENT_TIME,e)}handleClick(){let e=Math.max(this.mediaCurrentTime-this.seekOffset,0),t=new E.CustomEvent(_.MEDIA_SEEK_REQUEST,{composed:!0,bubbles:!0,detail:e});this.dispatchEvent(t)}};zs.getSlotTemplateHTML=Fs,zs.getTooltipContentHTML=Ls,E.customElements.get(`media-seek-backward-button`)||E.customElements.define(`media-seek-backward-button`,zs);var Bs={SEEK_OFFSET:`seekoffset`},Vs=30,Hs=e=>`
  <svg aria-hidden="true" viewBox="0 0 20 24">
    <defs>
      <style>.text{font-size:8px;font-family:Arial-BoldMT, Arial;font-weight:700;}</style>
    </defs>
    <text class="text value" transform="translate(8.9 19.87)">${e}</text>
    <path d="M10 6V3l5.61 4L10 10.94V8a5.54 5.54 0 0 0-1.9 10.48v2.12A7.5 7.5 0 0 1 10 6Z"/>
  </svg>`;function Us(e,t){return`
    <slot name="icon">${Hs(t.seekOffset)}</slot>
  `}var Ws=(e,t)=>{e.setAttribute(`aria-label`,T(`seek forward {seekOffset} seconds`,{seekOffset:t}))};function Gs(){return T(`Seek forward`)}var Ks=0,qs=class extends G{static get observedAttributes(){return[...super.observedAttributes,y.MEDIA_CURRENT_TIME,Bs.SEEK_OFFSET]}connectedCallback(){super.connectedCallback(),this.seekOffset=k(this,Bs.SEEK_OFFSET,Vs)}attributeChangedCallback(e,t,n){super.attributeChangedCallback(e,t,n),Ws(this,this.seekOffset),e===Bs.SEEK_OFFSET&&(this.seekOffset=k(this,Bs.SEEK_OFFSET,Vs))}get seekOffset(){return k(this,Bs.SEEK_OFFSET,Vs)}set seekOffset(e){A(this,Bs.SEEK_OFFSET,e),this.setAttribute(`aria-label`,T(`seek forward {seekOffset} seconds`,{seekOffset:this.seekOffset})),Je(Xe(this,`icon`),this.seekOffset)}get mediaCurrentTime(){return k(this,y.MEDIA_CURRENT_TIME,Ks)}set mediaCurrentTime(e){A(this,y.MEDIA_CURRENT_TIME,e)}handleClick(){let e=this.mediaCurrentTime+this.seekOffset,t=new E.CustomEvent(_.MEDIA_SEEK_REQUEST,{composed:!0,bubbles:!0,detail:e});this.dispatchEvent(t)}};qs.getSlotTemplateHTML=Us,qs.getTooltipContentHTML=Gs,E.customElements.get(`media-seek-forward-button`)||E.customElements.define(`media-seek-forward-button`,qs);var Js=(e,t,n)=>{if(!t.has(e))throw TypeError(`Cannot `+n)},Ys=(e,t,n)=>(Js(e,t,`read from private field`),n?n.call(e):t.get(e)),Xs=(e,t,n)=>{if(t.has(e))throw TypeError(`Cannot add the same private member more than once`);t instanceof WeakSet?t.add(e):t.set(e,n)},Zs=(e,t,n,r)=>(Js(e,t,`write to private field`),r?r.call(e,n):t.set(e,n),n),Qs=(e,t,n)=>(Js(e,t,`access private method`),n),$s,ec,tc,nc,rc,ic,ac,oc,sc,cc,lc,uc={REMAINING:`remaining`,SHOW_DURATION:`showduration`,NO_TOGGLE:`notoggle`},dc=[...Object.values(uc),y.MEDIA_CURRENT_TIME,y.MEDIA_DURATION,y.MEDIA_SEEKABLE],fc=[`Enter`,` `],pc=`&nbsp;/&nbsp;`,mc=(e,{timesSep:t=pc}={})=>{let n=e.mediaCurrentTime??0,[,r]=e.mediaSeekable??[],i=0;Number.isFinite(e.mediaDuration)?i=e.mediaDuration:Number.isFinite(r)&&(i=r);let a=e.remaining?je(0-(i-n)):je(n);return e.showDuration?`${a}${t}${je(i)}`:a},hc=e=>{let t=e.mediaCurrentTime,[,n]=e.mediaSeekable??[],r=null;if(Number.isFinite(e.mediaDuration)?r=e.mediaDuration:Number.isFinite(n)&&(r=n),t==null||r===null){e.setAttribute(`aria-description`,T(`video not loaded, unknown time.`));return}let i=e.remaining?Ae(0-(r-t)):Ae(t);if(!e.showDuration){e.setAttribute(`aria-description`,i);return}let a=T(`{currentTime} of {totalTime}`,{currentTime:i,totalTime:Ae(r)});e.setAttribute(`aria-description`,a)};function gc(e,t){return`
    <slot>${mc(t)}</slot>
  `}var _c=e=>{e.setAttribute(`aria-label`,T(`playback time`))},vc=class extends Da{constructor(){super(),Xs(this,nc),Xs(this,ic),Xs(this,oc),Xs(this,cc),Xs(this,$s,void 0),Xs(this,ec,null),Xs(this,tc,e=>{let{metaKey:t,altKey:n,key:r}=e;if(t||n||!fc.includes(r)){this.removeEventListener(`keyup`,Ys(this,ec));return}this.addEventListener(`keyup`,Ys(this,ec))}),Zs(this,$s,this.shadowRoot.querySelector(`slot`)),Ys(this,$s).innerHTML=`${mc(this)}`}static get observedAttributes(){return[...super.observedAttributes,...dc,`disabled`]}connectedCallback(){let{style:e}=O(this.shadowRoot,`:host(:hover:not([notoggle]))`);e.setProperty(`cursor`,`var(--media-cursor, pointer)`),e.setProperty(`background`,`var(--media-control-hover-background, rgba(50 50 70 / .7))`),this.setAttribute(`aria-label`,T(`playback time`)),Qs(this,oc,sc).call(this),super.connectedCallback()}toggleTimeDisplay(){this.noToggle||(this.hasAttribute(`remaining`)?this.removeAttribute(`remaining`):this.setAttribute(`remaining`,``))}disconnectedCallback(){this.disable(),Qs(this,ic,ac).call(this),super.disconnectedCallback()}attributeChangedCallback(e,t,n){_c(this),dc.includes(e)?this.update():e===`disabled`&&n!==t?n==null?Qs(this,oc,sc).call(this):Qs(this,cc,lc).call(this):e===uc.NO_TOGGLE&&n!==t&&(this.noToggle?Qs(this,cc,lc).call(this):Qs(this,oc,sc).call(this)),super.attributeChangedCallback(e,t,n)}enable(){this.noToggle||(this.tabIndex=0)}disable(){this.tabIndex=-1}get remaining(){return j(this,uc.REMAINING)}set remaining(e){M(this,uc.REMAINING,e)}get showDuration(){return j(this,uc.SHOW_DURATION)}set showDuration(e){M(this,uc.SHOW_DURATION,e)}get noToggle(){return j(this,uc.NO_TOGGLE)}set noToggle(e){M(this,uc.NO_TOGGLE,e)}get mediaDuration(){return k(this,y.MEDIA_DURATION)}set mediaDuration(e){A(this,y.MEDIA_DURATION,e)}get mediaCurrentTime(){return k(this,y.MEDIA_CURRENT_TIME)}set mediaCurrentTime(e){A(this,y.MEDIA_CURRENT_TIME,e)}get mediaSeekable(){let e=this.getAttribute(y.MEDIA_SEEKABLE);if(e)return e.split(`:`).map(e=>+e)}set mediaSeekable(e){if(e==null){this.removeAttribute(y.MEDIA_SEEKABLE);return}this.setAttribute(y.MEDIA_SEEKABLE,e.join(`:`))}update(){let e=mc(this);hc(this),e!==Ys(this,$s).innerHTML&&(Ys(this,$s).innerHTML=e)}};$s=new WeakMap,ec=new WeakMap,tc=new WeakMap,nc=new WeakSet,rc=function(){Ys(this,ec)||(Zs(this,ec,e=>{let{key:t}=e;if(!fc.includes(t)){this.removeEventListener(`keyup`,Ys(this,ec));return}this.toggleTimeDisplay()}),this.addEventListener(`keydown`,Ys(this,tc)),this.addEventListener(`click`,this.toggleTimeDisplay))},ic=new WeakSet,ac=function(){Ys(this,ec)&&(this.removeEventListener(`keyup`,Ys(this,ec)),this.removeEventListener(`keydown`,Ys(this,tc)),this.removeEventListener(`click`,this.toggleTimeDisplay),Zs(this,ec,null))},oc=new WeakSet,sc=function(){!this.noToggle&&!this.hasAttribute(`disabled`)&&(this.setAttribute(`role`,`button`),this.enable(),Qs(this,nc,rc).call(this))},cc=new WeakSet,lc=function(){this.removeAttribute(`role`),this.disable(),Qs(this,ic,ac).call(this)},vc.getSlotTemplateHTML=gc,E.customElements.get(`media-time-display`)||E.customElements.define(`media-time-display`,vc);var yc=(e,t,n)=>{if(!t.has(e))throw TypeError(`Cannot `+n)},J=(e,t,n)=>(yc(e,t,`read from private field`),n?n.call(e):t.get(e)),bc=(e,t,n)=>{if(t.has(e))throw TypeError(`Cannot add the same private member more than once`);t instanceof WeakSet?t.add(e):t.set(e,n)},Y=(e,t,n,r)=>(yc(e,t,`write to private field`),r?r.call(e,n):t.set(e,n),n),xc=(e,t,n,r)=>({set _(r){Y(e,t,r,n)},get _(){return J(e,t,r)}}),Sc,Cc,wc,Tc,Ec,Dc,Oc,kc,Ac,jc,Mc=class{constructor(e,t,n){bc(this,Sc,void 0),bc(this,Cc,void 0),bc(this,wc,void 0),bc(this,Tc,void 0),bc(this,Ec,void 0),bc(this,Dc,void 0),bc(this,Oc,void 0),bc(this,kc,void 0),bc(this,Ac,0),bc(this,jc,(e=performance.now())=>{Y(this,Ac,requestAnimationFrame(J(this,jc))),Y(this,Tc,performance.now()-J(this,wc));let t=1e3/this.fps;if(J(this,Tc)>t){Y(this,wc,e-J(this,Tc)%t);let n=1e3/((e-J(this,Cc))/++xc(this,Ec)._),r=(e-J(this,Dc))/1e3/this.duration,i=J(this,Oc)+r*this.playbackRate;i-J(this,Sc).valueAsNumber>0?Y(this,kc,this.playbackRate/this.duration/n):(Y(this,kc,.995*J(this,kc)),i=J(this,Sc).valueAsNumber+J(this,kc)),this.callback(i)}}),Y(this,Sc,e),this.callback=t,this.fps=n}start(){J(this,Ac)===0&&(Y(this,wc,performance.now()),Y(this,Cc,J(this,wc)),Y(this,Ec,0),J(this,jc).call(this))}stop(){J(this,Ac)!==0&&(cancelAnimationFrame(J(this,Ac)),Y(this,Ac,0))}update({start:e,duration:t,playbackRate:n}){let r=e-J(this,Sc).valueAsNumber,i=Math.abs(t-this.duration);(r>0||r<-.03||i>=.5)&&this.callback(e),Y(this,Oc,e),Y(this,Dc,performance.now()),this.duration=t,this.playbackRate=n}};Sc=new WeakMap,Cc=new WeakMap,wc=new WeakMap,Tc=new WeakMap,Ec=new WeakMap,Dc=new WeakMap,Oc=new WeakMap,kc=new WeakMap,Ac=new WeakMap,jc=new WeakMap;var Nc=(e,t,n)=>{if(!t.has(e))throw TypeError(`Cannot `+n)},X=(e,t,n)=>(Nc(e,t,`read from private field`),n?n.call(e):t.get(e)),Z=(e,t,n)=>{if(t.has(e))throw TypeError(`Cannot add the same private member more than once`);t instanceof WeakSet?t.add(e):t.set(e,n)},Q=(e,t,n,r)=>(Nc(e,t,`write to private field`),r?r.call(e,n):t.set(e,n),n),$=(e,t,n)=>(Nc(e,t,`access private method`),n),Pc,Fc,Ic,Lc,Rc,zc,Bc,Vc,Hc,Uc,Wc,Gc,Kc,qc,Jc,Yc,Xc,Zc,Qc,$c,el,tl,nl,rl,il,al,ol=e=>{let t=e.range,n=Ae(+ll(e)),r=Ae(+e.mediaSeekableEnd),i=n&&r?T(`{currentTime} of {totalTime}`,{currentTime:n,totalTime:r}):T(`video not loaded, unknown time.`);t.setAttribute(`aria-valuetext`,i)};function sl(e){return`
    <style>
      :host {
        --media-box-border-radius: 4px;
        --media-box-padding-left: 10px;
        --media-box-padding-right: 10px;
        --media-preview-border-radius: var(--media-box-border-radius);
        --media-box-arrow-offset: var(--media-box-border-radius);
        --_control-background: var(--media-control-background, var(--media-secondary-color, rgb(20 20 30 / .7)));
        --_preview-background: var(--media-preview-background, var(--_control-background));

        
        contain: layout;
      }

      #buffered {
        background: var(--media-time-range-buffered-color, rgb(255 255 255 / .4));
        position: absolute;
        height: 100%;
        will-change: width;
      }

      #preview-rail,
      #current-rail {
        width: 100%;
        position: absolute;
        left: 0;
        bottom: 100%;
        pointer-events: none;
        will-change: transform;
      }

      [part~="box"] {
        width: min-content;
        
        position: absolute;
        bottom: 100%;
        flex-direction: column;
        align-items: center;
        transform: translateX(-50%);
      }

      [part~="current-box"] {
        display: var(--media-current-box-display, var(--media-box-display, flex));
        margin: var(--media-current-box-margin, var(--media-box-margin, 0 0 5px));
        visibility: hidden;
      }

      [part~="preview-box"] {
        display: var(--media-preview-box-display, var(--media-box-display, flex));
        margin: var(--media-preview-box-margin, var(--media-box-margin, 0 0 5px));
        transition-property: var(--media-preview-transition-property, visibility, opacity);
        transition-duration: var(--media-preview-transition-duration-out, .25s);
        transition-delay: var(--media-preview-transition-delay-out, 0s);
        visibility: hidden;
        opacity: 0;
      }

      :host(:is([${y.MEDIA_PREVIEW_IMAGE}], [${y.MEDIA_PREVIEW_TIME}])[dragging]) [part~="preview-box"] {
        transition-duration: var(--media-preview-transition-duration-in, .5s);
        transition-delay: var(--media-preview-transition-delay-in, .25s);
        visibility: visible;
        opacity: 1;
      }

      @media (hover: hover) {
        :host(:is([${y.MEDIA_PREVIEW_IMAGE}], [${y.MEDIA_PREVIEW_TIME}]):hover) [part~="preview-box"] {
          transition-duration: var(--media-preview-transition-duration-in, .5s);
          transition-delay: var(--media-preview-transition-delay-in, .25s);
          visibility: visible;
          opacity: 1;
        }
      }

      media-preview-thumbnail,
      ::slotted(media-preview-thumbnail) {
        visibility: hidden;
        
        transition: visibility 0s .25s;
        transition-delay: calc(var(--media-preview-transition-delay-out, 0s) + var(--media-preview-transition-duration-out, .25s));
        background: var(--media-preview-thumbnail-background, var(--_preview-background));
        box-shadow: var(--media-preview-thumbnail-box-shadow, 0 0 4px rgb(0 0 0 / .2));
        max-width: var(--media-preview-thumbnail-max-width, 180px);
        max-height: var(--media-preview-thumbnail-max-height, 160px);
        min-width: var(--media-preview-thumbnail-min-width, 120px);
        min-height: var(--media-preview-thumbnail-min-height, 80px);
        border: var(--media-preview-thumbnail-border);
        border-radius: var(--media-preview-thumbnail-border-radius,
          var(--media-preview-border-radius) var(--media-preview-border-radius) 0 0);
      }

      :host([${y.MEDIA_PREVIEW_IMAGE}][dragging]) media-preview-thumbnail,
      :host([${y.MEDIA_PREVIEW_IMAGE}][dragging]) ::slotted(media-preview-thumbnail) {
        transition-delay: var(--media-preview-transition-delay-in, .25s);
        visibility: visible;
      }

      @media (hover: hover) {
        :host([${y.MEDIA_PREVIEW_IMAGE}]:hover) media-preview-thumbnail,
        :host([${y.MEDIA_PREVIEW_IMAGE}]:hover) ::slotted(media-preview-thumbnail) {
          transition-delay: var(--media-preview-transition-delay-in, .25s);
          visibility: visible;
        }

        :host([${y.MEDIA_PREVIEW_TIME}]:hover) {
          --media-time-range-hover-display: block;
        }
      }

      media-preview-chapter-display,
      ::slotted(media-preview-chapter-display) {
        font-size: var(--media-font-size, 13px);
        line-height: 17px;
        min-width: 0;
        visibility: hidden;
        
        transition: min-width 0s, border-radius 0s, margin 0s, padding 0s, visibility 0s;
        transition-delay: calc(var(--media-preview-transition-delay-out, 0s) + var(--media-preview-transition-duration-out, .25s));
        background: var(--media-preview-chapter-background, var(--_preview-background));
        border-radius: var(--media-preview-chapter-border-radius,
          var(--media-preview-border-radius) var(--media-preview-border-radius)
          var(--media-preview-border-radius) var(--media-preview-border-radius));
        padding: var(--media-preview-chapter-padding, 3.5px 9px);
        margin: var(--media-preview-chapter-margin, 0 0 5px);
        text-shadow: var(--media-preview-chapter-text-shadow, 0 0 4px rgb(0 0 0 / .75));
      }

      :host([${y.MEDIA_PREVIEW_IMAGE}]) media-preview-chapter-display,
      :host([${y.MEDIA_PREVIEW_IMAGE}]) ::slotted(media-preview-chapter-display) {
        transition-delay: var(--media-preview-transition-delay-in, .25s);
        border-radius: var(--media-preview-chapter-border-radius, 0);
        padding: var(--media-preview-chapter-padding, 3.5px 9px 0);
        margin: var(--media-preview-chapter-margin, 0);
        min-width: 100%;
      }

      media-preview-chapter-display[${y.MEDIA_PREVIEW_CHAPTER}],
      ::slotted(media-preview-chapter-display[${y.MEDIA_PREVIEW_CHAPTER}]) {
        visibility: visible;
      }

      media-preview-chapter-display:not([aria-valuetext]),
      ::slotted(media-preview-chapter-display:not([aria-valuetext])) {
        display: none;
      }

      media-preview-time-display,
      ::slotted(media-preview-time-display),
      media-time-display,
      ::slotted(media-time-display) {
        font-size: var(--media-font-size, 13px);
        line-height: 17px;
        min-width: 0;
        
        transition: min-width 0s, border-radius 0s;
        transition-delay: calc(var(--media-preview-transition-delay-out, 0s) + var(--media-preview-transition-duration-out, .25s));
        background: var(--media-preview-time-background, var(--_preview-background));
        border-radius: var(--media-preview-time-border-radius,
          var(--media-preview-border-radius) var(--media-preview-border-radius)
          var(--media-preview-border-radius) var(--media-preview-border-radius));
        padding: var(--media-preview-time-padding, 3.5px 9px);
        margin: var(--media-preview-time-margin, 0);
        text-shadow: var(--media-preview-time-text-shadow, 0 0 4px rgb(0 0 0 / .75));
        transform: translateX(min(
          max(calc(50% - var(--_box-width) / 2),
          calc(var(--_box-shift, 0))),
          calc(var(--_box-width) / 2 - 50%)
        ));
      }

      :host([${y.MEDIA_PREVIEW_IMAGE}]) media-preview-time-display,
      :host([${y.MEDIA_PREVIEW_IMAGE}]) ::slotted(media-preview-time-display) {
        transition-delay: var(--media-preview-transition-delay-in, .25s);
        border-radius: var(--media-preview-time-border-radius,
          0 0 var(--media-preview-border-radius) var(--media-preview-border-radius));
        min-width: 100%;
      }

      :host([${y.MEDIA_PREVIEW_TIME}]:hover) {
        --media-time-range-hover-display: block;
      }

      [part~="arrow"],
      ::slotted([part~="arrow"]) {
        display: var(--media-box-arrow-display, inline-block);
        transform: translateX(min(
          max(calc(50% - var(--_box-width) / 2 + var(--media-box-arrow-offset)),
          calc(var(--_box-shift, 0))),
          calc(var(--_box-width) / 2 - 50% - var(--media-box-arrow-offset))
        ));
        
        border-color: transparent;
        border-top-color: var(--media-box-arrow-background, var(--_control-background));
        border-width: var(--media-box-arrow-border-width,
          var(--media-box-arrow-height, 5px) var(--media-box-arrow-width, 6px) 0);
        border-style: solid;
        justify-content: center;
        height: 0;
      }
    </style>
    <div id="preview-rail">
      <slot name="preview" part="box preview-box">
        <media-preview-thumbnail>
          <template shadowrootmode="${Ts.shadowRootOptions.mode}">
            ${Ts.getTemplateHTML({})}
          </template>
        </media-preview-thumbnail>
        <media-preview-chapter-display></media-preview-chapter-display>
        <media-preview-time-display></media-preview-time-display>
        <slot name="preview-arrow"><div part="arrow"></div></slot>
      </slot>
    </div>
    <div id="current-rail">
      <slot name="current" part="box current-box">
        
      </slot>
    </div>
  `}var cl=(e,t=e.mediaCurrentTime)=>{let n=Number.isFinite(e.mediaSeekableStart)?e.mediaSeekableStart:0,r=Number.isFinite(e.mediaDuration)?e.mediaDuration:e.mediaSeekableEnd;if(Number.isNaN(r))return 0;let i=(t-n)/(r-n);return Math.max(0,Math.min(i,1))},ll=(e,t=e.range.valueAsNumber)=>{let n=Number.isFinite(e.mediaSeekableStart)?e.mediaSeekableStart:0,r=Number.isFinite(e.mediaDuration)?e.mediaDuration:e.mediaSeekableEnd;return Number.isNaN(r)?0:t*(r-n)+n},ul=class extends fa{constructor(){super(),Z(this,Gc),Z(this,Jc),Z(this,Xc),Z(this,Qc),Z(this,el),Z(this,nl),Z(this,il),Z(this,Pc,null),Z(this,Fc,void 0),Z(this,Ic,void 0),Z(this,Lc,void 0),Z(this,Rc,void 0),Z(this,zc,void 0),Z(this,Bc,void 0),Z(this,Vc,void 0),Z(this,Hc,void 0),Z(this,Uc,void 0),Z(this,Wc,()=>{$(this,Gc,Kc).call(this)?X(this,Fc).start():X(this,Fc).stop()}),Z(this,qc,e=>{this.dragging||(be(e)&&(this.range.valueAsNumber=e),X(this,Uc)||this.updateBar())}),this.shadowRoot.querySelector(`#track`).insertAdjacentHTML(`afterbegin`,`<div id="buffered" part="buffered"></div>`),Q(this,Ic,this.shadowRoot.querySelectorAll(`[part~="box"]`)),Q(this,Rc,this.shadowRoot.querySelector(`[part~="preview-box"]`)),Q(this,zc,this.shadowRoot.querySelector(`[part~="current-box"]`));let e=getComputedStyle(this);Q(this,Bc,parseInt(e.getPropertyValue(`--media-box-padding-left`))),Q(this,Vc,parseInt(e.getPropertyValue(`--media-box-padding-right`))),Q(this,Fc,new Mc(this.range,X(this,qc),60))}static get observedAttributes(){return[...super.observedAttributes,y.MEDIA_PAUSED,y.MEDIA_DURATION,y.MEDIA_SEEKABLE,y.MEDIA_CURRENT_TIME,y.MEDIA_PREVIEW_IMAGE,y.MEDIA_PREVIEW_TIME,y.MEDIA_PREVIEW_CHAPTER,y.MEDIA_BUFFERED,y.MEDIA_PLAYBACK_RATE,y.MEDIA_LOADING,y.MEDIA_ENDED]}connectedCallback(){var e;super.connectedCallback(),this.range.setAttribute(`aria-label`,T(`seek`)),X(this,Wc).call(this),Q(this,Pc,this.getRootNode()),(e=X(this,Pc))==null||e.addEventListener(`transitionstart`,this)}disconnectedCallback(){var e;super.disconnectedCallback(),X(this,Fc).stop(),(e=X(this,Pc))==null||e.removeEventListener(`transitionstart`,this),Q(this,Pc,null)}attributeChangedCallback(e,t,n){super.attributeChangedCallback(e,t,n),t!=n&&(e===y.MEDIA_CURRENT_TIME||e===y.MEDIA_PAUSED||e===y.MEDIA_ENDED||e===y.MEDIA_LOADING||e===y.MEDIA_DURATION||e===y.MEDIA_SEEKABLE?(X(this,Fc).update({start:cl(this),duration:this.mediaSeekableEnd-this.mediaSeekableStart,playbackRate:this.mediaPlaybackRate}),X(this,Wc).call(this),ol(this)):e===y.MEDIA_BUFFERED&&this.updateBufferedBar(),(e===y.MEDIA_DURATION||e===y.MEDIA_SEEKABLE)&&(this.mediaChaptersCues=X(this,Hc),this.updateBar()))}get mediaChaptersCues(){return X(this,Hc)}set mediaChaptersCues(e){Q(this,Hc,e),this.updateSegments(X(this,Hc)?.map(e=>({start:cl(this,e.startTime),end:cl(this,e.endTime)})))}get mediaPaused(){return j(this,y.MEDIA_PAUSED)}set mediaPaused(e){M(this,y.MEDIA_PAUSED,e)}get mediaLoading(){return j(this,y.MEDIA_LOADING)}set mediaLoading(e){M(this,y.MEDIA_LOADING,e)}get mediaDuration(){return k(this,y.MEDIA_DURATION)}set mediaDuration(e){A(this,y.MEDIA_DURATION,e)}get mediaCurrentTime(){return k(this,y.MEDIA_CURRENT_TIME)}set mediaCurrentTime(e){A(this,y.MEDIA_CURRENT_TIME,e)}get mediaPlaybackRate(){return k(this,y.MEDIA_PLAYBACK_RATE,1)}set mediaPlaybackRate(e){A(this,y.MEDIA_PLAYBACK_RATE,e)}get mediaBuffered(){let e=this.getAttribute(y.MEDIA_BUFFERED);return e?e.split(` `).map(e=>e.split(`:`).map(e=>+e)):[]}set mediaBuffered(e){if(!e){this.removeAttribute(y.MEDIA_BUFFERED);return}let t=e.map(e=>e.join(`:`)).join(` `);this.setAttribute(y.MEDIA_BUFFERED,t)}get mediaSeekable(){let e=this.getAttribute(y.MEDIA_SEEKABLE);if(e)return e.split(`:`).map(e=>+e)}set mediaSeekable(e){if(e==null){this.removeAttribute(y.MEDIA_SEEKABLE);return}this.setAttribute(y.MEDIA_SEEKABLE,e.join(`:`))}get mediaSeekableEnd(){let[,e=this.mediaDuration]=this.mediaSeekable??[];return e}get mediaSeekableStart(){let[e=0]=this.mediaSeekable??[];return e}get mediaPreviewImage(){return N(this,y.MEDIA_PREVIEW_IMAGE)}set mediaPreviewImage(e){P(this,y.MEDIA_PREVIEW_IMAGE,e)}get mediaPreviewTime(){return k(this,y.MEDIA_PREVIEW_TIME)}set mediaPreviewTime(e){A(this,y.MEDIA_PREVIEW_TIME,e)}get mediaEnded(){return j(this,y.MEDIA_ENDED)}set mediaEnded(e){M(this,y.MEDIA_ENDED,e)}updateBar(){super.updateBar(),this.updateBufferedBar(),this.updateCurrentBox()}updateBufferedBar(){let e=this.mediaBuffered;if(!e.length)return;let t;if(this.mediaEnded)t=1;else{let n=this.mediaCurrentTime,[,r=this.mediaSeekableStart]=e.find(([e,t])=>e<=n&&n<=t)??[];t=cl(this,r)}let{style:n}=O(this.shadowRoot,`#buffered`);n.setProperty(`width`,`${t*100}%`)}updateCurrentBox(){if(!this.shadowRoot.querySelector(`slot[name="current"]`).assignedElements().length)return;let e=O(this.shadowRoot,`#current-rail`),t=O(this.shadowRoot,`[part~="current-box"]`),n=$(this,Jc,Yc).call(this,X(this,zc)),r=$(this,Xc,Zc).call(this,n,this.range.valueAsNumber),i=$(this,Qc,$c).call(this,n,this.range.valueAsNumber);e.style.transform=`translateX(${r})`,e.style.setProperty(`--_range-width`,`${n.range.width}`),t.style.setProperty(`--_box-shift`,`${i}`),t.style.setProperty(`--_box-width`,`${n.box.width}px`),t.style.setProperty(`visibility`,`initial`)}handleEvent(e){switch(super.handleEvent(e),e.type){case`input`:$(this,il,al).call(this);break;case`pointermove`:$(this,el,tl).call(this,e);break;case`pointerup`:X(this,Uc)&&Q(this,Uc,!1);break;case`pointerdown`:Q(this,Uc,!0);break;case`pointerleave`:$(this,nl,rl).call(this,null);break;case`transitionstart`:Ze(e.target,this)&&setTimeout(()=>X(this,Wc).call(this),0)}}};Pc=new WeakMap,Fc=new WeakMap,Ic=new WeakMap,Lc=new WeakMap,Rc=new WeakMap,zc=new WeakMap,Bc=new WeakMap,Vc=new WeakMap,Hc=new WeakMap,Uc=new WeakMap,Wc=new WeakMap,Gc=new WeakSet,Kc=function(){return this.isConnected&&!this.mediaPaused&&!this.mediaLoading&&!this.mediaEnded&&this.mediaSeekableEnd>0&&tt(this)},qc=new WeakMap,Jc=new WeakSet,Yc=function(e){let t=((this.getAttribute(`bounds`)?Qe(this,`#${this.getAttribute(`bounds`)}`):this.parentElement)??this).getBoundingClientRect(),n=this.range.getBoundingClientRect(),r=e.offsetWidth;return{box:{width:r,min:-(n.left-t.left-r/2),max:t.right-n.left-r/2},bounds:t,range:n}},Xc=new WeakSet,Zc=function(e,t){let n=`${t*100}%`,{width:r,min:i,max:a}=e.box;if(!r)return n;if(Number.isNaN(i)||(n=`max(${`calc(1 / var(--_range-width) * 100 * ${i}% + var(--media-box-padding-left))`}, ${n})`),!Number.isNaN(a)){let e=`calc(1 / var(--_range-width) * 100 * ${a}% - var(--media-box-padding-right))`;n=`min(${n}, ${e})`}return n},Qc=new WeakSet,$c=function(e,t){let{width:n,min:r,max:i}=e.box,a=t*e.range.width;if(a<r+X(this,Bc)){let t=e.range.left-e.bounds.left-X(this,Bc);return`${a-n/2+t}px`}if(a>i-X(this,Vc)){let t=e.bounds.right-e.range.right-X(this,Vc);return`${a+n/2-t-e.range.width}px`}return 0},el=new WeakSet,tl=function(e){let t=[...X(this,Ic)].some(t=>e.composedPath().includes(t));if(!this.dragging&&(t||!e.composedPath().includes(this))){$(this,nl,rl).call(this,null);return}let n=this.mediaSeekableEnd;if(!n)return;let r=O(this.shadowRoot,`#preview-rail`),i=O(this.shadowRoot,`[part~="preview-box"]`),a=$(this,Jc,Yc).call(this,X(this,Rc)),o=(e.clientX-a.range.left)/a.range.width;o=Math.max(0,Math.min(1,o));let s=$(this,Xc,Zc).call(this,a,o),c=$(this,Qc,$c).call(this,a,o);r.style.transform=`translateX(${s})`,r.style.setProperty(`--_range-width`,`${a.range.width}`),i.style.setProperty(`--_box-shift`,`${c}`),i.style.setProperty(`--_box-width`,`${a.box.width}px`);let l=Math.round(X(this,Lc))-Math.round(o*n);Math.abs(l)<1&&o>.01&&o<.99||(Q(this,Lc,o*n),$(this,nl,rl).call(this,X(this,Lc)))},nl=new WeakSet,rl=function(e){this.dispatchEvent(new E.CustomEvent(_.MEDIA_PREVIEW_REQUEST,{composed:!0,bubbles:!0,detail:e}))},il=new WeakSet,al=function(){X(this,Fc).stop();let e=ll(this);this.dispatchEvent(new E.CustomEvent(_.MEDIA_SEEK_REQUEST,{composed:!0,bubbles:!0,detail:e}))},ul.shadowRootOptions={mode:`open`},ul.getContainerTemplateHTML=sl,E.customElements.get(`media-time-range`)||E.customElements.define(`media-time-range`,ul);var dl=(e,t,n)=>{if(!t.has(e))throw TypeError(`Cannot `+n)},fl=(e,t,n)=>(dl(e,t,`read from private field`),n?n.call(e):t.get(e)),pl=(e,t,n)=>{if(t.has(e))throw TypeError(`Cannot add the same private member more than once`);t instanceof WeakSet?t.add(e):t.set(e,n)},ml,hl=1,gl=e=>e.mediaMuted?0:e.mediaVolume,_l=e=>`${Math.round(e*100)}%`,vl=class extends fa{constructor(){super(...arguments),pl(this,ml,()=>{let e=this.range.value,t=new E.CustomEvent(_.MEDIA_VOLUME_REQUEST,{composed:!0,bubbles:!0,detail:e});this.dispatchEvent(t)})}static get observedAttributes(){return[...super.observedAttributes,y.MEDIA_VOLUME,y.MEDIA_MUTED,y.MEDIA_VOLUME_UNAVAILABLE]}connectedCallback(){super.connectedCallback(),this.range.setAttribute(`aria-label`,T(`volume`)),this.range.addEventListener(`input`,fl(this,ml))}disconnectedCallback(){this.range.removeEventListener(`input`,fl(this,ml)),super.disconnectedCallback()}attributeChangedCallback(e,t,n){super.attributeChangedCallback(e,t,n),(e===y.MEDIA_VOLUME||e===y.MEDIA_MUTED)&&(this.range.valueAsNumber=gl(this),this.range.setAttribute(`aria-valuetext`,_l(this.range.valueAsNumber)),this.updateBar())}get mediaVolume(){return k(this,y.MEDIA_VOLUME,hl)}set mediaVolume(e){A(this,y.MEDIA_VOLUME,e)}get mediaMuted(){return j(this,y.MEDIA_MUTED)}set mediaMuted(e){M(this,y.MEDIA_MUTED,e)}get mediaVolumeUnavailable(){return N(this,y.MEDIA_VOLUME_UNAVAILABLE)}set mediaVolumeUnavailable(e){P(this,y.MEDIA_VOLUME_UNAVAILABLE,e)}};ml=new WeakMap,E.customElements.get(`media-volume-range`)||E.customElements.define(`media-volume-range`,vl);function yl(e){return`
      <style>
        :host {
          min-width: 4ch;
          padding: var(--media-button-padding, var(--media-control-padding, 10px 5px));
          width: 100%;
          display: grid;
          grid-template-columns: 1fr auto;
          gap: 1rem;
          font-weight: var(--media-button-font-weight, normal);
        }

        #checked-indicator {
          display: none;
        }

        :host([${y.MEDIA_LOOP}]) #checked-indicator {
          display: block;
        }
      </style>
      
      <span id="icon">
     </span>

      <div id="checked-indicator">
        <svg aria-hidden="true" viewBox="0 1 24 24" part="checked-indicator indicator">
          <path d="m10 15.17 9.193-9.191 1.414 1.414-10.606 10.606-6.364-6.364 1.414-1.414 4.95 4.95Z"/>
        </svg>
      </div>
    `}function bl(){return T(`Loop`)}var xl=class extends G{constructor(){super(...arguments),this.container=null}static get observedAttributes(){return[...super.observedAttributes,y.MEDIA_LOOP]}connectedCallback(){super.connectedCallback(),this.container=this.shadowRoot?.querySelector(`#icon`)||null,this.container&&(this.container.textContent=T(`Loop`))}attributeChangedCallback(e,t,n){super.attributeChangedCallback(e,t,n),e===y.MEDIA_LOOP&&this.container&&this.setAttribute(`aria-checked`,this.mediaLoop?`true`:`false`)}get mediaLoop(){return j(this,y.MEDIA_LOOP)}set mediaLoop(e){M(this,y.MEDIA_LOOP,e)}handleClick(){let e=!this.mediaLoop,t=new E.CustomEvent(_.MEDIA_LOOP_REQUEST,{composed:!0,bubbles:!0,detail:e});this.dispatchEvent(t)}};xl.getSlotTemplateHTML=yl,xl.getTooltipContentHTML=bl,E.customElements.get(`media-loop-button`)||E.customElements.define(`media-loop-button`,xl),Te(`zh-CN`,{"Start airplay":`开始 AirPlay`,"Stop airplay":`停止 AirPlay`,Audio:`音频`,Captions:`字幕`,"Enable captions":`开启字幕`,"Disable captions":`关闭字幕`,"Start casting":`开始投屏`,"Stop casting":`停止投屏`,"Enter fullscreen mode":`进入全屏`,"Exit fullscreen mode":`退出全屏`,Mute:`静音`,Unmute:`恢复音量`,Loop:`循环播放`,"Enter picture in picture mode":`开启画中画`,"Exit picture in picture mode":`关闭画中画`,Play:`播放`,Pause:`暂停`,"Playback rate":`播放速度`,"Playback rate {playbackRate}":`播放速度：{playbackRate}`,Quality:`清晰度`,"Seek backward":`快退`,"Seek forward":`快进`,Settings:`设置`,Auto:`自动`,"audio player":`音频播放器`,"video player":`视频播放器`,volume:`音量`,seek:`跳转`,"closed captions":`隐藏式辅助字幕`,"current playback rate":`当前播放速度`,"playback time":`播放时间`,"media loading":`媒体加载中...`,settings:`设置`,"audio tracks":`音轨`,quality:`清晰度`,play:`播放`,pause:`暂停`,mute:`静音`,unmute:`恢复音量`,"chapter: {chapterName}":`章节: {chapterName}`,live:`直播`,Off:`关闭`,"start airplay":`开始 AirPlay`,"stop airplay":`停止 AirPlay`,"start casting":`开始投屏`,"stop casting":`停止投屏`,"enter fullscreen mode":`进入全屏`,"exit fullscreen mode":`退出全屏`,"enter picture in picture mode":`开启画中画`,"exit picture in picture mode":`关闭画中画`,"seek to live":`跳转至直播进度`,"playing live":`正在直播中`,"seek back {seekOffset} seconds":`快退 {seekOffset} 秒`,"seek forward {seekOffset} seconds":`快进 {seekOffset} 秒`,"Network Error":`网络错误`,"Decode Error":`解码失败`,"Source Not Supported":`不支持的媒体来源`,"Encryption Error":`加密错误`,"A network error caused the media download to fail.":`媒体下载失败，请检查网络连接。`,"A media error caused playback to be aborted. The media could be corrupt or your browser does not support this format.":`媒体错误导致播放中止。可能是文件损坏，或浏览器不支持该格式。`,"An unsupported error occurred. The server or network failed, or your browser does not support this format.":`发生未支持的错误，可能是服务器或网络故障，或浏览器不支持该格式。`,"The media is encrypted and there are no keys to decrypt it.":`媒体已加密，缺少解密密钥。`,hour:`小时`,hours:`小时`,minute:`分钟`,minutes:`分钟`,second:`秒`,seconds:`秒`,"{time} remaining":`剩余 {time}`,"{currentTime} of {totalTime}":`{currentTime} / {totalTime}`,"video not loaded, unknown time.":`视频未加载，时间未知。`});var Sl={class:`file-preview audio-preview`,role:`dialog`,"aria-modal":`true`,"aria-label":`音频预览`},Cl={class:`audio-preview__stage`},wl={audio:``,noautohide:``,class:`audio-preview__controller`},Tl=[`src`],El={class:`audio-preview__layout`,slot:`centered-chrome`},Dl={key:0,class:`audio-preview__notice`,role:`status`},Ol={class:`audio-preview__now`},kl={key:0,class:`audio-preview__meta`},Al=[`title`],jl={key:1,class:`audio-preview__loading`,"aria-label":`正在加载音频`},Ml={key:2,class:`audio-preview__error`,role:`alert`},Nl={class:`audio-preview__transport`},Pl=[`disabled`],Fl=[`disabled`],Il={class:`audio-preview__playlist`},Ll=[`aria-current`,`onClick`],Rl={class:`audio-track__index`},zl={key:0,class:`fa-solid fa-volume-high`,"aria-hidden":`true`},Bl={class:`audio-track__copy`},Vl=[`title`],Hl=re(f({__name:`AudioPreview`,props:{accountId:{},files:{},initialFileId:{}},emits:[`close`,`download`],setup(f,{emit:re}){let _=f,v=re;we(`zh-CN`);let de=m(null),fe=m(null),y=m(!0),b=m(!1),pe=m(!1),x=m(``),me,S=te(()=>_.files.filter(e=>!e.is_dir&&ue(e)===`audio`).sort((e,t)=>e.name.localeCompare(t.name,void 0,{numeric:!0,sensitivity:`base`}))),C=S.value.findIndex(e=>e.id===_.initialFileId),w=m(C>=0?C:0),he=te(()=>S.value[w.value]??null),ge=te(()=>{let e=he.value;return e?se.previewURL(_.accountId,e.id,e.name):``});function _e(e){return e.replace(/\.[^.]+$/,``)}function ve(e){return _e(e).trim()||e.trim()||`未命名音频`}function ye(e){return`${ae(e.name).toUpperCase()||`音频`} · ${e.size>0?ie(e.size):`未知大小`}`}function be(e){x.value=e,window.clearTimeout(me),me=window.setTimeout(()=>{x.value=``},1500)}async function xe(){await a();let e=de.value;e&&(e.load(),await e.play().catch(()=>void 0))}async function Se(e){e<0||e>=S.value.length||e===w.value||(w.value=e,y.value=!0,b.value=!1,pe.value=!1,be(`正在播放 ${_e(S.value[e].name)}`),await xe(),Ee())}function Ce(e){let t=w.value+e;if(t<0||t>=S.value.length){be(e>0?`已经是最后一首`:`已经是第一首`);return}Se(t)}function Te(){w.value<S.value.length-1&&Se(w.value+1)}function Ee(){a(()=>{fe.value?.querySelector(`.audio-track.is-active`)?.scrollIntoView({behavior:`smooth`,block:`nearest`})})}function De(e){let t=de.value;if(!t)return;let n=Number.isFinite(t.duration)?t.duration:1/0;t.currentTime=Math.max(0,Math.min(n,t.currentTime+e)),be(e>0?`快进 ${e} 秒`:`后退 ${Math.abs(e)} 秒`)}function T(e){let t=de.value;t&&(t.volume=Math.max(0,Math.min(1,t.volume+e)),t.volume>0&&(t.muted=!1),be(`音量 ${Math.round(t.volume*100)}%`))}function Oe(){let e=de.value;e&&(e.paused?e.play().catch(()=>void 0):e.pause())}function ke(){let e=de.value;e&&(e.muted=!e.muted,be(e.muted?`已静音`:`已取消静音`))}function Ae(e){return!!(e instanceof HTMLElement?e:null)?.closest(`input, textarea, select, [contenteditable='true']`)}function je(e){if(Ae(e.target))return;let t=e.key.toLowerCase();[`arrowleft`,`arrowright`,`arrowup`,`arrowdown`,` `].includes(t)&&e.preventDefault(),t===`escape`?v(`close`):t===`arrowleft`?De(-10):t===`arrowright`?De(10):t===`arrowup`?T(.05):t===`arrowdown`?T(-.05):t===` `?Oe():t===`p`?Ce(-1):t===`n`?Ce(1):t===`m`&&ke()}function Me(){y.value=!1,b.value=!1}function Ne(){y.value=!1,b.value=!0,pe.value=!1}function Pe(){he.value&&v(`download`,he.value)}return ce(),t(()=>{window.addEventListener(`keydown`,je),Ee(),xe()}),l(()=>{window.clearTimeout(me),window.removeEventListener(`keydown`,je)}),(t,a)=>(c(),u(d,{to:`body`},[g(`main`,Sl,[n(le,{"file-name":he.value?.name,status:`正在播放第${w.value+1}首/共${S.value.length}首`,"download-label":`下载当前音频`,onClose:a[0]||=e=>v(`close`),onDownload:Pe},null,8,[`file-name`,`status`]),g(`section`,Cl,[g(`media-controller`,wl,[he.value?(c(),s(`audio`,{ref_key:`audioRef`,ref:de,slot:`media`,key:he.value.id,src:ge.value,autoplay:``,preload:`metadata`,onLoadedmetadata:Me,onCanplay:Me,onPlaying:a[1]||=e=>{pe.value=!0,Me()},onPause:a[2]||=e=>pe.value=!1,onWaiting:a[3]||=e=>y.value=!0,onError:Ne,onEnded:Te},null,40,Tl)):h(``,!0),g(`div`,El,[n(ne,{name:`audio-notice`},{default:ee(()=>[x.value?(c(),s(`div`,Dl,o(x.value),1)):h(``,!0)]),_:1}),g(`section`,Ol,[g(`div`,{class:e([`audio-preview__art`,{"is-playing":pe.value}]),"aria-hidden":`true`},[...a[6]||=[g(`div`,{class:`audio-preview__disc`},[g(`span`,null,[g(`i`,{class:`fa-solid fa-music`})])],-1)]],2),he.value?(c(),s(`div`,kl,[g(`span`,null,o(ye(he.value)),1),g(`h1`,{title:ve(he.value.name)},o(ve(he.value.name)),9,Al),g(`p`,null,o(b.value?`当前浏览器无法解码此音频格式`:`来自当前文件夹`),1)])):h(``,!0),y.value&&!b.value?(c(),s(`div`,jl,[n(oe,{size:16,color:`#1687ff`}),a[7]||=r(` 正在加载音频… `,-1)])):h(``,!0),b.value?(c(),s(`div`,Ml,[a[8]||=g(`i`,{class:`fa-solid fa-circle-exclamation`,"aria-hidden":`true`},null,-1),a[9]||=g(`div`,null,[g(`strong`,null,`浏览器无法直接播放这个音频`),g(`span`,null,`可能是音频编码不受支持，可下载后使用本地播放器打开。`)],-1),g(`button`,{type:`button`,onClick:Pe},`下载音频`)])):h(``,!0),g(`div`,Nl,[g(`button`,{type:`button`,"aria-label":`上一首`,disabled:w.value<=0,onClick:a[4]||=e=>Ce(-1)},[...a[10]||=[g(`i`,{class:`fa-solid fa-backward-step`,"aria-hidden":`true`},null,-1)]],8,Pl),a[12]||=g(`media-control-bar`,{class:`audio-preview__controls`},[g(`media-play-button`,{"aria-label":`播放或暂停`}),g(`media-time-display`,{"show-duration":``}),g(`media-time-range`),g(`media-mute-button`,{"aria-label":`静音`}),g(`media-volume-range`),g(`media-playback-rate-button`,{rates:`0.5 0.75 1 1.25 1.5 2`})],-1),g(`button`,{type:`button`,"aria-label":`下一首`,disabled:w.value>=S.value.length-1,onClick:a[5]||=e=>Ce(1)},[...a[11]||=[g(`i`,{class:`fa-solid fa-forward-step`,"aria-hidden":`true`},null,-1)]],8,Fl)]),a[13]||=g(`div`,{class:`audio-preview__shortcuts`,"aria-hidden":`true`},[g(`span`,null,`← / → 快退快进`),g(`i`,null,`·`),g(`span`,null,`↑ / ↓ 音量`),g(`i`,null,`·`),g(`span`,null,`空格 播放暂停`),g(`i`,null,`·`),g(`span`,null,`P 上一首丨N 下一首`),g(`i`,null,`·`),g(`span`,null,`M 静音切换`)],-1)]),g(`aside`,Il,[g(`header`,null,[a[14]||=g(`div`,null,[g(`strong`,null,`播放列表`),g(`span`,null,`当前文件夹`)],-1),g(`b`,null,o(S.value.length)+` 首`,1)]),g(`div`,{ref_key:`trackListRef`,ref:fe,class:`audio-preview__tracks`},[(c(!0),s(p,null,i(S.value,(t,n)=>(c(),s(`button`,{key:t.id,type:`button`,class:e([`audio-track`,{"is-active":n===w.value}]),"aria-current":n===w.value?`true`:void 0,onClick:e=>Se(n)},[g(`span`,Rl,[n===w.value?(c(),s(`i`,zl)):(c(),s(p,{key:1},[r(o(String(n+1).padStart(2,`0`)),1)],64))]),g(`span`,Bl,[g(`strong`,{title:ve(t.name)},o(ve(t.name)),9,Vl),g(`small`,null,o(ye(t)),1)]),a[15]||=g(`i`,{class:`fa-solid fa-play audio-track__play`,"aria-hidden":`true`},null,-1)],10,Ll))),128))],512)])])])])])]))}}),[[`__scopeId`,`data-v-c123c3b2`]]);export{Hl as default};